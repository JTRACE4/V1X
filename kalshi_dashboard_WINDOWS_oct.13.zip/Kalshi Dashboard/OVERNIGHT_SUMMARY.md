# Overnight findings — KXBTC15M bot

## 1. Near-close "buy the favorite" strategy: the stop-loss hurts, not helps

Tested breakeven + trailing-stop exits (various lock-in/trail/hard-stop combos) against
3,994 historical settled markets, entering at T-15/10/7/5/3 minutes before close.

**Result: every active stop-loss variant tested performed WORSE than just holding to
settlement.** At the best entry point (T-3min), holding to settlement with no stop at
all closes non-negative **89.45%** of the time. The best stop-loss variant only reached
79%, even after loosening the stop all the way out to 30 cents.

Why: by 3 minutes before close, the market has usually already mostly resolved
directionally (average favorite price ~90%, from earlier calibration work). Short-term
dips at that stage are mostly noise that reverts, not real signal — a stop-loss reacts
to that noise and locks in losses that would have recovered.

**Action taken:** the live bot's "close_favorite" leg now enters at T-3min and holds to
settlement with no stop-loss at all — simpler than what we discussed, and empirically better.

## 2. Momentum-jump strategy: a real, validated signal — with a big caveat

Confirmed via 1000-market lead-lag test: BTC spot price moves lead Kalshi's price by
almost exactly 1 minute (correlation 0.47 at that lag, vs ~0 at every other lag tested).
Regression: a 1% spot move predicts roughly a 2.05-point move in Kalshi's price the
following minute (R²=0.22).

Backtested entering in the direction of a >=0.10% one-minute spot move, then using a
trailing/breakeven stop to exit on correction:

**Result: 92.87% non-negative, average payoff +$23.41 per $100, across 1,235 historical
triggers (fires on ~31% of 15-min windows).**

**Important caveat:** this number assumes perfect execution — buying and selling exactly
at the quoted mark price with zero spread and zero delay. Real trading has Kalshi's
actual bid/ask spread and a few seconds of latency between a candle closing and the bot
reacting. The real edge is very likely smaller than $23/$100. This is exactly why it's
now running in **paper mode live** rather than being taken at face value — we'll have
real forward evidence instead of just backtest math.

## 3. Bug fixed: the original bot was never logging settlements

While reviewing the first night's live log, found that positions were being opened
correctly but essentially never closed out in the log — the state tracking lost the
previous market's position the instant a new market opened. Rebuilt the state handling
so every tracked market gets checked for settlement independently, regardless of which
market is currently "active" for new entries.

## 4. What's running now

The bot (`src/kalshi_paper_bot.py`) runs both strategies concurrently, paper-trading only:
- **close_favorite**: enters the favorite side at T-3min, holds to settlement, no stop
- **momentum_jump**: enters on a >=0.10% one-minute spot jump (config in
  `bot_state/thresholds.json`), exits via trailing-stop (lock in at +3c, trail 2c,
  breakeven-stop at -1c) or settlement

Everything logs to `bot_state/trades.csv` (one row per entry, one row per exit — pair by
ticker+strategy) and `bot_state/ticks.csv`. `src/kalshi_bot_recalibrate.py` will compare
live performance to the backtest once ~20+ momentum trades have accumulated live.

## 5. Honest bottom line on "always sell out positive"

Can't be literally guaranteed — real markets have gap risk and spread that no
backtest fully captures. But the two things that actually move the needle in that
direction (validated against real data, not assumption) are: **entering very late with
no stop** for the calm case, and **entering on validated momentum with a trailing stop**
for the opportunistic case. Both are live now, both need real forward data before either
should be trusted with real money.
