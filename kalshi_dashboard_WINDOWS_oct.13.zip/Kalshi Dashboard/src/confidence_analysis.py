import argparse
import os

import joblib
import numpy as np

from src.data import fetch_history
from src.features import build_dataset, FEATURE_COLUMNS

MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "models", "model.joblib")


def analyze(symbol=None, interval=None, days=4300, test_size=0.15):
    bundle = joblib.load(MODEL_PATH)
    model = bundle["model"]
    symbol = symbol or bundle["symbol"]
    interval = interval or bundle["interval"]

    raw = fetch_history(symbol=symbol, interval=interval, days=days)
    data = build_dataset(raw)

    split_idx = int(len(data) * (1 - test_size))
    test_df = data.iloc[split_idx:]

    proba_up = model.predict_proba(test_df[FEATURE_COLUMNS])[:, 1]
    confidence = np.abs(proba_up - 0.5)
    predicted_up = proba_up >= 0.5
    correct = predicted_up.astype(int) == test_df["label"].values

    print(f"{'proba cutoff':>13} {'coverage':>10} {'n':>10} {'win rate':>10}")
    for min_conf in [0.00, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45]:
        mask = confidence >= min_conf
        n = int(mask.sum())
        coverage = mask.mean()
        win_rate = correct[mask].mean() if n > 0 else float("nan")
        print(f"{0.5 + min_conf:>13.2f} {coverage:>10.4%} {n:>10d} {win_rate:>10.4%}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbol", default=None)
    parser.add_argument("--interval", default=None)
    parser.add_argument("--days", type=int, default=4300)
    parser.add_argument("--test-size", type=float, default=0.15)
    args = parser.parse_args()

    analyze(symbol=args.symbol, interval=args.interval, days=args.days, test_size=args.test_size)
