import numpy as np
import pandas as pd

# Base resolution is 5-minute candles. Each trend window below is expressed
# as a number of 5-minute bars so every named horizon lines up exactly:
# 288 bars/day, 2016 bars/week, ~8640 bars/month (30d), ~105120 bars/year (365d).
BARS_PER_DAY = 288

TREND_WINDOWS = {
    "trend_5m": 1,
    "trend_15m": 3,
    "trend_30m": 6,
    "trend_1h": 12,
    "trend_6d": 6 * BARS_PER_DAY,
    "trend_week": 7 * BARS_PER_DAY,
    "trend_month": 30 * BARS_PER_DAY,
    "trend_year": 365 * BARS_PER_DAY,
}

# how many bars ahead the label looks: 15 minutes = 3 five-minute bars
LABEL_HORIZON_BARS = 3

FEATURE_COLUMNS = list(TREND_WINDOWS.keys()) + [
    "vol_10", "vol_20",
    "rsi_14",
    "macd", "macd_signal", "macd_hist",
    "bb_pctb",
    "sma_ratio_10", "sma_ratio_30",
    "vol_chg", "vol_z_20",
    "hl_range",
]


def _rsi(close, period=14):
    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))


def _macd(close, fast=12, slow=26, signal=9):
    ema_fast = close.ewm(span=fast, adjust=False).mean()
    ema_slow = close.ewm(span=slow, adjust=False).mean()
    macd = ema_fast - ema_slow
    macd_signal = macd.ewm(span=signal, adjust=False).mean()
    return macd, macd_signal, macd - macd_signal


def _bollinger_pctb(close, period=20, num_std=2):
    sma = close.rolling(period).mean()
    std = close.rolling(period).std()
    upper = sma + num_std * std
    lower = sma - num_std * std
    return (close - lower) / (upper - lower)


def add_features(df):
    df = df.copy()
    close = df["close"]
    volume = df["volume"]

    for name, window in TREND_WINDOWS.items():
        df[name] = close.pct_change(window)

    short_ret = close.pct_change(1)
    df["vol_10"] = short_ret.rolling(10).std()
    df["vol_20"] = short_ret.rolling(20).std()

    df["rsi_14"] = _rsi(close, 14)

    macd, macd_signal, macd_hist = _macd(close)
    df["macd"] = macd
    df["macd_signal"] = macd_signal
    df["macd_hist"] = macd_hist

    df["bb_pctb"] = _bollinger_pctb(close)

    sma_10 = close.rolling(10).mean()
    sma_30 = close.rolling(30).mean()
    df["sma_ratio_10"] = close / sma_10 - 1
    df["sma_ratio_30"] = close / sma_30 - 1

    df["vol_chg"] = volume.pct_change(1)
    df["vol_z_20"] = (volume - volume.rolling(20).mean()) / volume.rolling(20).std()

    df["hl_range"] = (df["high"] - df["low"]) / close

    return df


def add_label(df):
    df = df.copy()
    df["label"] = (df["close"].shift(-LABEL_HORIZON_BARS) > df["close"]).astype(int)
    return df


def build_dataset(df):
    df = add_features(df)
    df = add_label(df)
    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.dropna(subset=FEATURE_COLUMNS + ["label"]).reset_index(drop=True)
    return df
