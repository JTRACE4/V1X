"""Tests a whipsaw filter using REAL sub-minute price data (Kalshi's per-market
trades endpoint, millisecond precision) instead of the 1-minute candle proxy
used in kalshi_volatility_filter_backtest.py, which was too coarse to see a
30-second move at all. For each settled market: find the price at the normal
entry point (3.5min before close) and the price 30 seconds before that, and
test whether skipping entries where that recent move was large improves
results. Buy-and-hold-to-settlement only (no defensive exit) to isolate the
entry-quality signal cleanly, same approach as the early-prediction test."""
import argparse
import datetime as dt
import statistics
import time

from src.kalshi_favorite_backtest import BASE, _get, fetch_settled_markets

EPS = 1e-9


def fetch_trades_anchored(ticker, anchor_ts, lookback_seconds=40, max_pages=8, page_limit=1000):
    """Paginates backward from the most recent trade until coverage reaches
    anchor_ts - lookback_seconds, or max_pages is hit. Returns None if that
    coverage was never reached (market too busy / too little history)."""
    cursor = None
    collected = []
    for _ in range(max_pages):
        params = {"ticker": ticker, "limit": page_limit}
        if cursor:
            params["cursor"] = cursor
        data = _get(f"{BASE}/markets/trades", params=params)
        trades = data.get("trades", [])
        cursor = data.get("cursor")
        if not trades:
            break
        for t in trades:
            ts = dt.datetime.fromisoformat(t["created_time"].replace("Z", "+00:00")).timestamp()
            collected.append((ts, float(t["yes_price_dollars"])))
        oldest = min(ts for ts, _ in collected)
        if oldest <= anchor_ts - lookback_seconds or not cursor:
            break
    if not collected:
        return None
    oldest = min(ts for ts, _ in collected)
    if oldest > anchor_ts - lookback_seconds:
        return None  # never reached far enough back - skip this market
    return sorted(collected)


def price_at_or_before(trades, ts):
    eligible = [(t, p) for t, p in trades if t <= ts]
    return eligible[-1][1] if eligible else None


def evaluate_market(m, entry_minutes=3.5):
    result = m.get("result")
    if result not in ("yes", "no"):
        return None
    ticker = m["ticker"]
    close_ts = dt.datetime.fromisoformat(m["close_time"].replace("Z", "+00:00")).timestamp()
    entry_ts = close_ts - entry_minutes * 60

    trades = fetch_trades_anchored(ticker, entry_ts, lookback_seconds=40)
    if trades is None:
        return None

    entry_price = price_at_or_before(trades, entry_ts)
    price_30s_before = price_at_or_before(trades, entry_ts - 30)
    if entry_price is None or price_30s_before is None or entry_price == 0.5:
        return None

    recent_move = abs(entry_price - price_30s_before)
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)
    payoff = (1 - cost) if side == result else -cost
    return {"recent_move": recent_move, "payoff": payoff}


def evaluate(records, move_threshold, bet_size=100.0):
    payoffs = []
    skipped = 0
    for r in records:
        if move_threshold is not None and r["recent_move"] > move_threshold:
            skipped += 1
            continue
        payoffs.append(r["payoff"])
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "skipped": skipped, "non_negative": non_negative,
            "avg_payoff": statistics.mean(payoffs) * bet_size,
            "total_payoff": sum(payoffs) * bet_size}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-markets", type=int, default=1000)
    parser.add_argument("--entry-minutes", type=float, default=3.5)
    args = parser.parse_args()

    print(f"Fetching last {args.n_markets} settled KXBTC15M markets...")
    markets = fetch_settled_markets(args.n_markets, series="KXBTC15M")
    print(f"Got {len(markets)} settled markets. Pulling sub-minute trade data at each entry point...")

    records = []
    skipped_too_busy = 0
    for i, m in enumerate(markets):
        try:
            out = evaluate_market(m, args.entry_minutes)
        except Exception as exc:
            out = None
        if out is None:
            skipped_too_busy += 1
        else:
            records.append(out)
        if (i + 1) % 100 == 0:
            print(f"  ...{i + 1}/{len(markets)} processed, {len(records)} usable so far")
        time.sleep(0.1)

    print(f"\nUsable records: {len(records)} (skipped/no-data: {skipped_too_busy})\n")

    records_sorted = records  # markets already roughly chronological from fetch_settled_markets
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    print("--- baseline (no whipsaw filter) ---")
    for label, data in (("TRAIN", train), ("HOLDOUT", test)):
        res = evaluate(data, None)
        print(f"{label}: n={res['n']} non-neg={res['non_negative']:.2%} "
              f"avgPay/$100={res['avg_payoff']:+.2f} total=${res['total_payoff']:+.2f}")

    print("\n--- sweeping 30-second move threshold on TRAIN ---")
    best = None
    for move_threshold in [0.02, 0.05, 0.08, 0.10, 0.15, 0.20]:
        res = evaluate(train, move_threshold)
        if res:
            print(f"  move_threshold={move_threshold:.2f}: n={res['n']} (skipped {res['skipped']}) "
                  f"non-neg={res['non_negative']:.2%} avgPay/$100={res['avg_payoff']:+.2f} "
                  f"total=${res['total_payoff']:+.2f}")
            if best is None or res["non_negative"] > best[0]["non_negative"]:
                best = (res, move_threshold)

    if best:
        _, best_move = best
        print(f"\n--- 30s whipsaw filter (threshold={best_move}) validated on HOLDOUT ---")
        res = evaluate(test, best_move)
        print(f"n={res['n']} (skipped {res['skipped']}) non-neg={res['non_negative']:.2%} "
              f"avgPay/$100={res['avg_payoff']:+.2f} total=${res['total_payoff']:+.2f}")


if __name__ == "__main__":
    main()
