"""Reports accuracy since the tracking baseline set on 2026-08-15 (per user
request, to get a clean read of the CURRENT system - regime veto, BEAR
confidence floor, settlement sanity check, wider momentum window - without
the cumulative day's numbers being diluted by the earlier, since-fixed bugs.
Read-only, just reads data_cache/kalshi_dashboard_history.json and the
baseline marker.
"""
import json
import os

HISTORY_FILE = os.path.join(os.path.dirname(__file__), "..", "data_cache", "kalshi_dashboard_history.json")
BASELINE_FILE = os.path.join(os.path.dirname(__file__), "..", "data_cache", "tracking_baseline.json")


def main():
    with open(HISTORY_FILE) as f:
        data = json.load(f)
    with open(BASELINE_FILE) as f:
        baseline = json.load(f)

    print(f"Since baseline set {baseline.get('_set_at')}:\n")
    for name, hist in data.items():
        start = baseline.get(name, 0)
        new_entries = hist[start:]
        graded = [x for x in new_entries if x["correct"] is not None]
        if not graded:
            print(f"{name}: no new graded windows yet ({len(new_entries)} total new, incl. no-calls)")
            continue
        correct = sum(1 for x in graded if x["correct"])
        print(f"{name}: {correct}/{len(graded)} correct ({correct/len(graded):.1%}) "
              f"- {len(new_entries)} new windows since baseline")


if __name__ == "__main__":
    main()
