"""Per-market confirm % (the confidence floor a call must reach before it
locks), tested separately for BTC and XRP. From the dashboard's real lock
moment, a call locks the first time either side's Kalshi price is at/above
the floor (and at/below the 82% buy cap for the money column). Split by date
into two halves - a floor only counts as better if it helps in BOTH.
Asked 2026-10-03: 'maybe different markets we should have different
confirm %?'"""
import json
import os

import numpy as np
import pandas as pd

ROOT = os.path.join(os.path.dirname(__file__), "..")
CAP = 0.82
FEE = lambda p: 0.07 * p * (1 - p)
hist = json.load(open(os.path.join(ROOT, "data_cache", "kalshi_dashboard_history.json")))
res = {r["ticker"]: r["actual_side"] for a in ("BTC", "XRP") for r in hist[a] if r.get("actual_side")}

frames = []
for f in ("intrawindow_price_log_v1_stale_quotes.csv", "intrawindow_price_log.csv"):
    d = pd.read_csv(os.path.join(ROOT, "bot_state", f), usecols=["ts", "asset", "ticker", "seconds_left",
                                                                    "kalshi_price", "locked_call"])
    frames.append(d)
d = pd.concat(frames)
d["ts"] = pd.to_datetime(d.ts, format="ISO8601", utc=True, errors="coerce")
d = d.dropna(subset=["ts"])
d["res"] = d.ticker.map(res)
d = d.dropna(subset=["res"]).sort_values(["ticker", "ts"])
days = sorted(d.ts.dt.date.unique())
split = days[len(days) // 2]


def lock_at_floor(g, floor):
    L = g[g.locked_call.isin(["YES", "NO"])]
    if L.empty:
        return None
    g = g[g.ts >= L.ts.iloc[0]]
    g = g[g.seconds_left > 90]
    fav_px = np.maximum(g.kalshi_price, 1 - g.kalshi_price)
    hit = g[fav_px >= floor]
    if hit.empty:
        return None
    r = hit.iloc[0]
    side = "YES" if r.kalshi_price >= 0.5 else "NO"
    return side, max(r.kalshi_price, 1 - r.kalshi_price), side == r.res, r.ts.date() < split


for a in ("BTC", "XRP"):
    print(f"\n{a}  (halves: before / from {split})")
    groups = list(d[d.asset == a].groupby("ticker"))
    for floor in (0.58, 0.62, 0.66, 0.70, 0.74, 0.78):
        rows = [x for x in (lock_at_floor(g, floor) for _, g in groups) if x]
        R = pd.DataFrame(rows, columns=["side", "px", "won", "early"])
        out = []
        for name, S in (("1st half", R[R.early]), ("2nd half", R[~R.early]), ("ALL", R)):
            B = S[S.px <= CAP]
            e = (B.px + 0.01).clip(upper=0.99)
            pnl = np.where(B.won, 1, 0) - e - e.map(FEE)
            roi = pnl.sum() / e.sum() if len(B) else 0
            out.append(f"{name}: right {S.won.mean():.0%} n={len(S)} | money (<=82c) n={len(B)} ROI {roi:+5.1%}")
        print(f"  confirm {floor:.0%}:  " + "   ".join(out))
