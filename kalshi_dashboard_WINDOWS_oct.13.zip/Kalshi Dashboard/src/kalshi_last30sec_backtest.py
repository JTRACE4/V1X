"""Tests buying the favorite in the last 30 seconds before close, only if price
is below 96% (skip near-certain markets), holding to settlement. Uses Kalshi's
per-market trades endpoint for true sub-minute precision, not 1-min candles."""
import argparse
import datetime as dt
import statistics
import time

from src.kalshi_favorite_backtest import BASE, _get, fetch_settled_markets

EPS = 1e-9
PRICE_CEILING = 0.96
SECONDS_BEFORE_CLOSE = 30


def fetch_trades_near_close(ticker, close_ts, lookback_seconds=180, limit=200):
    """Fetch recent trades for a market; trades come back newest-first, so we
    only need the first page to find the price right before close in most cases."""
    data = _get(f"{BASE}/markets/trades", params={"ticker": ticker, "limit": limit})
    trades = data.get("trades", [])
    out = []
    for t in trades:
        created = dt.datetime.fromisoformat(t["created_time"].replace("Z", "+00:00"))
        ts = created.timestamp()
        if close_ts - lookback_seconds <= ts <= close_ts:
            out.append((ts, float(t["yes_price_dollars"])))
    return sorted(out)


def price_at_offset(trades, close_ts, seconds_before_close):
    target_ts = close_ts - seconds_before_close
    eligible = [(ts, p) for ts, p in trades if ts <= target_ts]
    if eligible:
        return eligible[-1][1]
    return trades[0][1] if trades else None


def simulate_market(m, price_ceiling=PRICE_CEILING, seconds_before_close=SECONDS_BEFORE_CLOSE):
    result = m.get("result")
    if result not in ("yes", "no"):
        return None
    ticker = m["ticker"]
    close_ts = dt.datetime.fromisoformat(m["close_time"].replace("Z", "+00:00")).timestamp()

    trades = fetch_trades_near_close(ticker, close_ts)
    if not trades:
        return None
    price = price_at_offset(trades, close_ts, seconds_before_close)
    if price is None or price == 0.5:
        return None

    confidence = max(price, 1 - price)
    if confidence >= price_ceiling:
        return {"skipped": True}

    side = "yes" if price > 0.5 else "no"
    cost = price if side == "yes" else (1 - price)
    payoff = (1 - cost) if side == result else -cost
    return {"skipped": False, "payoff": payoff, "cost": cost}


def evaluate(series, n_markets, price_ceiling=PRICE_CEILING, seconds_before_close=SECONDS_BEFORE_CLOSE, bet_size=100.0):
    print(f"Fetching last {n_markets} settled {series} markets...")
    markets = fetch_settled_markets(n_markets, series=series)
    print(f"Got {len(markets)} settled markets. Pulling trade-level data near close...")

    payoffs = []
    skipped = 0
    missing = 0
    for i, m in enumerate(markets):
        try:
            out = simulate_market(m, price_ceiling, seconds_before_close)
        except Exception as exc:
            print(f"  skipping {m['ticker']}: {exc}")
            out = None
        if out is None:
            missing += 1
        elif out["skipped"]:
            skipped += 1
        else:
            payoffs.append(out["payoff"])
        if (i + 1) % 200 == 0:
            print(f"  ...{i + 1}/{len(markets)} processed")
        time.sleep(0.1)

    n = len(payoffs)
    if n == 0:
        print(f"No usable trades for {series}.")
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    avg_payoff = statistics.mean(payoffs) * bet_size
    print(f"\n=== {series}: buy favorite at T-{seconds_before_close}s, skip if >={price_ceiling:.0%} ===")
    print(f"n={n} (skipped as already >={price_ceiling:.0%}: {skipped}, missing/no-trade-data: {missing})")
    print(f"non-negative={non_negative:.2%} avg_payoff/$100={avg_payoff:+.2f}")
    return {"n": n, "non_negative": non_negative, "avg_payoff": avg_payoff, "skipped": skipped, "missing": missing}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--series", required=True)
    parser.add_argument("--n-markets", type=int, default=1000)
    parser.add_argument("--price-ceiling", type=float, default=PRICE_CEILING)
    parser.add_argument("--seconds-before-close", type=int, default=SECONDS_BEFORE_CLOSE)
    args = parser.parse_args()
    evaluate(args.series, args.n_markets, args.price_ceiling, args.seconds_before_close)


if __name__ == "__main__":
    main()
