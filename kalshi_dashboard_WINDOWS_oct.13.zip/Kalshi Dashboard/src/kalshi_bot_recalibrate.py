import csv
import json
import os
from collections import defaultdict

from src.kalshi_paper_bot import TRADES_PATH, THRESHOLDS_PATH


def load_completed_trades():
    if not os.path.exists(TRADES_PATH):
        return []
    with open(TRADES_PATH) as f:
        rows = list(csv.DictReader(f))
    # entries and exits are logged as separate rows sharing (ticker, strategy);
    # pair them up into completed trades.
    entries = {}
    completed = []
    for row in rows:
        key = (row["ticker"], row["strategy"])
        if row["entry_time"]:
            entries[key] = row
        elif row["exit_time"]:
            entry = entries.pop(key, None)
            if entry:
                cost = float(row["cost"])
                side = row["side"]
                reason = row["exit_reason"]
                result = row["result"]
                if reason == "settlement":
                    # recompute from side/result rather than trusting the stored
                    # payoff/exit_price - a prior bug inverted this for "no" trades.
                    # side and result are always correct, so this is the safe source of truth.
                    payoff = (1 - cost) if side == result else -cost
                else:
                    # stop-loss exits are computed inline against live ticks and don't
                    # have this failure mode, so the stored value is trustworthy.
                    payoff = float(row["realized_payoff"])
                completed.append({
                    "ticker": row["ticker"],
                    "strategy": row["strategy"],
                    "side": side,
                    "cost": cost,
                    "exit_reason": reason,
                    "realized_payoff": payoff,
                    "result": result,
                })
    return completed


def summarize_by_strategy(trades):
    by_strategy = defaultdict(list)
    for t in trades:
        by_strategy[t["strategy"]].append(t)

    for strategy, ts in by_strategy.items():
        n = len(ts)
        avg_payoff = sum(t["realized_payoff"] for t in ts) / n
        non_negative = sum(1 for t in ts if t["realized_payoff"] >= 0) / n
        reasons = defaultdict(int)
        for t in ts:
            reasons[t["exit_reason"]] += 1
        print(f"\n{strategy}: n={n} non-negative={non_negative:.1%} "
              f"avg_payoff/$100={avg_payoff * 100:+.2f} reasons={dict(reasons)}")


def main():
    trades = load_completed_trades()
    print(f"Loaded {len(trades)} completed (entry+exit matched) paper trades.")
    if not trades:
        print("No completed trades yet - the bot needs more market cycles before there's "
              "anything to recalibrate from.")
        return

    summarize_by_strategy(trades)

    momentum_trades = [t for t in trades if t["strategy"] == "momentum_jump"]
    if len(momentum_trades) < 20:
        print(f"\nOnly {len(momentum_trades)} momentum trades so far - too few to "
              "responsibly recalibrate thresholds. Current config in "
              f"{THRESHOLDS_PATH if os.path.exists(THRESHOLDS_PATH) else '(defaults, no override file yet)'} "
              "is left unchanged.")
        return

    # simple, conservative recalibration: if the live hard-stop rate is far higher
    # than the backtest's ~1-2%, loosen it slightly; if trailing stops rarely fire
    # and losers are still large, tighten the trail. This intentionally makes small
    # nudges rather than re-deriving parameters from scratch on limited live data.
    n = len(momentum_trades)
    hard_stops = sum(1 for t in momentum_trades if t["exit_reason"] == "breakeven_stop")
    hard_stop_rate = hard_stops / n
    print(f"\nLive momentum hard-stop rate: {hard_stop_rate:.1%} over {n} trades "
          "(backtest expectation was roughly 1-2%).")

    if hard_stop_rate > 0.10:
        print("Hard-stop firing much more often than expected live - consider loosening it "
              "by hand; leaving thresholds.json untouched rather than guessing from limited data.")
    else:
        print("Hard-stop rate looks broadly consistent with the backtest. No change made.")


if __name__ == "__main__":
    main()
