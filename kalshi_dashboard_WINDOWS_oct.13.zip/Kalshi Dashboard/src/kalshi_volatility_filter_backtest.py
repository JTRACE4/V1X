"""Tests skipping close_favorite entries when Kalshi's OWN price has moved too
much in the last ~1 minute before entry - a whipsaw filter, separate from the
existing spot-momentum entry filter. Motivated by a real loss: price swung
95.5% yes -> 64.5% -> 66% no, all within about a minute, and the entry landed
mid-swing on the wrong side. Layers on top of the already-validated entry
filter + confidence floor + adaptive-gap defensive exit."""
import argparse
import statistics

from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records, build_spot_minute_map
from src.kalshi_adaptive_gap_backtest import adaptive_threshold

EPS = 1e-9


def simulate(candles, close_ts, result, spot_map, entry_minutes, entry_filter_threshold,
             base_threshold, min_threshold, confidence_floor, kalshi_vol_threshold):
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None

    window_start_ts = close_ts - entry_minutes * 60

    entry_idx = None
    if confidence_floor <= 0.5:
        for i, (ts, _) in enumerate(prices):
            if ts <= window_start_ts:
                entry_idx = i
            else:
                break
        if entry_idx is None:
            entry_idx = 0
    else:
        for i, (ts, p) in enumerate(prices):
            if ts < window_start_ts or ts >= close_ts:
                continue
            if max(p, 1 - p) >= confidence_floor:
                entry_idx = i
                break
        if entry_idx is None:
            return None

    if entry_idx >= len(prices) - 1:
        return None

    entry_ts, entry_price = prices[entry_idx]
    if entry_price == 0.5:
        return None

    # kalshi whipsaw filter: how much has kalshi's own price moved in the last
    # ~60s before entry? skip if it's been unusually volatile.
    if kalshi_vol_threshold is not None:
        prior = None
        for ts, p in reversed(prices[:entry_idx + 1]):
            if entry_ts - ts >= 60:
                prior = p
                break
        if prior is not None and abs(entry_price - prior) > kalshi_vol_threshold:
            return None

    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    if entry_filter_threshold is not None:
        spot_now = spot_map.get(entry_ts)
        spot_prev = spot_map.get(entry_ts - 60)
        if spot_now is not None and spot_prev is not None and spot_prev != 0:
            spot_ret = spot_now / spot_prev - 1
            adverse_at_entry = (side == "yes" and spot_ret <= -entry_filter_threshold) or \
                                (side == "no" and spot_ret >= entry_filter_threshold)
            if adverse_at_entry:
                return None

    for ts, p in prices[entry_idx + 1:]:
        confidence = max(p, 1 - p)
        threshold = adaptive_threshold(confidence, base_threshold, min_threshold)
        spot_now = spot_map.get(ts)
        spot_prev = spot_map.get(ts - 60)
        if spot_now is not None and spot_prev is not None and spot_prev != 0:
            spot_ret = spot_now / spot_prev - 1
            adverse = (side == "yes" and spot_ret <= -threshold) or \
                      (side == "no" and spot_ret >= threshold)
            if adverse:
                price_side_now = p if side == "yes" else (1 - p)
                return {"payoff": price_side_now - cost, "reason": "defensive_exit"}

    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff, "reason": "settlement"}


def evaluate(records, spot_map, entry_minutes, entry_filter, base_threshold, min_threshold,
             confidence_floor, kalshi_vol_threshold, bet_size=100.0):
    payoffs = []
    skipped = 0
    for r in records:
        out = simulate(r["candles"], r["close_ts"], r["result"], spot_map, entry_minutes,
                        entry_filter, base_threshold, min_threshold, confidence_floor,
                        kalshi_vol_threshold)
        if out is None:
            skipped += 1
            continue
        payoffs.append(out["payoff"])
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "skipped": skipped, "non_negative": non_negative,
            "avg_payoff": statistics.mean(payoffs) * bet_size,
            "total_payoff": sum(payoffs) * bet_size}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--entry-minutes", type=float, default=3.5)
    parser.add_argument("--entry-filter", type=float, default=0.00005)
    parser.add_argument("--base-threshold", type=float, default=0.00035)
    parser.add_argument("--min-threshold", type=float, default=0.00005)
    parser.add_argument("--confidence-floor", type=float, default=0.58)
    args = parser.parse_args()

    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.")
    spot_map = build_spot_minute_map(records)

    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    print("--- current setup (58% floor, no whipsaw filter) baseline ---")
    for label, data in (("TRAIN", train), ("HOLDOUT", test)):
        res = evaluate(data, spot_map, args.entry_minutes, args.entry_filter,
                        args.base_threshold, args.min_threshold, args.confidence_floor, None)
        print(f"{label}: n={res['n']} non-neg={res['non_negative']:.2%} "
              f"avgPay/$100={res['avg_payoff']:+.2f} total=${res['total_payoff']:+.2f}")

    print("\n--- sweeping whipsaw threshold on TRAIN ---")
    best = None
    for vol_threshold in [0.05, 0.10, 0.15, 0.20, 0.25, 0.30]:
        res = evaluate(train, spot_map, args.entry_minutes, args.entry_filter,
                        args.base_threshold, args.min_threshold, args.confidence_floor, vol_threshold)
        if res:
            print(f"  vol_threshold={vol_threshold:.2f}: n={res['n']} (skipped {res['skipped']}) "
                  f"non-neg={res['non_negative']:.2%} avgPay/$100={res['avg_payoff']:+.2f} "
                  f"total=${res['total_payoff']:+.2f}")
            if best is None or res["non_negative"] > best[0]["non_negative"]:
                best = (res, vol_threshold)

    _, best_vol = best
    print(f"\n--- whipsaw filter (threshold={best_vol}) validated on HOLDOUT ---")
    res = evaluate(test, spot_map, args.entry_minutes, args.entry_filter,
                    args.base_threshold, args.min_threshold, args.confidence_floor, best_vol)
    print(f"n={res['n']} (skipped {res['skipped']}) non-neg={res['non_negative']:.2%} "
          f"avgPay/$100={res['avg_payoff']:+.2f} total=${res['total_payoff']:+.2f}")


if __name__ == "__main__":
    main()
