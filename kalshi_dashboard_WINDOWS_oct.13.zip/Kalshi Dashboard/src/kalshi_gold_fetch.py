import pickle
from src.kalshi_favorite_backtest import fetch_settled_markets
from src.kalshi_favorite_sweep import fetch_candles

print("Fetching settled gold markets list...")
markets = fetch_settled_markets(2500, series='KXGOLD15M')
markets = [m for m in markets if m.get('result') in ('yes', 'no')]
print(f"{len(markets)} valid settled markets. Pulling candle paths...")

records = []
for i, m in enumerate(markets):
    try:
        candles, close_ts = fetch_candles(m['ticker'], m['open_time'], m['close_time'], series='KXGOLD15M')
    except Exception:
        continue
    if not candles:
        continue
    records.append({
        'ticker': m['ticker'], 'open_time': m['open_time'], 'close_time': m['close_time'],
        'close_ts': close_ts, 'result': m['result'], 'candles': candles,
    })
    if (i + 1) % 200 == 0:
        print(f"  ...{i+1}/{len(markets)} processed, {len(records)} usable so far")

print(f"Done. {len(records)} usable records.")
with open('data_cache/kalshi_paths_KXGOLD15M.pkl', 'wb') as f:
    pickle.dump(records, f)
print("Saved to data_cache/kalshi_paths_KXGOLD15M.pkl")
