import argparse
import os
import pickle
import time

from src.kalshi_favorite_backtest import fetch_settled_markets, SERIES as DEFAULT_SERIES
from src.kalshi_favorite_sweep import fetch_candles

CACHE_DIR = os.path.join(os.path.dirname(__file__), "..", "data_cache")


def cache_path_for(series):
    return os.path.join(CACHE_DIR, f"kalshi_paths_{series}.pkl")


# kept for backward compatibility with existing BTC-only callers
CACHE_PATH = cache_path_for(DEFAULT_SERIES)


def fetch_and_cache(n_markets, series=DEFAULT_SERIES):
    cache_path = cache_path_for(series)
    print(f"Fetching last {n_markets} settled {series} markets...")
    markets = fetch_settled_markets(n_markets, series=series)
    print(f"Got {len(markets)} settled markets. Pulling full candle paths...")

    records = []
    for i, m in enumerate(markets):
        result = m.get("result")
        if result not in ("yes", "no"):
            continue
        try:
            candles, close_ts = fetch_candles(m["ticker"], m["open_time"], m["close_time"], series=series)
        except Exception as exc:
            print(f"  skipping {m['ticker']}: {exc}")
            continue
        if not candles:
            continue
        records.append({
            "ticker": m["ticker"],
            "open_time": m["open_time"],
            "close_time": m["close_time"],
            "close_ts": close_ts,
            "result": result,
            "candles": candles,
        })
        if (i + 1) % 100 == 0:
            print(f"  ...{i + 1}/{len(markets)} processed, {len(records)} usable")
            os.makedirs(CACHE_DIR, exist_ok=True)
            with open(cache_path, "wb") as f:
                pickle.dump(records, f)
        time.sleep(0.1)

    os.makedirs(CACHE_DIR, exist_ok=True)
    with open(cache_path, "wb") as f:
        pickle.dump(records, f)
    print(f"\nSaved {len(records)} market price paths to {cache_path}")
    return records


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-markets", type=int, default=4000)
    parser.add_argument("--series", default=DEFAULT_SERIES)
    args = parser.parse_args()
    fetch_and_cache(args.n_markets, series=args.series)
