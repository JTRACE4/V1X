"""Tests using the pullback-filtered wick signal as the ENTRY trigger for a momentum-
style ride-the-move strategy (buy on a confirmed shallow-pullback wick, exit via
trailing stop or hold to settlement) - vs. the existing momentum_jump entry, which
uses a plain close-to-close spot return."""
import argparse
import statistics

from src.kalshi_exit_sim import prices_from_candles, simulate_exit
from src.kalshi_momentum_backtest import load_records, build_spot_minute_map, simulate_momentum_trade
from src.kalshi_wick_exit_backtest import build_spot_maps, wick_signal

EPS = 1e-9
MIN_SECONDS_LEFT = 90
LOCK_IN, TRAIL, HARD_STOP = 0.03, 0.02, 0.01  # matches existing momentum_jump defaults


def simulate_wick_entry_trade(candles, close_ts, result, close_map, high_map, low_map,
                               wick_threshold, pullback_cutoff):
    prices = prices_from_candles(candles)
    if len(prices) < 3:
        return None

    for i, (ts, p) in enumerate(prices):
        if i == 0:
            continue
        if close_ts - ts < MIN_SECONDS_LEFT:
            break

        wr, ratio = wick_signal(ts, close_map, high_map, low_map)
        if wr is None or ratio is None or abs(wr) < wick_threshold or ratio > pullback_cutoff:
            continue

        side = "yes" if wr > 0 else "no"
        entry_price = p
        if entry_price <= 0.0 or entry_price >= 1.0:
            continue
        cost = entry_price if side == "yes" else (1 - entry_price)
        return simulate_exit(prices, i, cost, side, result, LOCK_IN, TRAIL, HARD_STOP)

    return None


def evaluate_wick_entry(records, close_map, high_map, low_map, wick_threshold, pullback_cutoff, bet_size):
    payoffs = []
    for r in records:
        out = simulate_wick_entry_trade(r["candles"], r["close_ts"], r["result"],
                                         close_map, high_map, low_map, wick_threshold, pullback_cutoff)
        if out is None:
            continue
        payoffs.append(out["payoff"])
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "coverage": n / len(records), "non_negative": non_negative,
            "avg_payoff": statistics.mean(payoffs) * bet_size}


def evaluate_existing_momentum(records, spot_map, jump_threshold, bet_size):
    payoffs = []
    for r in records:
        out = simulate_momentum_trade(r["candles"], r["close_ts"], r["result"], spot_map,
                                       jump_threshold, MIN_SECONDS_LEFT, LOCK_IN, TRAIL, HARD_STOP)
        if out is None:
            continue
        payoffs.append(out["payoff"])
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "coverage": n / len(records), "non_negative": non_negative,
            "avg_payoff": statistics.mean(payoffs) * bet_size}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bet-size", type=float, default=100.0)
    args = parser.parse_args()

    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.")
    close_map, high_map, low_map = build_spot_maps(records)
    spot_map = close_map  # existing momentum entry only needs closes
    print("Got spot maps.\n")

    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    print("=== existing momentum_jump entry (close-based), for reference ===")
    for jt in [0.0005, 0.0007, 0.0010]:
        res = evaluate_existing_momentum(records, spot_map, jt, args.bet_size)
        if res:
            print(f"  jump_thr={jt:.4f}: n={res['n']} coverage={res['coverage']:.1%} "
                  f"non-neg={res['non_negative']:.2%} avgPay/100={res['avg_payoff']:+.2f}")

    print("\n=== wick-entry variant: selecting params on TRAIN ===")
    best = None
    for wick_threshold in [0.0003, 0.0004, 0.0005]:
        for pullback_cutoff in [0.25, 0.5]:
            res = evaluate_wick_entry(train, close_map, high_map, low_map, wick_threshold, pullback_cutoff, args.bet_size)
            if res:
                print(f"  wick_thr={wick_threshold:.4f} pullback<={pullback_cutoff:.2f}: n={res['n']} "
                      f"coverage={res['coverage']:.1%} non-neg={res['non_negative']:.2%} "
                      f"avgPay/100={res['avg_payoff']:+.2f}")
                if best is None or res["non_negative"] > best[0]["non_negative"]:
                    best = (res, wick_threshold, pullback_cutoff)

    if best:
        _, wt, pc = best
        print(f"\n=== best on train: wick_thr={wt}, pullback<={pc} - validated on HOLDOUT ===")
        holdout_res = evaluate_wick_entry(test, close_map, high_map, low_map, wt, pc, args.bet_size)
        print(f"wick-entry on holdout: n={holdout_res['n']} coverage={holdout_res['coverage']:.1%} "
              f"non-neg={holdout_res['non_negative']:.2%} avgPay/100={holdout_res['avg_payoff']:+.2f}")

        print("\n=== existing momentum_jump on the SAME holdout, for direct comparison ===")
        for jt in [0.0005, 0.0007, 0.0010]:
            res = evaluate_existing_momentum(test, spot_map, jt, args.bet_size)
            if res:
                print(f"  jump_thr={jt:.4f}: n={res['n']} coverage={res['coverage']:.1%} "
                      f"non-neg={res['non_negative']:.2%} avgPay/100={res['avg_payoff']:+.2f}")


if __name__ == "__main__":
    main()
