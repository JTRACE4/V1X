import statistics

from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_path_backtest import load_records

THRESHOLDS = [0.80, 0.85, 0.90, 0.95]


def analyze(records, threshold):
    jump_sizes = []       # size of the single biggest 1-min move in the 3 minutes before crossing
    cumulative_moves = [] # total move from window start to crossing point
    pullback_depths = []  # how far confidence fell back after crossing, if it did
    pullback_count = 0
    reached_count = 0
    minutes_to_pullback_low = []

    for r in records:
        prices = prices_from_candles(r["candles"])
        if len(prices) < 4:
            continue

        confidences = [max(p, 1 - p) for _, p in prices]
        cross_idx = None
        for i, c in enumerate(confidences):
            if c >= threshold:
                cross_idx = i
                break
        if cross_idx is None:
            continue
        reached_count += 1

        # biggest single 1-min confidence jump in the run-up
        lookback = max(0, cross_idx - 3)
        run_up = confidences[lookback:cross_idx + 1]
        if len(run_up) >= 2:
            biggest_jump = max(run_up[i + 1] - run_up[i] for i in range(len(run_up) - 1))
            jump_sizes.append(biggest_jump)
        cumulative_moves.append(confidences[cross_idx] - confidences[0])

        # after crossing, find the lowest confidence point before window close
        rest = confidences[cross_idx + 1:]
        if rest:
            min_after = min(rest)
            min_after_idx = rest.index(min_after)
            depth = confidences[cross_idx] - min_after
            pullback_depths.append(depth)
            if depth >= 0.05:  # meaningful pullback: at least 5 points of confidence given back
                pullback_count += 1
                minutes_to_pullback_low.append(min_after_idx + 1)

    return {
        "threshold": threshold, "n_markets": len(records), "reached_count": reached_count,
        "reach_rate": reached_count / len(records) if records else 0,
        "avg_biggest_jump": statistics.mean(jump_sizes) if jump_sizes else None,
        "median_biggest_jump": statistics.median(jump_sizes) if jump_sizes else None,
        "avg_cumulative_move": statistics.mean(cumulative_moves) if cumulative_moves else None,
        "pullback_rate": pullback_count / reached_count if reached_count else 0,
        "avg_pullback_depth": statistics.mean(pullback_depths) if pullback_depths else None,
        "median_pullback_depth": statistics.median(pullback_depths) if pullback_depths else None,
        "avg_minutes_to_low": statistics.mean(minutes_to_pullback_low) if minutes_to_pullback_low else None,
    }


def main():
    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.\n")

    for threshold in THRESHOLDS:
        res = analyze(records, threshold)
        print(f"--- Confidence reaches >= {threshold:.0%} ---")
        print(f"  reached this level in {res['reached_count']}/{res['n_markets']} markets ({res['reach_rate']:.1%})")
        if res["avg_biggest_jump"] is not None:
            print(f"  biggest single 1-min jump in the run-up: avg {res['avg_biggest_jump']:.3f}, "
                  f"median {res['median_biggest_jump']:.3f} (confidence points, e.g. 0.10 = 10 cents)")
            print(f"  avg cumulative move from window start to crossing: {res['avg_cumulative_move']:.3f}")
        print(f"  of those, {res['pullback_rate']:.1%} pulled back by >=5pts afterward before settling")
        if res["avg_pullback_depth"] is not None:
            print(f"  avg pullback depth (all cases, incl. no pullback): {res['avg_pullback_depth']:.3f}, "
                  f"median {res['median_pullback_depth']:.3f}")
        if res["avg_minutes_to_low"] is not None:
            print(f"  avg time to reach the post-cross low: {res['avg_minutes_to_low']:.1f} minutes later")
        print()


if __name__ == "__main__":
    main()
