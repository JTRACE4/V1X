"""Tests whether real spot-market CHOPPINESS (how much BTC has bounced around
in both directions over the last few minutes, not just its net 1-min return)
predicts a reversal risk at entry. Distinct from every prior test: not Kalshi's
price, not Kalshi's trade flow, not spot volume, and not spot's single-minute
direction (already covered by the existing entry filter) - this measures
recent volatility/magnitude regardless of direction. Entirely local/cached
data, no live API calls needed."""
import argparse
import datetime as dt
import statistics

from src.data import fetch_history
from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records
from src.kalshi_adaptive_gap_backtest import adaptive_threshold

EPS = 1e-9


def build_price_map(records, symbol="BTC-USD"):
    open_times = [dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")) for r in records]
    span_start = min(open_times)
    days = (dt.datetime.now(dt.timezone.utc) - span_start).days + 2
    print(f"Loading {symbol} spot 1m data covering {days} days...")
    spot_df = fetch_history(symbol=symbol, interval="1m", days=days)
    spot_df["minute_ts"] = spot_df["open_time"] // 1000
    price_map = dict(zip(spot_df["minute_ts"], spot_df["close"]))
    print(f"Got {len(price_map)} spot minute bars.")
    return price_map


def recent_choppiness(price_map, entry_ts, lookback_minutes=4):
    """Sum of absolute 1-minute returns over the lookback window - high value
    means BTC has been bouncing around a lot (regardless of net direction),
    low value means it's been calm/trending smoothly."""
    minute_ts = int(entry_ts) // 60 * 60
    total_abs_ret = 0.0
    count = 0
    for i in range(lookback_minutes):
        ts = minute_ts - i * 60
        p_now = price_map.get(ts)
        p_prev = price_map.get(ts - 60)
        if p_now is not None and p_prev is not None and p_prev != 0:
            total_abs_ret += abs(p_now / p_prev - 1)
            count += 1
    if count == 0:
        return None
    return total_abs_ret


def simulate(candles, close_ts, result, price_map, entry_minutes, entry_filter_threshold,
             base_threshold, min_threshold, confidence_floor, choppiness_threshold, lookback_minutes):
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None

    window_start_ts = close_ts - entry_minutes * 60

    entry_idx = None
    if confidence_floor <= 0.5:
        for i, (ts, _) in enumerate(prices):
            if ts <= window_start_ts:
                entry_idx = i
            else:
                break
        if entry_idx is None:
            entry_idx = 0
    else:
        for i, (ts, p) in enumerate(prices):
            if ts < window_start_ts or ts >= close_ts:
                continue
            if max(p, 1 - p) >= confidence_floor:
                entry_idx = i
                break
        if entry_idx is None:
            return None

    if entry_idx >= len(prices) - 1:
        return None

    entry_ts, entry_price = prices[entry_idx]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    if choppiness_threshold is not None:
        chop = recent_choppiness(price_map, entry_ts, lookback_minutes)
        if chop is not None and chop > choppiness_threshold:
            return None

    if entry_filter_threshold is not None:
        spot_now = price_map.get(entry_ts)
        spot_prev = price_map.get(entry_ts - 60)
        if spot_now is not None and spot_prev is not None and spot_prev != 0:
            spot_ret = spot_now / spot_prev - 1
            adverse_at_entry = (side == "yes" and spot_ret <= -entry_filter_threshold) or \
                                (side == "no" and spot_ret >= entry_filter_threshold)
            if adverse_at_entry:
                return None

    for ts, p in prices[entry_idx + 1:]:
        confidence = max(p, 1 - p)
        threshold = adaptive_threshold(confidence, base_threshold, min_threshold)
        spot_now = price_map.get(ts)
        spot_prev = price_map.get(ts - 60)
        if spot_now is not None and spot_prev is not None and spot_prev != 0:
            spot_ret = spot_now / spot_prev - 1
            adverse = (side == "yes" and spot_ret <= -threshold) or \
                      (side == "no" and spot_ret >= threshold)
            if adverse:
                price_side_now = p if side == "yes" else (1 - p)
                return {"payoff": price_side_now - cost, "reason": "defensive_exit"}

    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff, "reason": "settlement"}


def evaluate(records, price_map, entry_minutes, entry_filter, base_threshold, min_threshold,
             confidence_floor, choppiness_threshold, lookback_minutes, bet_size=100.0):
    payoffs = []
    skipped = 0
    for r in records:
        out = simulate(r["candles"], r["close_ts"], r["result"], price_map, entry_minutes,
                        entry_filter, base_threshold, min_threshold, confidence_floor,
                        choppiness_threshold, lookback_minutes)
        if out is None:
            skipped += 1
            continue
        payoffs.append(out["payoff"])
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "skipped": skipped, "non_negative": non_negative,
            "avg_payoff": statistics.mean(payoffs) * bet_size,
            "total_payoff": sum(payoffs) * bet_size}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--entry-minutes", type=float, default=3.5)
    parser.add_argument("--entry-filter", type=float, default=0.00005)
    parser.add_argument("--base-threshold", type=float, default=0.00035)
    parser.add_argument("--min-threshold", type=float, default=0.00005)
    parser.add_argument("--confidence-floor", type=float, default=0.58)
    parser.add_argument("--lookback-minutes", type=int, default=4)
    parser.add_argument("--thresholds", type=str, default="0.0005,0.001,0.0015,0.002,0.003,0.005,0.008")
    args = parser.parse_args()

    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.")
    price_map = build_price_map(records)

    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    print("--- current setup (58% floor, no choppiness filter) baseline ---")
    for label, data in (("TRAIN", train), ("HOLDOUT", test)):
        res = evaluate(data, price_map, args.entry_minutes, args.entry_filter,
                        args.base_threshold, args.min_threshold, args.confidence_floor, None,
                        args.lookback_minutes)
        print(f"{label}: n={res['n']} non-neg={res['non_negative']:.2%} "
              f"avgPay/$100={res['avg_payoff']:+.2f} total=${res['total_payoff']:+.2f}")

    print(f"\n--- sweeping choppiness threshold on TRAIN (sum of |1min returns| over last "
          f"{args.lookback_minutes}min) ---")
    best = None
    for chop_threshold in [float(x) for x in args.thresholds.split(",")]:
        res = evaluate(train, price_map, args.entry_minutes, args.entry_filter,
                        args.base_threshold, args.min_threshold, args.confidence_floor,
                        chop_threshold, args.lookback_minutes)
        if res:
            print(f"  chop_threshold={chop_threshold:.4f}: n={res['n']} (skipped {res['skipped']}) "
                  f"non-neg={res['non_negative']:.2%} avgPay/$100={res['avg_payoff']:+.2f} "
                  f"total=${res['total_payoff']:+.2f}")
            if best is None or res["non_negative"] > best[0]["non_negative"]:
                best = (res, chop_threshold)

    if best:
        _, best_chop = best
        print(f"\n--- choppiness filter (threshold={best_chop}) validated on HOLDOUT ---")
        res = evaluate(test, price_map, args.entry_minutes, args.entry_filter,
                        args.base_threshold, args.min_threshold, args.confidence_floor,
                        best_chop, args.lookback_minutes)
        print(f"n={res['n']} (skipped {res['skipped']}) non-neg={res['non_negative']:.2%} "
              f"avgPay/$100={res['avg_payoff']:+.2f} total=${res['total_payoff']:+.2f}")


if __name__ == "__main__":
    main()
