import argparse
import datetime as dt
import os

import joblib

from src.data import fetch_history, drop_forming_candle, INTERVAL_MS
from src.features import add_features, LABEL_HORIZON_BARS

MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "models", "model.joblib")

# the year-long trend feature needs ~365 days of 5-minute history to compute
# even for a single live prediction; this makes predict.py a multi-minute call.
LOOKBACK_DAYS = 372


def predict(symbol=None, interval=None):
    bundle = joblib.load(MODEL_PATH)
    model = bundle["model"]
    feature_cols = bundle["features"]
    symbol = symbol or bundle["symbol"]
    interval = interval or bundle["interval"]

    raw = fetch_history(symbol=symbol, interval=interval, days=LOOKBACK_DAYS)
    raw = drop_forming_candle(raw, interval)

    df = add_features(raw)
    latest = df.iloc[[-1]]

    if latest[feature_cols].isna().any(axis=1).iloc[0]:
        raise RuntimeError("Not enough history to compute all features; increase fetch limit.")

    proba_up = model.predict_proba(latest[feature_cols])[0, 1]
    direction = "UP" if proba_up >= 0.5 else "DOWN"

    close_time_ms = int(latest["close_time"].iloc[0])
    candle_close = dt.datetime.fromtimestamp(close_time_ms / 1000, tz=dt.timezone.utc)
    target_time = candle_close + dt.timedelta(milliseconds=INTERVAL_MS[interval] * LABEL_HORIZON_BARS)

    print(f"Symbol:            {symbol}")
    print(f"Last closed candle: {candle_close} UTC (close={latest['close'].iloc[0]:.2f})")
    print(f"Predicting candle:  {target_time} UTC")
    print(f"Prediction:         {direction}")
    print(f"P(up):              {proba_up:.4f}")
    print(f"P(down):            {1 - proba_up:.4f}")

    return direction, proba_up


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbol", default=None)
    parser.add_argument("--interval", default=None)
    args = parser.parse_args()

    predict(symbol=args.symbol, interval=args.interval)
