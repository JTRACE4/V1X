"""Quick standalone check that KALSHI_API_KEY_ID + KALSHI_PRIVATE_KEY_PATH are a
matching pair, by making one authenticated read-only call (get balance). Places
no orders."""
import os

from src.kalshi_live_bot import KalshiClient, AUTH_BASE
import requests


def main():
    client = KalshiClient()
    path = "/trade-api/v2/portfolio/balance"
    resp = requests.get(AUTH_BASE + path.replace("/trade-api/v2", ""),
                         headers=client._headers("GET", path), timeout=20)
    if resp.status_code == 200:
        data = resp.json()
        print("SUCCESS - your API key and private key match.")
        print(f"Balance: {data}")
    else:
        print(f"FAILED - status {resp.status_code}")
        print(resp.text)
        print("\nThis usually means the private key file doesn't match the public "
              "key registered under this API Key ID.")


if __name__ == "__main__":
    main()
