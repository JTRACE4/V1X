"""Pressure-based protection for the dashboard's lock trades (asked
2026-10-03: "find the buying or selling pressure when you make a call and I
buy in ... sell out our position and buy the other way").

For every window the dashboard locked a call (intrawindow logs, Sep 24+):
  entry  = called side's real ask in the first 1-min Kalshi candle that
           closes after the lock, only if 58c-82c (the live buy rules)
  watch  = at each later candle close, Coinbase aggressive buy/sell volume
           over the last W seconds + spot move, signed toward the call
  exit   = when pressure AND spot move both turn against the call by the
           thresholds -> sell at the real bid (EXIT), or sell and buy the
           other side at its real ask and hold to settlement (FLIP)
Compared to plain hold-to-settlement, after Kalshi taker fees on every leg.
Thresholds are chosen on the first half of the dates and judged on the
second half only.
Data: data_cache/kalshi_paths_recent_*.pkl (src/fetch_recent_paths.py),
data_cache/flow_seconds_*.pkl (src/build_flow_seconds.py)."""
import datetime as dt
import itertools
import os
import pickle

import numpy as np
import pandas as pd

ROOT = os.path.join(os.path.dirname(__file__), "..")
MIN_PX, MAX_PX = 0.58, 0.82
ASSETS = {"BTC": ("KXBTC15M", "BTC-USD"), "XRP": ("KXXRP15M", "XRP-USD")}


def fee(p):
    return 0.07 * p * (1 - p)


def lock_times():
    """ticker -> (call, seconds_left at the dashboard's first lock)."""
    out = {}
    for f in ("intrawindow_price_log_v1_stale_quotes.csv", "intrawindow_price_log.csv"):
        d = pd.read_csv(os.path.join(ROOT, "bot_state", f), usecols=["ticker", "seconds_left", "locked_call"])
        d = d[d.locked_call.isin(["YES", "NO"])]
        first = d.groupby("ticker").agg(call=("locked_call", "first"), left=("seconds_left", "max"))
        for tk, r in first.iterrows():
            out.setdefault(tk, (r.call, r.left))
    return out


def side_quotes(c, side):
    """(ask, bid) for one side from a candle's yes_bid/yes_ask closes."""
    ya, yb = float(c["yes_ask"]["close_dollars"] or 0), float(c["yes_bid"]["close_dollars"] or 0)
    if side == "YES":
        return ya, yb
    return 1 - yb, 1 - ya


class Flow:
    def __init__(self, sym):
        df = pd.read_pickle(os.path.join(ROOT, "data_cache", f"flow_seconds_{sym}.pkl"))
        self.t = (df.index - pd.Timestamp("1970-01-01", tz="UTC")).total_seconds().to_numpy().astype(np.int64)
        self.cb = np.cumsum(df.buy_usd.to_numpy())
        self.cs = np.cumsum(df.sell_usd.to_numpy())
        self.px = df.price.to_numpy()

    def at(self, ts, w):
        """(imbalance in [-1,1], spot move in bps) over (ts-w, ts]."""
        i1 = np.searchsorted(self.t, ts, side="right") - 1
        i0 = np.searchsorted(self.t, ts - w, side="right") - 1
        if i1 < 0 or i0 < 0 or i1 <= i0 or ts - self.t[i1] > 30:
            return None
        b = self.cb[i1] - self.cb[i0]
        s = self.cs[i1] - self.cs[i0]
        if b + s <= 0:
            return None
        return (b - s) / (b + s), (self.px[i1] / self.px[i0] - 1) * 1e4


def build_trades(asset, locks):
    series, sym = ASSETS[asset]
    path = os.path.join(ROOT, "data_cache", f"kalshi_paths_recent_{series}.pkl")
    if not os.path.exists(path):
        return []
    paths = pickle.load(open(path, "rb"))
    flow = Flow(sym)
    trades = []
    for p in paths:
        if p["ticker"] not in locks:
            continue
        call, left = locks[p["ticker"]]
        close_ts = int(dt.datetime.fromisoformat(p["close_time"].replace("Z", "+00:00")).timestamp())
        lock_ts = close_ts - left
        candles = sorted(p["candles"], key=lambda c: c["end_period_ts"])
        after = [c for c in candles if c["end_period_ts"] >= lock_ts and c["end_period_ts"] < close_ts]
        if not after:
            continue
        ask, _ = side_quotes(after[0], call)
        if not (MIN_PX <= ask <= MAX_PX):
            continue
        sign = 1 if call == "YES" else -1
        later = []
        for c in after[1:]:
            ts = c["end_period_ts"]
            if close_ts - ts < 60:
                break
            feats = {w: flow.at(ts, w) for w in (30, 60, 120)}
            later.append((ts, c, feats))
        trades.append(dict(ticker=p["ticker"], asset=asset, call=call, entry=ask, sign=sign,
                           result=p["result"].upper(), close_ts=close_ts, later=later))
    return trades


def simulate(t, w, imb, bps, drop, mode):
    """P&L per contract for one trade under one rule. mode: HOLD/EXIT/FLIP."""
    e = t["entry"]
    won = t["call"] == t["result"]
    hold = (1.0 if won else 0.0) - e - fee(e)
    if mode == "HOLD":
        return hold, False
    for ts, c, feats in t["later"]:
        f = feats.get(w)
        if f is None:
            continue
        im, mv = f[0] * t["sign"], f[1] * t["sign"]  # + = supports the call
        ask, bid = side_quotes(c, t["call"])
        if im <= -imb and mv <= -bps and (e - bid) >= drop and bid > 0:
            pnl = bid - fee(bid) - e - fee(e)
            if mode == "FLIP":
                other = "NO" if t["call"] == "YES" else "YES"
                oask, _ = side_quotes(c, other)
                if 0 < oask < 1:
                    pnl += (1.0 if t["result"] == other else 0.0) - oask - fee(oask)
            return pnl, True
    return hold, False


def main():
    locks = lock_times()
    for asset in ASSETS:
        trades = build_trades(asset, locks)
        if not trades:
            print(asset, "no trades - fetch candles first")
            continue
        trades.sort(key=lambda t: t["close_ts"])
        mid = trades[len(trades) // 2]["close_ts"]
        halves = {"1st": [t for t in trades if t["close_ts"] < mid], "2nd": [t for t in trades if t["close_ts"] >= mid]}
        d0 = dt.datetime.fromtimestamp(trades[0]["close_ts"]).date()
        d1 = dt.datetime.fromtimestamp(trades[-1]["close_ts"]).date()
        dm = dt.datetime.fromtimestamp(mid).date()
        print(f"\n{'=' * 100}\n{asset}: {len(trades)} locked calls bought at 58-82c  ({d0} .. {d1}, 2nd half from {dm})")

        def score(ts, rule, mode):
            r = [simulate(t, *rule, mode) for t in ts]
            pnl = np.array([x[0] for x in r])
            cost = sum(t["entry"] + fee(t["entry"]) for t in ts)
            return pnl.sum() / cost, sum(x[1] for x in r), pnl.sum()

        base = {h: score(ts, (60, 0, 0, 0), "HOLD") for h, ts in halves.items()}
        print(f"  HOLD to settlement: 1st half ROI {base['1st'][0]:+6.1%} (n={len(halves['1st'])})   "
              f"2nd half ROI {base['2nd'][0]:+6.1%} (n={len(halves['2nd'])})")
        grid = list(itertools.product((30, 60, 120), (0.2, 0.4, 0.6, 0.8), (0, 2, 5, 10), (0, 0.10, 0.20)))
        for mode in ("EXIT", "FLIP"):
            res = []
            for rule in grid:
                r1 = score(halves["1st"], rule, mode)
                res.append((r1[0], rule, r1))
            res.sort(key=lambda x: -x[0])
            print(f"\n  {mode} - best 5 rules picked on the 1st half, then checked on the 2nd half:")
            for roi1, rule, r1 in res[:5]:
                r2 = score(halves["2nd"], rule, mode)
                w, imb, bps, drop = rule
                print(f"    last {w:>3}s pressure >= {imb:.0%} against + spot >= {bps:>2} bps against"
                      f" + down >= {drop * 100:>2.0f}c  |  1st: ROI {r1[0]:+6.1%} ({r1[1]} triggered)"
                      f"  2nd: ROI {r2[0]:+6.1%} ({r2[1]} triggered)  vs hold {base['2nd'][0]:+6.1%}")
        # how good is pressure as a warning at all? (calls that lost vs won)
        rows = []
        for t in trades:
            worst = min((f[60][0] * t["sign"] for _, _, f in t["later"] if f.get(60)), default=None)
            if worst is not None:
                rows.append((worst, t["call"] == t["result"]))
        R = pd.DataFrame(rows, columns=["worst_imb", "won"])
        R["bucket"] = pd.cut(R.worst_imb, [-1.01, -0.8, -0.6, -0.4, -0.2, 1.0])
        print("\n  Strongest 60s pressure AGAINST the call during the hold -> how often the call still won:")
        for b, g in R.groupby("bucket", observed=True):
            print(f"    {str(b):<16} n={len(g):>4}  call won {g.won.mean():.0%}")


if __name__ == "__main__":
    main()
