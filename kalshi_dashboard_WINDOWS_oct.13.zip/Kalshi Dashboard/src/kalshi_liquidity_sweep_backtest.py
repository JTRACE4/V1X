"""Tests whether a real spot-market "liquidity sweep" - price breaking past a
recent swing high/low (where resting stop-loss/limit orders cluster), a
classic precursor to a sharp reversal - predicts the kind of loss we've been
chasing all day. Distinct from every prior test: this is a structural,
level-based pattern (did price break a specific recent extreme), not a raw
magnitude/volume metric. Entirely local/cached spot data, no API calls."""
import argparse
import datetime as dt
import statistics

from src.data import fetch_history
from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records
from src.kalshi_adaptive_gap_backtest import adaptive_threshold

EPS = 1e-9
BASE_ENTRY_MINUTES = 3.5
BASE_THRESHOLD = 0.00035
BASE_MIN_THRESHOLD = 0.00005
BASE_CONFIDENCE_FLOOR = 0.58
BASE_STRICT_MARGIN = 0.0002


def build_price_map(records, symbol="BTC-USD"):
    open_times = [dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")) for r in records]
    span_start = min(open_times)
    days = (dt.datetime.now(dt.timezone.utc) - span_start).days + 2
    spot_df = fetch_history(symbol=symbol, interval="1m", days=days)
    spot_df["minute_ts"] = spot_df["open_time"] // 1000
    return dict(zip(spot_df["minute_ts"], spot_df["close"]))


def find_entry_idx(prices, close_ts, entry_minutes, confidence_floor):
    window_start_ts = close_ts - entry_minutes * 60
    if confidence_floor <= 0.5:
        entry_idx = None
        for i, (ts, _) in enumerate(prices):
            if ts <= window_start_ts:
                entry_idx = i
            else:
                break
        return entry_idx if entry_idx is not None else 0
    for i, (ts, p) in enumerate(prices):
        if ts < window_start_ts or ts >= close_ts:
            continue
        if max(p, 1 - p) >= confidence_floor:
            return i
    return None


def had_recent_sweep(price_map, entry_ts, lookback_minutes, recent_minutes, sweep_margin):
    """Was there a swing high/low (over the lookback window, excluding the
    most recent `recent_minutes`) that price then broke through within the
    most recent `recent_minutes`? That's the sweep - resting liquidity at the
    old extreme got triggered."""
    minute_ts = int(entry_ts) // 60 * 60
    older_prices = []
    for i in range(recent_minutes, lookback_minutes):
        p = price_map.get(minute_ts - i * 60)
        if p is not None:
            older_prices.append(p)
    if not older_prices:
        return None
    recent_high = max(older_prices)
    recent_low = min(older_prices)

    recent_prices = []
    for i in range(0, recent_minutes):
        p = price_map.get(minute_ts - i * 60)
        if p is not None:
            recent_prices.append(p)
    if not recent_prices:
        return None

    swept_up = max(recent_prices) > recent_high * (1 + sweep_margin)
    swept_down = min(recent_prices) < recent_low * (1 - sweep_margin)
    return swept_up or swept_down


def simulate(candles, close_ts, result, price_map, sweep_lookback, sweep_recent, sweep_margin, filter_on_sweep):
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None
    entry_idx = find_entry_idx(prices, close_ts, BASE_ENTRY_MINUTES, BASE_CONFIDENCE_FLOOR)
    if entry_idx is None or entry_idx >= len(prices) - 1:
        return None
    entry_ts, entry_price = prices[entry_idx]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    spot_now = price_map.get(entry_ts)
    spot_prev = price_map.get(entry_ts - 60)
    if spot_now is None or spot_prev is None or spot_prev == 0:
        return None
    spot_ret = spot_now / spot_prev - 1
    favorable = (side == "yes" and spot_ret >= BASE_STRICT_MARGIN) or (side == "no" and spot_ret <= -BASE_STRICT_MARGIN)
    if not favorable:
        return None

    if filter_on_sweep:
        swept = had_recent_sweep(price_map, entry_ts, sweep_lookback, sweep_recent, sweep_margin)
        if swept:
            return None

    for ts, p in prices[entry_idx + 1:]:
        confidence = max(p, 1 - p)
        threshold = adaptive_threshold(confidence, BASE_THRESHOLD, BASE_MIN_THRESHOLD)
        spot_now2 = price_map.get(ts)
        spot_prev2 = price_map.get(ts - 60)
        if spot_now2 is not None and spot_prev2 is not None and spot_prev2 != 0:
            spot_ret2 = spot_now2 / spot_prev2 - 1
            adverse = (side == "yes" and spot_ret2 <= -threshold) or (side == "no" and spot_ret2 >= threshold)
            if adverse:
                price_side_now = p if side == "yes" else (1 - p)
                return {"payoff": price_side_now - cost}
    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff}


def evaluate(records, price_map, sweep_lookback, sweep_recent, sweep_margin, filter_on_sweep, bet_size=100.0):
    payoffs = []
    for r in records:
        out = simulate(r["candles"], r["close_ts"], r["result"], price_map,
                        sweep_lookback, sweep_recent, sweep_margin, filter_on_sweep)
        if out is None:
            continue
        payoffs.append(out["payoff"])
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "non_negative": non_negative, "avg_payoff": statistics.mean(payoffs) * bet_size,
            "total_payoff": sum(payoffs) * bet_size}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--series", default="KXBTC15M")
    parser.add_argument("--symbol", default="BTC-USD")
    args = parser.parse_args()

    records = load_records(series=args.series)
    print(f"Loaded {len(records)} historical market price paths.")
    price_map = build_price_map(records, symbol=args.symbol)
    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    print("--- current deployed setup (floor + strict direction, no sweep filter) baseline ---")
    for label, data in (("TRAIN", train), ("HOLDOUT", test)):
        res = evaluate(data, price_map, 15, 3, 0.0005, False)
        print(f"{label}: n={res['n']} non-neg={res['non_negative']:.2%} avgPay/$100={res['avg_payoff']:+.2f} "
              f"total=${res['total_payoff']:+.2f}")

    print("\n--- sweeping sweep-detection params on TRAIN (lookback/recent/margin) ---")
    best = None
    configs = [
        (10, 2, 0.0003), (10, 2, 0.0005), (15, 3, 0.0003), (15, 3, 0.0005),
        (15, 5, 0.0005), (20, 5, 0.0005), (30, 5, 0.001), (30, 10, 0.001),
    ]
    for lookback, recent, margin in configs:
        res = evaluate(train, price_map, lookback, recent, margin, True)
        if res:
            print(f"  lookback={lookback}m recent={recent}m margin={margin}: n={res['n']} "
                  f"non-neg={res['non_negative']:.2%} avgPay/$100={res['avg_payoff']:+.2f} "
                  f"total=${res['total_payoff']:+.2f}")
            if best is None or res["non_negative"] > best[0]["non_negative"]:
                best = (res, lookback, recent, margin)

    if best:
        _, bl, br, bm = best
        print(f"\n--- sweep filter (lookback={bl}m recent={br}m margin={bm}) validated on HOLDOUT ---")
        res = evaluate(test, price_map, bl, br, bm, True)
        print(f"n={res['n']} non-neg={res['non_negative']:.2%} avgPay/$100={res['avg_payoff']:+.2f} "
              f"total=${res['total_payoff']:+.2f}")


if __name__ == "__main__":
    main()
