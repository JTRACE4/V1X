"""Supervisor: keeps the web dashboard running. The dashboard process has a
history of dying silently (unexplained, no traceback) - this just restarts
it whenever it exits, so it stays up while the user is away watching it.

Launch detached so it outlives the terminal/agent session, e.g.:
  powershell -Command "Start-Process python -ArgumentList '-m','src.keepalive_dashboard' -WorkingDirectory 'C:\\Users\\user\\projects\\crypto-15m-predictor' -WindowStyle Hidden"
Stop it by killing the python process running this module (and its child).

SINGLETON LOCK (added 2026-09-22): this machine has two separate Python
installs that can both satisfy a bare `pythonw` on PATH depending on timing
(the Startup-folder launcher and an interactive terminal can resolve to
different ones) - that silently produced TWO independent keepalive
supervisors, each launching its OWN dashboard process, both bound to the
same port. With real-money auto-buy live, that's not just a nuisance - two
independent dashboards could both decide to fire their own real order on
the same window (a double-buy). This process now refuses to start a second
time: it holds an exclusive OS-level lock on bot_state/keepalive.lock for
as long as it's alive. The lock is released automatically if the process
dies or crashes (it's tied to the open file handle, not written state), so
a stale lock can never block a legitimate restart - only an ACTUALLY
running second instance blocks a second one from starting.
"""
import datetime as dt
import os
import subprocess
import sys
import time

RESTART_DELAY_SECONDS = 3
LOG = "keepalive_dashboard_log.txt"
LOCK_PATH = os.path.join(os.path.dirname(__file__), "..", "bot_state", "keepalive.lock")


def log(msg):
    line = f"{dt.datetime.now().isoformat(timespec='seconds')}  {msg}"
    print(line, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def _acquire_singleton_lock():
    """Returns an open file handle holding the lock, or None if another
    instance already holds it. The CALLER must keep the returned handle
    referenced for the process's entire lifetime - closing it (or letting
    it get garbage collected) releases the lock early."""
    os.makedirs(os.path.dirname(LOCK_PATH), exist_ok=True)
    f = open(LOCK_PATH, "a+")
    try:
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        f.close()
        return None
    return f


def main():
    lock_handle = _acquire_singleton_lock()
    if lock_handle is None:
        log("another keepalive_dashboard is already running (lock held) - exiting, not starting a second one")
        sys.exit(1)
    log("keepalive starting")
    while True:
        log("launching dashboard")
        try:
            proc = subprocess.run([sys.executable, "-m", "src.kalshi_web_dashboard"])
            log(f"dashboard exited (code {proc.returncode})")
        except Exception as exc:  # noqa: BLE001 - supervisor must never itself die
            log(f"launch raised: {exc!r}")
        time.sleep(RESTART_DELAY_SECONDS)


if __name__ == "__main__":
    main()
