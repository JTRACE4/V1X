"""Test the friend's (a friend) bot ideas against OUR real data.

Data: bot_state/intrawindow_price_log.csv (per-poll Kalshi price + spot + strike
since 2026-09-24) joined to real Kalshi settlements in
data_cache/kalshi_dashboard_history.json.

Ideas tested (from friend_bot/.../fair_value.py and bot.py):
  1. Fair-value model: P(final 60s average >= strike) from spot, strike,
     realized volatility, using the settlement-average horizon.
  2. Using that fair value as a FILTER on our own lock entries.
  3. His entry rule run on our data (35-65c, >=6c edge after fees, momentum).
  4. His "chaos" volatility gate (60s range / 10s shock).
Everything is split by date: first half = TRAIN (pick thresholds), second
half = TEST (honest out-of-sample result).
"""
import json
import math
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.join(os.path.dirname(__file__), "..")
LOG = os.path.join(ROOT, "bot_state", "intrawindow_price_log.csv")
HIST = os.path.join(ROOT, "data_cache", "kalshi_dashboard_history.json")
SLIP = 0.01  # 1c worse than the logged price on entry (logged price isn't the ask)
FEE_RATE = 0.07
SETTLE_WINDOW = 60.0


def fee(p):
    return FEE_RATE * p * (1 - p)


def ncdf(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def effective_seconds(left, window=SETTLE_WINDOW):
    left = max(0.0, left)
    return left - window + window / 3 if left >= window else left ** 3 / (3 * window ** 2)


def load():
    df = pd.read_csv(LOG)
    df["ts"] = pd.to_datetime(df["ts"], format="ISO8601", utc=True, errors="coerce")
    df = df.dropna(subset=["ts"])
    df = df[df["asset"].isin(["BTC", "XRP"])].dropna(subset=["kalshi_price", "spot_price", "target"])
    df = df[(df["target"] > 0) & (df["spot_price"] > 0)]
    hist = json.load(open(HIST))
    outcome = {}
    for asset in ("BTC", "XRP"):
        for r in hist.get(asset, []):
            if r.get("actual_side") in ("YES", "NO"):
                outcome[r["ticker"]] = r["actual_side"]
    df["result"] = df["ticker"].map(outcome)
    df = df.dropna(subset=["result"]).sort_values(["asset", "ts"]).reset_index(drop=True)
    return df


def add_features(df):
    out = []
    for asset, g in df.groupby("asset"):
        g = g.copy()
        t = (g["ts"] - pd.Timestamp("1970-01-01", tz="UTC")).dt.total_seconds().to_numpy()
        p = g["spot_price"].to_numpy(float)
        s = pd.Series(p, index=pd.DatetimeIndex(g["ts"]))
        # realized vol per sqrt-second over the trailing 300s (friend's oracle)
        dt = np.diff(t, prepend=np.nan)
        r = np.diff(np.log(p), prepend=np.nan) / np.sqrt(np.where(dt > 0, dt, np.nan))
        r[(dt > 30) | ~np.isfinite(r)] = np.nan  # gaps between polls/restarts
        rs = pd.Series(r, index=s.index)
        sigma = rs.rolling("300s", min_periods=12).std().to_numpy()
        lo, hi = 1 / 1e4 / math.sqrt(60), 80 / 1e4 / math.sqrt(60)
        sigma = np.where(np.isfinite(sigma), np.clip(sigma, lo, hi), 8 / 1e4 / math.sqrt(60))
        g["sigma"] = sigma
        g["rng60_bps"] = ((s.rolling("60s").max() - s.rolling("60s").min()) / s * 1e4).to_numpy()
        # 12s momentum (friend: $5 on BTC ~0.6bps); use asof lookup to tolerate poll jitter
        lag = pd.Series(p, index=s.index).asof(s.index - pd.Timedelta(seconds=12)).to_numpy()
        g["mom12_bps"] = (p - lag) / p * 1e4
        lag10 = pd.Series(p, index=s.index).asof(s.index - pd.Timedelta(seconds=10)).to_numpy()
        g["mv10_bps"] = (p - lag10) / p * 1e4
        h = np.array([effective_seconds(x) for x in g["seconds_left"].to_numpy(float)])
        z = np.log(p / g["target"].to_numpy(float)) / (sigma * np.sqrt(np.maximum(h, 1e-9)))
        fy = np.clip(0.5 * (1 + np.vectorize(math.erf)(z / math.sqrt(2))), 0.005, 0.995)
        g["fair_yes"] = np.where(h > 0, fy, np.where(p >= g["target"], 0.995, 0.005))
        out.append(g)
    return pd.concat(out).sort_values("ts").reset_index(drop=True)


def side_price(row_price_yes, side):
    return row_price_yes if side == "YES" else 1 - row_price_yes


def pnl_per_contract(entry, won):
    return (1.0 if won else 0.0) - entry - fee(entry)


def summarize(name, trades):
    if len(trades) == 0:
        print(f"  {name:<52} n=   0")
        return
    n = len(trades)
    wr = trades["won"].mean()
    avg_px = trades["entry"].mean()
    roi = trades["pnl"].sum() / (trades["entry"] + trades["entry"].map(fee)).sum()
    print(f"  {name:<52} n={n:>4}  win={wr:6.1%}  avg entry={avg_px:5.2f}  "
          f"P&L/contract={trades['pnl'].mean():+.3f}  ROI={roi:+6.1%}  total(per $100 bet)=${roi*100*n:+8.0f}")


def main():
    df = add_features(load())
    days = sorted(df["ts"].dt.date.unique())
    split = days[len(days) // 2]
    df["half"] = np.where(df["ts"].dt.date < split, "TRAIN", "TEST")
    print(f"Rows: {len(df):,}  windows: {df['ticker'].nunique():,}  days: {days[0]}..{days[-1]}  "
          f"(TRAIN < {split} <= TEST)\n")

    # ---------- 1. Calibration: is Kalshi's price or his fair model closer to reality? ----------
    print("=" * 110)
    print("1. WHO PREDICTS BETTER - Kalshi's own price vs friend's fair-value model (all snapshots 60s-14min left)")
    c = df[(df["seconds_left"] > 60) & (df["seconds_left"] < 840)].copy()
    c["y"] = (c["result"] == "YES").astype(float)
    for asset in ("BTC", "XRP"):
        a = c[c["asset"] == asset]
        bk = ((a["kalshi_price"] - a["y"]) ** 2).mean()
        bf = ((a["fair_yes"] - a["y"]) ** 2).mean()
        bb = (((a["kalshi_price"] + a["fair_yes"]) / 2 - a["y"]) ** 2).mean()
        print(f"  {asset}: Brier (lower=better)  Kalshi={bk:.4f}  Fair model={bf:.4f}  50/50 blend={bb:.4f}   n={len(a):,}")
    print("\n  Favorite-side calibration (Kalshi price bucket -> how often the favorite actually won):")
    c["fav_px"] = np.maximum(c["kalshi_price"], 1 - c["kalshi_price"])
    c["fav_won"] = np.where(c["kalshi_price"] >= 0.5, c["y"], 1 - c["y"])
    c["fair_fav"] = np.where(c["kalshi_price"] >= 0.5, c["fair_yes"], 1 - c["fair_yes"])
    bins = [0.5, 0.6, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 1.0]
    for asset in ("BTC", "XRP"):
        a = c[c["asset"] == asset]
        t = a.groupby(pd.cut(a["fav_px"], bins), observed=True).agg(
            n=("fav_won", "size"), price=("fav_px", "mean"), actual=("fav_won", "mean"), fair=("fair_fav", "mean"))
        print(f"  {asset}:")
        for idx, r in t.iterrows():
            gap = r["actual"] - r["price"]
            print(f"    {str(idx):<12} n={int(r['n']):>6}  priced {r['price']:.3f}  actually won {r['actual']:.3f} "
                  f"({gap*100:+5.1f}c)   fair model said {r['fair']:.3f}")

    # ---------- 2. Our real lock entries, with/without his fair-value filter ----------
    print("\n" + "=" * 110)
    print("2. OUR LOCK ENTRIES (first snapshot each window where the dashboard locked a call), hold to settlement")
    locks = (df.dropna(subset=["locked_call"]).groupby("ticker", as_index=False).first())
    locks = locks[locks["locked_call"].isin(["YES", "NO"])].copy()
    locks["side_px"] = np.where(locks["locked_call"] == "YES", locks["kalshi_price"], 1 - locks["kalshi_price"])
    locks["entry"] = (locks["side_px"] + SLIP).clip(upper=0.99)
    locks["won"] = locks["locked_call"] == locks["result"]
    locks["pnl"] = [pnl_per_contract(e, w) for e, w in zip(locks["entry"], locks["won"])]
    locks["fair_side"] = np.where(locks["locked_call"] == "YES", locks["fair_yes"], 1 - locks["fair_yes"])
    locks["edge_c"] = (locks["fair_side"] - locks["entry"] - locks["entry"].map(fee)) * 100
    for half in ("TRAIN", "TEST", None):
        L = locks if half is None else locks[locks["half"] == half]
        label = half or "ALL"
        print(f"\n  --- {label} ---")
        for asset in ("BTC", "XRP"):
            A = L[L["asset"] == asset]
            for cap in (0.70, 0.82, 0.99):
                base = A[A["side_px"] <= cap]
                summarize(f"{asset} cap {cap:.2f}  (current rules)", base)
                for e in (-10, -5, 0, 3, 6):
                    summarize(f"{asset} cap {cap:.2f}  + fair edge >= {e:+d}c", base[base["edge_c"] >= e])
            gate = A[(A["side_px"] <= 0.82)]
            calm = gate[(gate["rng60_bps"] < gate["rng60_bps"].quantile(0.9))]
            summarize(f"{asset} cap 0.82  + chaos gate (skip top-10% 60s range)", calm)

    # ---------- 3. His entry rule on our data ----------
    print("\n" + "=" * 110)
    print("3. FRIEND'S ENTRY RULE ON OUR DATA: 35-65c, edge>=6c after fees, 12s momentum, spot on the right side,")
    print("   3min after open, not in last 90s. One entry per window. Hold vs. sell at 75c.")
    rows = []
    for tk, g in df.groupby("ticker"):
        g = g[(g["seconds_left"] > 90) & (g["seconds_left"] <= 720)]
        for side in ("YES", "NO"):
            px = g["kalshi_price"] if side == "YES" else 1 - g["kalshi_price"]
            fair = g["fair_yes"] if side == "YES" else 1 - g["fair_yes"]
            entry = (px + SLIP).clip(upper=0.99)
            edge = (fair - entry - entry.map(fee)) * 100
            mom_ok = g["mom12_bps"] >= 0.6 if side == "YES" else g["mom12_bps"] <= -0.6
            side_ok = g["spot_price"] >= g["target"] if side == "YES" else g["spot_price"] <= g["target"]
            calm = (g["rng60_bps"] < 8.3) & (g["mv10_bps"].abs() < 3.6)
            ok = (px >= 0.35) & (px <= 0.65) & (edge >= 6) & mom_ok & side_ok
            hit = g[ok]
            if len(hit):
                r = hit.iloc[0]
                e = min(0.99, (r["kalshi_price"] if side == "YES" else 1 - r["kalshi_price"]) + SLIP)
                later = g[g["ts"] > r["ts"]]
                lpx = later["kalshi_price"] if side == "YES" else 1 - later["kalshi_price"]
                hit75 = bool((lpx >= 0.75).any())
                won = r["result"] == side
                rows.append(dict(ticker=tk, asset=r["asset"], half=r["half"], ts=r["ts"], side=side, entry=e,
                                 won=won, pnl=pnl_per_contract(e, won),
                                 pnl75=((0.74 - e - fee(e) - fee(0.74)) if hit75 else pnl_per_contract(e, won)),
                                 calm=bool(calm.loc[r.name])))
    fr = pd.DataFrame(rows)
    if len(fr):
        fr = fr.sort_values("ts").groupby("ticker", as_index=False).first()  # one entry per window
        for half in ("TRAIN", "TEST", None):
            F = fr if half is None else fr[fr["half"] == half]
            print(f"\n  --- {half or 'ALL'} ---")
            for asset in ("BTC", "XRP"):
                A = F[F["asset"] == asset]
                summarize(f"{asset} his rule, hold to settlement", A)
                B = A.assign(pnl=A["pnl75"])
                summarize(f"{asset} his rule, sell when price reaches 75c", B)
                summarize(f"{asset} his rule + chaos gate, hold", A[A["calm"]])
    fr.to_csv(os.path.join(ROOT, "friend_bot", "friend_rule_trades_on_our_data.csv"), index=False)
    locks.to_csv(os.path.join(ROOT, "friend_bot", "our_locks_with_fair_value.csv"), index=False)


if __name__ == "__main__":
    pd.set_option("display.width", 200)
    sys.exit(main())
