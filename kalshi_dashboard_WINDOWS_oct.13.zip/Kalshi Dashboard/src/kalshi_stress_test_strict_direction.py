"""Stress-tests combo_floor_plus_spot_direction_strict against a genuinely
FRESH, independent batch of markets (not the cached 3994-market historical
set the original test used) - specifically including the recent period that
kalshi_flow_defensive_exit_continuous found to be underperforming the
historical average (85-88% non-neg vs the usual ~98%). If the filter's
advantage survives against that tougher recent stretch, that's real evidence.
Saves the fresh batch to its own cache file - does NOT touch the master
kalshi_paths_KXBTC15M.pkl cache."""
import os
import pickle
import time

from src.kalshi_favorite_backtest import fetch_settled_markets
from src.kalshi_favorite_sweep import fetch_candles
from src.kalshi_research_agent import build_price_map, simulate_strict_direction, simulate_joint, evaluate, \
    BASE_ENTRY_MINUTES, BASE_CONFIDENCE_FLOOR

CACHE_DIR = os.path.join(os.path.dirname(__file__), "..", "data_cache")
STRESS_CACHE_PATH = os.path.join(CACHE_DIR, "kalshi_paths_KXBTC15M_stress_test.pkl")


def fetch_fresh_batch(n_markets=600):
    print(f"Fetching {n_markets} fresh settled KXBTC15M markets (independent of the main cache)...")
    markets = fetch_settled_markets(n_markets, series="KXBTC15M")
    print(f"Got {len(markets)} settled markets. Pulling full candle paths...")

    records = []
    for i, m in enumerate(markets):
        result = m.get("result")
        if result not in ("yes", "no"):
            continue
        try:
            candles, close_ts = fetch_candles(m["ticker"], m["open_time"], m["close_time"], series="KXBTC15M")
        except Exception as exc:
            print(f"  skipping {m['ticker']}: {exc}")
            continue
        if not candles:
            continue
        records.append({
            "ticker": m["ticker"], "open_time": m["open_time"], "close_time": m["close_time"],
            "close_ts": close_ts, "result": result, "candles": candles,
        })
        if (i + 1) % 100 == 0:
            print(f"  ...{i + 1}/{len(markets)} processed, {len(records)} usable")
            os.makedirs(CACHE_DIR, exist_ok=True)
            with open(STRESS_CACHE_PATH, "wb") as f:
                pickle.dump(records, f)
        time.sleep(0.1)

    os.makedirs(CACHE_DIR, exist_ok=True)
    with open(STRESS_CACHE_PATH, "wb") as f:
        pickle.dump(records, f)
    print(f"\nSaved {len(records)} fresh market price paths to {STRESS_CACHE_PATH}")
    return records


def main():
    if os.path.exists(STRESS_CACHE_PATH):
        with open(STRESS_CACHE_PATH, "rb") as f:
            records = pickle.load(f)
        print(f"Loaded {len(records)} already-cached fresh markets.")
    else:
        records = fetch_fresh_batch(600)

    if len(records) < 50:
        print("Too few usable records to stress-test.")
        return

    price_map = build_price_map(records, symbol="BTC-USD")

    print(f"\n=== Stress test on {len(records)} FRESH, independent markets ===\n")

    baseline = evaluate(records, price_map,
                         lambda c, cl, r, pm, m=None: simulate_joint(c, cl, r, pm, BASE_ENTRY_MINUTES, BASE_CONFIDENCE_FLOOR),
                         None)
    print(f"Current deployed setting (3.5min/58% floor, no strict direction): n={baseline['n']} "
          f"non-neg={baseline['non_negative']:.2%} avgPay/$100={baseline['avg_payoff']:+.2f} "
          f"total=${baseline['total_payoff']:+.2f}")

    strict = evaluate(records, price_map,
                       lambda c, cl, r, pm, m=0.0002: simulate_strict_direction(c, cl, r, pm, m), 0.0002)
    print(f"Strict direction filter (margin=0.0002) on fresh data:      n={strict['n']} "
          f"non-neg={strict['non_negative']:.2%} avgPay/$100={strict['avg_payoff']:+.2f} "
          f"total=${strict['total_payoff']:+.2f}")


if __name__ == "__main__":
    main()
