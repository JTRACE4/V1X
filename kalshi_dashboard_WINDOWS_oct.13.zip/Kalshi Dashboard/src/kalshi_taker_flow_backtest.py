"""Tests whether order-FLOW imbalance (who's aggressively trading which side,
and how much size) in the ~60 seconds before entry predicts a reversal - closer
to what a human watching the tape would read than raw price movement alone.
Kalshi doesn't store historical order book snapshots (confirmed: querying a
settled market's orderbook returns empty), but individual trades DO carry
taker_side and count_fp historically, which is the next best thing: it shows
who was aggressively taking liquidity and how hard, not just where price sat.
Buy-and-hold-to-settlement only, to isolate the entry-quality signal cleanly."""
import argparse
import datetime as dt
import statistics
import time

from src.kalshi_favorite_backtest import BASE, _get, fetch_settled_markets

EPS = 1e-9


def fetch_trades_anchored(ticker, anchor_ts, lookback_seconds=65, max_pages=8, page_limit=1000):
    cursor = None
    collected = []
    for _ in range(max_pages):
        params = {"ticker": ticker, "limit": page_limit}
        if cursor:
            params["cursor"] = cursor
        data = _get(f"{BASE}/markets/trades", params=params)
        trades = data.get("trades", [])
        cursor = data.get("cursor")
        if not trades:
            break
        for t in trades:
            ts = dt.datetime.fromisoformat(t["created_time"].replace("Z", "+00:00")).timestamp()
            collected.append({
                "ts": ts,
                "price": float(t["yes_price_dollars"]),
                "count": float(t.get("count_fp", 0) or 0),
                "taker_side": t.get("taker_side"),
            })
        oldest = min(x["ts"] for x in collected)
        if oldest <= anchor_ts - lookback_seconds or not cursor:
            break
    if not collected:
        return None
    oldest = min(x["ts"] for x in collected)
    if oldest > anchor_ts - lookback_seconds:
        return None
    collected.sort(key=lambda x: x["ts"])
    return collected


def price_at_or_before(trades, ts):
    eligible = [t for t in trades if t["ts"] <= ts]
    return eligible[-1]["price"] if eligible else None


def net_taker_flow(trades, start_ts, end_ts):
    """Positive = net yes-side aggression, negative = net no-side aggression,
    in contracts. This is the signal a human reading order flow would use."""
    net = 0.0
    for t in trades:
        if start_ts <= t["ts"] <= end_ts:
            if t["taker_side"] == "yes":
                net += t["count"]
            elif t["taker_side"] == "no":
                net -= t["count"]
    return net


def evaluate_market(m, entry_minutes=3.5, flow_lookback=60):
    result = m.get("result")
    if result not in ("yes", "no"):
        return None
    ticker = m["ticker"]
    close_ts = dt.datetime.fromisoformat(m["close_time"].replace("Z", "+00:00")).timestamp()
    entry_ts = close_ts - entry_minutes * 60

    trades = fetch_trades_anchored(ticker, entry_ts, lookback_seconds=flow_lookback + 5)
    if trades is None:
        return None

    entry_price = price_at_or_before(trades, entry_ts)
    if entry_price is None or entry_price == 0.5:
        return None

    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)
    payoff = (1 - cost) if side == result else -cost

    flow = net_taker_flow(trades, entry_ts - flow_lookback, entry_ts)
    # flow_against_side: positive means recent aggressive flow is running
    # AGAINST the side we're about to buy (a live warning sign)
    flow_against_side = -flow if side == "yes" else flow

    return {"payoff": payoff, "flow_against_side": flow_against_side, "entry_price": entry_price}


def evaluate(records, flow_threshold, bet_size=100.0):
    payoffs = []
    skipped = 0
    for r in records:
        if flow_threshold is not None and r["flow_against_side"] > flow_threshold:
            skipped += 1
            continue
        payoffs.append(r["payoff"])
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "skipped": skipped, "non_negative": non_negative,
            "avg_payoff": statistics.mean(payoffs) * bet_size,
            "total_payoff": sum(payoffs) * bet_size}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-markets", type=int, default=1000)
    parser.add_argument("--entry-minutes", type=float, default=3.5)
    parser.add_argument("--flow-lookback", type=float, default=60)
    args = parser.parse_args()

    print(f"Fetching last {args.n_markets} settled KXBTC15M markets...")
    markets = fetch_settled_markets(args.n_markets, series="KXBTC15M")
    print(f"Got {len(markets)} settled markets. Pulling taker-flow data at each entry point...")

    records = []
    skipped_too_busy = 0
    for i, m in enumerate(markets):
        try:
            out = evaluate_market(m, args.entry_minutes, args.flow_lookback)
        except Exception:
            out = None
        if out is None:
            skipped_too_busy += 1
        else:
            records.append(out)
        if (i + 1) % 100 == 0:
            print(f"  ...{i + 1}/{len(markets)} processed, {len(records)} usable so far")
        time.sleep(0.1)

    print(f"\nUsable records: {len(records)} (skipped/no-data: {skipped_too_busy})\n")

    split = int(len(records) * 0.8)
    train, test = records[:split], records[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    print("--- baseline (no flow filter) ---")
    for label, data in (("TRAIN", train), ("HOLDOUT", test)):
        res = evaluate(data, None)
        print(f"{label}: n={res['n']} non-neg={res['non_negative']:.2%} "
              f"avgPay/$100={res['avg_payoff']:+.2f} total=${res['total_payoff']:+.2f}")

    print("\n--- sweeping 'flow against our side' threshold on TRAIN ---")
    print("(flow measured in contracts of net taker aggression in the 60s before entry)")
    best = None
    for flow_threshold in [50, 100, 200, 500, 1000, 2000, 5000]:
        res = evaluate(train, flow_threshold)
        if res:
            print(f"  flow_threshold={flow_threshold}: n={res['n']} (skipped {res['skipped']}) "
                  f"non-neg={res['non_negative']:.2%} avgPay/$100={res['avg_payoff']:+.2f} "
                  f"total=${res['total_payoff']:+.2f}")
            if best is None or res["non_negative"] > best[0]["non_negative"]:
                best = (res, flow_threshold)

    if best:
        _, best_flow = best
        print(f"\n--- taker-flow filter (threshold={best_flow}) validated on HOLDOUT ---")
        res = evaluate(test, best_flow)
        print(f"n={res['n']} (skipped {res['skipped']}) non-neg={res['non_negative']:.2%} "
              f"avgPay/$100={res['avg_payoff']:+.2f} total=${res['total_payoff']:+.2f}")


if __name__ == "__main__":
    main()
