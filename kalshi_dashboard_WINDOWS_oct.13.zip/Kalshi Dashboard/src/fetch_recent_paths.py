"""Fetch 1-minute Kalshi candles (real yes_bid/yes_ask) for the most recent
settled windows into NEW cache files (never overwrites the older
kalshi_paths_*.pkl - keep all data). Added 2026-10-03 for the pressure-exit
backtest, which needs Kalshi prices overlapping the Coinbase tick logs
(ticks start 2026-08-02; the older path caches end 2026-08-01)."""
import os
import pickle
import sys
import time

from src.kalshi_favorite_backtest import fetch_settled_markets
from src.kalshi_favorite_sweep import fetch_candles

CACHE_DIR = os.path.join(os.path.dirname(__file__), "..", "data_cache")


def run(series, n):
    path = os.path.join(CACHE_DIR, f"kalshi_paths_recent_{series}.pkl")
    have = {}
    if os.path.exists(path):
        have = {r["ticker"]: r for r in pickle.load(open(path, "rb"))}
    markets = fetch_settled_markets(n, series=series)
    print(f"{series}: {len(markets)} settled markets, {len(have)} already cached", flush=True)
    for i, m in enumerate(markets):
        if m["ticker"] in have or m.get("result") not in ("yes", "no"):
            continue
        try:
            candles, close_ts = fetch_candles(m["ticker"], m["open_time"], m["close_time"], series=series)
        except Exception as exc:
            print(f"  skip {m['ticker']}: {exc}", flush=True)
            continue
        if candles:
            have[m["ticker"]] = {"ticker": m["ticker"], "open_time": m["open_time"],
                                 "close_time": m["close_time"], "close_ts": close_ts,
                                 "result": m["result"], "floor_strike": m.get("floor_strike"),
                                 "candles": candles}
        if (i + 1) % 100 == 0:
            pickle.dump(list(have.values()), open(path, "wb"))
            print(f"  {i + 1}/{len(markets)}", flush=True)
        time.sleep(0.35)  # gentle - the live dashboard shares this IP's rate limit
    pickle.dump(list(have.values()), open(path, "wb"))
    print(f"{series}: saved {len(have)} -> {path}", flush=True)


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 1000
    for s in ("KXBTC15M", "KXXRP15M"):
        run(s, n)
