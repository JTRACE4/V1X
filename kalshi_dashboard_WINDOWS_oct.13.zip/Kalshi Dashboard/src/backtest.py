import argparse

import numpy as np

from src.features import FEATURE_COLUMNS, LABEL_HORIZON_BARS
from src.train import train

FEE_RATE = 0.0004  # ~0.04% per side, adjust to your exchange's taker fee


def simulate(model, test_df, up_threshold=0.55, down_threshold=0.45, fee_rate=FEE_RATE):
    # The label looks LABEL_HORIZON_BARS bars ahead (15 minutes). Stepping by
    # that stride gives non-overlapping decision points, one per holding period,
    # instead of re-betting on the same 15-minute window every 5 minutes.
    df = test_df.iloc[::LABEL_HORIZON_BARS].copy()
    proba_up = model.predict_proba(df[FEATURE_COLUMNS])[:, 1]
    df["proba_up"] = proba_up

    position = np.where(proba_up > up_threshold, 1, np.where(proba_up < down_threshold, -1, 0))
    df["position"] = position

    next_ret = df["close"].shift(-1) / df["close"] - 1
    df["next_ret"] = next_ret

    position_change = np.abs(np.diff(np.concatenate([[0], position])))
    fees = position_change * fee_rate

    strategy_ret = position * next_ret - fees
    df["strategy_ret"] = strategy_ret

    df = df.iloc[:-1]  # last row has no next_ret

    cum_strategy = (1 + df["strategy_ret"]).cumprod()
    cum_buy_hold = (1 + df["next_ret"]).cumprod()

    n_trades = int((position_change > 0).sum())
    total_return = cum_strategy.iloc[-1] - 1 if len(cum_strategy) else 0.0
    buy_hold_return = cum_buy_hold.iloc[-1] - 1 if len(cum_buy_hold) else 0.0

    running_max = cum_strategy.cummax()
    drawdown = (cum_strategy - running_max) / running_max
    max_drawdown = drawdown.min() if len(drawdown) else 0.0

    return {
        "n_periods": len(df),
        "n_trades": n_trades,
        "total_return": total_return,
        "buy_hold_return": buy_hold_return,
        "max_drawdown": max_drawdown,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbol", default="BTC-USD")
    parser.add_argument("--interval", default="5m")
    parser.add_argument("--days", type=int, default=4300)
    parser.add_argument("--up-threshold", type=float, default=0.55)
    parser.add_argument("--down-threshold", type=float, default=0.45)
    args = parser.parse_args()

    model, test_df = train(symbol=args.symbol, interval=args.interval, days=args.days)
    stats = simulate(model, test_df, up_threshold=args.up_threshold, down_threshold=args.down_threshold)

    print("\n--- Backtest (holdout period only, fees included) ---")
    for k, v in stats.items():
        print(f"{k}: {v}")
