"""Tests a TRAILING stop on close_favorite (distinct from the flat take-profit
already ruled out): let the position run, track its peak unrealized profit, and
only sell if it gives back a meaningful amount from that peak - rather than
selling the instant it crosses a fixed level."""
import argparse
import statistics

from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_path_backtest import load_records

EPS = 1e-9


def simulate(candles, close_ts, result, entry_minutes, lock_in, trail):
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None

    entry_ts = close_ts - entry_minutes * 60
    entry_idx = None
    for i, (ts, _) in enumerate(prices):
        if ts <= entry_ts:
            entry_idx = i
        else:
            break
    if entry_idx is None:
        entry_idx = 0
    if entry_idx >= len(prices) - 1:
        return None

    entry_price = prices[entry_idx][1]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    peak_payoff = 0.0
    for ts, p in prices[entry_idx + 1:]:
        price_side_now = p if side == "yes" else (1 - p)
        payoff_now = price_side_now - cost
        peak_payoff = max(peak_payoff, payoff_now)

        if peak_payoff >= lock_in and payoff_now <= peak_payoff - trail:
            return {"payoff": payoff_now, "reason": "trailing_stop"}

    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff, "reason": "settlement"}


def evaluate(records, entry_minutes, lock_in, trail, bet_size=100.0):
    payoffs = []
    reasons = {"trailing_stop": 0, "settlement": 0}
    for r in records:
        out = simulate(r["candles"], r["close_ts"], r["result"], entry_minutes, lock_in, trail)
        if out is None:
            continue
        payoffs.append(out["payoff"])
        reasons[out["reason"]] += 1
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "non_negative": non_negative,
            "avg_payoff": statistics.mean(payoffs) * bet_size, "reasons": reasons}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--entry-minutes", type=float, default=3)
    args = parser.parse_args()

    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.\n")

    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    print("--- baseline: hold to settlement ---")
    baseline = evaluate(records, args.entry_minutes, 999, 999)
    print(f"n={baseline['n']} non-neg={baseline['non_negative']:.2%} avgPay/$100={baseline['avg_payoff']:+.2f}\n")

    print("--- selecting best trailing-stop params on TRAIN ---")
    best = None
    for lock_in in [0.01, 0.02, 0.03, 0.05, 0.08]:
        for trail in [0.01, 0.02, 0.03, 0.05]:
            if trail > lock_in:
                continue
            res = evaluate(train, args.entry_minutes, lock_in, trail)
            if res:
                if best is None or res["non_negative"] > best[0]["non_negative"]:
                    best = (res, lock_in, trail)

    res, lock_in, trail = best
    print(f"best on train: lock_in={lock_in} trail={trail}")
    print(f"  n={res['n']} non-neg={res['non_negative']:.2%} avgPay/$100={res['avg_payoff']:+.2f} reasons={res['reasons']}\n")

    print(f"--- trailing stop (lock_in={lock_in}, trail={trail}) validated on HOLDOUT ---")
    baseline_test = evaluate(test, args.entry_minutes, 999, 999)
    trail_test = evaluate(test, args.entry_minutes, lock_in, trail)
    print(f"hold-only holdout:      n={baseline_test['n']} non-neg={baseline_test['non_negative']:.2%} "
          f"avgPay/$100={baseline_test['avg_payoff']:+.2f}")
    print(f"trailing stop holdout:  n={trail_test['n']} non-neg={trail_test['non_negative']:.2%} "
          f"avgPay/$100={trail_test['avg_payoff']:+.2f} reasons={trail_test['reasons']}")


if __name__ == "__main__":
    main()
