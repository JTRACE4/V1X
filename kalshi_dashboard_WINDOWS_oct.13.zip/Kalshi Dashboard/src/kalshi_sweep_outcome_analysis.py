"""For every real liquidity sweep event found in the historical data: what side
became favored immediately after the sweep, and did that side actually win at
settlement? Broken down by how much time was left when the sweep happened,
since a late sweep (little time left to reverse again) should be more
reliable than an early one if the concept holds at all."""
import argparse
import datetime as dt
import statistics
from collections import defaultdict

from src.data import fetch_history
from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records


def build_price_map(records, symbol="BTC-USD"):
    open_times = [dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")) for r in records]
    span_start = min(open_times)
    days = (dt.datetime.now(dt.timezone.utc) - span_start).days + 2
    spot_df = fetch_history(symbol=symbol, interval="1m", days=days)
    spot_df["minute_ts"] = spot_df["open_time"] // 1000
    return dict(zip(spot_df["minute_ts"], spot_df["close"]))


def find_sweeps_in_market(price_map, open_ts, close_ts, lookback_minutes=10, sweep_margin=0.0005):
    """Scans minute-by-minute through the market's life. At each minute,
    checks whether price just broke a swing high/low from the preceding
    lookback window. Returns a list of (minute_offset_from_open, seconds_left,
    swept_direction) for every sweep detected."""
    sweeps = []
    minute = int(open_ts) // 60 * 60
    end = int(close_ts) // 60 * 60
    while minute <= end:
        older = []
        for i in range(1, lookback_minutes + 1):
            p = price_map.get(minute - i * 60)
            if p is not None:
                older.append(p)
        current = price_map.get(minute)
        if len(older) >= 3 and current is not None:
            recent_high = max(older)
            recent_low = min(older)
            if current > recent_high * (1 + sweep_margin):
                sweeps.append((minute, close_ts - minute, "up"))
            elif current < recent_low * (1 - sweep_margin):
                sweeps.append((minute, close_ts - minute, "down"))
        minute += 60
    return sweeps


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--series", default="KXBTC15M")
    parser.add_argument("--symbol", default="BTC-USD")
    parser.add_argument("--lookback-minutes", type=int, default=10)
    parser.add_argument("--sweep-margin", type=float, default=0.0005)
    args = parser.parse_args()

    records = load_records(series=args.series)
    print(f"Loaded {len(records)} historical market price paths.")
    price_map = build_price_map(records, symbol=args.symbol)

    # bucket outcomes by how much time was left (seconds) when the sweep happened
    buckets = defaultdict(lambda: {"holds": 0, "reverses": 0})
    total_sweeps = 0
    markets_with_sweep = 0

    for r in records:
        result = r["result"]
        if result not in ("yes", "no"):
            continue
        open_ts = dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")).timestamp()
        close_ts = r["close_ts"]
        sweeps = find_sweeps_in_market(price_map, open_ts, close_ts, args.lookback_minutes, args.sweep_margin)
        if sweeps:
            markets_with_sweep += 1
        for minute, seconds_left, direction in sweeps:
            total_sweeps += 1
            # "up" sweep -> spot favored higher -> if BTC/ETH itself trends up,
            # that generally corresponds to "yes" becoming more likely on
            # Kalshi (up/down market), matching direction to result directly
            favored_side = "yes" if direction == "up" else "no"
            minutes_left = seconds_left / 60
            if minutes_left <= 2:
                bucket = "0-2min left"
            elif minutes_left <= 5:
                bucket = "2-5min left"
            elif minutes_left <= 8:
                bucket = "5-8min left"
            else:
                bucket = "8min+ left"
            if favored_side == result:
                buckets[bucket]["holds"] += 1
            else:
                buckets[bucket]["reverses"] += 1

    print(f"\n{markets_with_sweep}/{len(records)} markets had at least one detected sweep "
          f"({markets_with_sweep/len(records):.1%})")
    print(f"{total_sweeps} total sweep events detected\n")

    print(f"{'time left when swept':>20} | {'n':>6} | {'held (won)':>10} | {'reversed (lost)':>15}")
    order = ["0-2min left", "2-5min left", "5-8min left", "8min+ left"]
    for bucket in order:
        if bucket not in buckets:
            continue
        b = buckets[bucket]
        n = b["holds"] + b["reverses"]
        hold_rate = b["holds"] / n if n else 0
        print(f"{bucket:>20} | {n:>6} | {hold_rate:>9.1%} | {1-hold_rate:>14.1%}")

    total_holds = sum(b["holds"] for b in buckets.values())
    total_n = sum(b["holds"] + b["reverses"] for b in buckets.values())
    print(f"\nOVERALL: {total_holds}/{total_n} post-sweep favorites held through to settlement "
          f"({total_holds/total_n:.1%})" if total_n else "no data")


if __name__ == "__main__":
    main()
