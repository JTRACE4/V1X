"""Tests a proposed late-window panic exit: in the final ~40 seconds, if
Kalshi's own price is within N percentage points of 50% (a genuine toss-up,
not yet decided) AND has been trending TOWARD 50% (getting less certain, not
more) over the last few seconds, exit any held position immediately -
regardless of what the normal defensive-exit/hard-floor logic says. Uses
real millisecond-precision trade data, not 1-min candles, since a 30-40
second window needs that precision to test honestly."""
import argparse
import datetime as dt
import statistics
import time

from src.kalshi_favorite_backtest import BASE, _get, fetch_settled_markets

EPS = 1e-9
ENTRY_MINUTES = 3.5


def fetch_trades_full_window(ticker, close_ts, lookback_seconds=300, max_pages=10, page_limit=1000):
    cursor = None
    collected = []
    for _ in range(max_pages):
        params = {"ticker": ticker, "limit": page_limit}
        if cursor:
            params["cursor"] = cursor
        data = _get(f"{BASE}/markets/trades", params=params)
        trades = data.get("trades", [])
        cursor = data.get("cursor")
        if not trades:
            break
        for t in trades:
            ts = dt.datetime.fromisoformat(t["created_time"].replace("Z", "+00:00")).timestamp()
            if ts < close_ts - lookback_seconds - 5:
                continue
            collected.append((ts, float(t["yes_price_dollars"])))
        oldest = min((ts for ts, _ in collected), default=close_ts)
        if oldest <= close_ts - lookback_seconds or not cursor:
            break
    if not collected:
        return None
    oldest = min(ts for ts, _ in collected)
    if oldest > close_ts - lookback_seconds + 5:
        return None
    collected.sort()
    return collected


def price_at_or_before(trades, ts):
    eligible = [(t, p) for t, p in trades if t <= ts]
    return eligible[-1][1] if eligible else None


def simulate_market(m, entry_minutes, panic_window_seconds, toss_up_band, trend_check_seconds):
    result = m.get("result")
    if result not in ("yes", "no"):
        return None
    ticker = m["ticker"]
    close_ts = dt.datetime.fromisoformat(m["close_time"].replace("Z", "+00:00")).timestamp()
    entry_ts = close_ts - entry_minutes * 60

    trades = fetch_trades_full_window(ticker, close_ts, lookback_seconds=entry_minutes * 60 + 10)
    if trades is None:
        return None

    entry_price = price_at_or_before(trades, entry_ts)
    if entry_price is None or entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    # baseline: hold to settlement (no panic exit)
    baseline_payoff = (1 - cost) if side == result else -cost

    # panic exit: scan the final panic_window_seconds before close
    panic_start = close_ts - panic_window_seconds
    panic_payoff = None
    t = panic_start
    while t < close_ts:
        current_price = price_at_or_before(trades, t)
        earlier_price = price_at_or_before(trades, t - trend_check_seconds)
        if current_price is not None and earlier_price is not None:
            confidence = max(current_price, 1 - current_price)
            in_toss_up_band = confidence <= 0.5 + toss_up_band
            # "trending toward the target" = confidence decreasing (getting
            # closer to 50%, i.e. less certain) over the trend-check window
            trending_toward_toss_up = confidence < max(earlier_price, 1 - earlier_price)
            if in_toss_up_band and trending_toward_toss_up:
                price_side_now = current_price if side == "yes" else (1 - current_price)
                panic_payoff = price_side_now - cost
                break
        t += 2  # check every 2 seconds within the panic window

    if panic_payoff is None:
        panic_payoff = baseline_payoff  # never triggered - held to settlement

    return {"baseline_payoff": baseline_payoff, "panic_payoff": panic_payoff, "triggered": panic_payoff != baseline_payoff}


def evaluate(records, bet_size=100.0):
    base_payoffs = [r["baseline_payoff"] for r in records]
    panic_payoffs = [r["panic_payoff"] for r in records]
    n = len(records)
    triggers = sum(1 for r in records if r["triggered"])
    base_non_neg = sum(1 for p in base_payoffs if p >= -EPS) / n if n else 0
    panic_non_neg = sum(1 for p in panic_payoffs if p >= -EPS) / n if n else 0
    return {
        "n": n, "triggers": triggers,
        "base_non_neg": base_non_neg, "base_avg": statistics.mean(base_payoffs) * bet_size if n else 0,
        "base_total": sum(base_payoffs) * bet_size if n else 0,
        "panic_non_neg": panic_non_neg, "panic_avg": statistics.mean(panic_payoffs) * bet_size if n else 0,
        "panic_total": sum(panic_payoffs) * bet_size if n else 0,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--series", default="KXBTC15M")
    parser.add_argument("--n-markets", type=int, default=500)
    parser.add_argument("--panic-window-seconds", type=int, default=40)
    parser.add_argument("--toss-up-band", type=float, default=0.05)
    parser.add_argument("--trend-check-seconds", type=int, default=5)
    args = parser.parse_args()

    print(f"Fetching last {args.n_markets} settled {args.series} markets...")
    markets = fetch_settled_markets(args.n_markets, series=args.series)
    print(f"Got {len(markets)} settled markets. Pulling real trade data and simulating...")

    results = []
    skipped = 0
    for i, m in enumerate(markets):
        try:
            out = simulate_market(m, ENTRY_MINUTES, args.panic_window_seconds, args.toss_up_band,
                                   args.trend_check_seconds)
        except Exception:
            out = None
        if out is None:
            skipped += 1
        else:
            results.append(out)
        if (i + 1) % 50 == 0:
            print(f"  ...{i + 1}/{len(markets)} processed, {len(results)} usable so far")
        time.sleep(0.1)

    print(f"\nUsable records: {len(results)} (skipped/no-data: {skipped})\n")
    if not results:
        return

    res = evaluate(results)
    print(f"Panic exit triggered on {res['triggers']}/{res['n']} positions "
          f"({res['triggers']/res['n']:.1%} of the time)\n")
    print(f"{'':20} | {'non-neg':>8} | {'avg/$100':>10} | {'total/$100':>12}")
    print(f"{'baseline (hold)':20} | {res['base_non_neg']:>7.2%} | {res['base_avg']:>+9.2f} | {res['base_total']:>+11.2f}")
    print(f"{'with panic exit':20} | {res['panic_non_neg']:>7.2%} | {res['panic_avg']:>+9.2f} | {res['panic_total']:>+11.2f}")


if __name__ == "__main__":
    main()
