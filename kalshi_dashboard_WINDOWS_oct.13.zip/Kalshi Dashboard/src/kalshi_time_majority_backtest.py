"""Tests a specific hypothesis: if price spends the MAJORITY of a 15-minute
window's minutes below the opening price (vs above), does that majority side
predict which way the market actually settles? Different from everything
tested today - this is about TIME SPENT on each side, not swing structure,
not a single momentum reading.

Two versions:
  1. FULL-WINDOW (descriptive): uses all 15 minutes' worth of bars - answers
     "if it spent 70% of the time down, did it settle down?" literally.
     Not actionable in real time (you don't have the full window yet), but
     tells us if the underlying idea has any statistical teeth at all.
  2. PARTIAL-WINDOW (actionable): uses only the first N minutes - checks if
     the majority-side-so-far predicts the EVENTUAL settlement, which is
     the version you could actually trade on.

Entirely local/cached data, no API calls, runs fast.
"""
import argparse
import datetime as dt
import statistics

from src.data import fetch_history
from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records

EPS = 1e-9


def build_price_series(records, symbol="BTC-USD"):
    open_times = [dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")) for r in records]
    span_start = min(open_times)
    days = (dt.datetime.now(dt.timezone.utc) - span_start).days + 2
    spot_df = fetch_history(symbol=symbol, interval="1m", days=days)
    spot_df["minute_ts"] = spot_df["open_time"] // 1000
    spot_df = spot_df.sort_values("minute_ts")
    return dict(zip(spot_df["minute_ts"], spot_df["close"]))


def majority_side(prices, reference):
    """Returns ('down', frac_down) or ('up', frac_up) - whichever side had
    more minutes, and what fraction of minutes were on that side. Ties count
    as neither (skipped)."""
    if not prices:
        return None, None
    down_n = sum(1 for p in prices if p < reference)
    up_n = sum(1 for p in prices if p > reference)
    total = down_n + up_n
    if total == 0:
        return None, None
    if down_n > up_n:
        return "down", down_n / total
    if up_n > down_n:
        return "up", up_n / total
    return None, None


def evaluate_market(r, price_map, window_minutes, min_majority_frac):
    """window_minutes=None means use the FULL market (all available minutes
    up to close) - the descriptive version. Otherwise only the first
    window_minutes minutes - the actionable version."""
    open_ts = dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")).timestamp()
    result = r["result"]
    if result not in ("yes", "no"):
        return None

    minute_ts = int(open_ts) // 60 * 60
    reference = price_map.get(minute_ts)
    if reference is None:
        return None

    n_minutes = window_minutes if window_minutes is not None else 15
    prices = []
    for i in range(1, n_minutes + 1):
        p = price_map.get(minute_ts + i * 60)
        if p is None:
            break
        prices.append(p)
    if len(prices) < max(3, n_minutes // 2):
        return None

    side, frac = majority_side(prices, reference)
    if side is None or frac < min_majority_frac:
        return None

    predicted = "no" if side == "down" else "yes"
    correct = predicted == result
    return {"side": side, "frac": frac, "correct": correct}


def run(records, price_map, window_minutes, min_majority_frac):
    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]

    for label, data in (("TRAIN", train), ("HOLDOUT", test)):
        results = []
        for r in data:
            out = evaluate_market(r, price_map, window_minutes, min_majority_frac)
            if out:
                results.append(out)
        n = len(results)
        if n == 0:
            print(f"  {label}: no qualifying events found")
            continue
        accuracy = sum(1 for x in results if x["correct"]) / n
        avg_frac = statistics.mean(x["frac"] for x in results)
        down_n = sum(1 for x in results if x["side"] == "down")
        print(f"  {label}: n={n:4d} (down-majority={down_n}, up-majority={n-down_n}) "
              f"avg_majority_frac={avg_frac:.1%} accuracy={accuracy:.2%}")


def evaluate_market_economic(r, price_map, window_minutes, min_majority_frac):
    """Same signal as evaluate_market, but pays Kalshi's OWN contract price
    at the detection moment as the entry cost - the real question: has the
    market already priced this in by the time you could act on it?"""
    open_ts = dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")).timestamp()
    result = r["result"]
    if result not in ("yes", "no"):
        return None

    minute_ts = int(open_ts) // 60 * 60
    reference = price_map.get(minute_ts)
    if reference is None:
        return None

    prices = []
    for i in range(1, window_minutes + 1):
        p = price_map.get(minute_ts + i * 60)
        if p is None:
            break
        prices.append(p)
    if len(prices) < max(3, window_minutes // 2):
        return None

    side, frac = majority_side(prices, reference)
    if side is None or frac < min_majority_frac:
        return None
    predicted = "no" if side == "down" else "yes"

    entry_ts = minute_ts + window_minutes * 60
    kalshi_prices = prices_from_candles(r["candles"])
    entry_price = None
    for ts, p in kalshi_prices:
        if ts <= entry_ts:
            entry_price = p
        else:
            break
    if entry_price is None or entry_price in (0, 1):
        return None

    cost = entry_price if predicted == "yes" else (1 - entry_price)
    if cost <= 0:
        return None
    payoff = (1 - cost) if predicted == result else -cost
    kalshi_leaning = "yes" if entry_price > 0.5 else "no"
    agrees_with_kalshi = (predicted == kalshi_leaning)
    return {"payoff": payoff, "cost": cost, "agrees_with_kalshi": agrees_with_kalshi}


def run_economic(records, window_minutes, min_majority_frac, price_map, bet_size=100.0):
    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]

    for label, data in (("TRAIN", train), ("HOLDOUT", test)):
        results = []
        for r in data:
            out = evaluate_market_economic(r, price_map, window_minutes, min_majority_frac)
            if out:
                results.append(out)
        n = len(results)
        if n == 0:
            print(f"  {label}: no qualifying events found")
            continue
        payoffs = [x["payoff"] for x in results]
        non_neg = sum(1 for p in payoffs if p >= -EPS) / n
        avg_cost = statistics.mean(x["cost"] for x in results)
        print(f"  {label}: n={n:4d} non-neg={non_neg:.2%} avg_cost_paid={avg_cost:.1%} "
              f"avgPay/$100={statistics.mean(payoffs) * bet_size:+.2f} total/$100={sum(payoffs) * bet_size:+.2f}")

        for tag in (True, False):
            bucket = [x for x in results if x["agrees_with_kalshi"] == tag]
            if not bucket:
                continue
            bp = [x["payoff"] for x in bucket]
            bc = statistics.mean(x["cost"] for x in bucket)
            label2 = "agrees w/ Kalshi's own lean" if tag else "DISAGREES w/ Kalshi's own lean (contrarian)"
            print(f"    [{label2}] n={len(bucket):4d} avg_cost={bc:.1%} "
                  f"avgPay/$100={statistics.mean(bp) * bet_size:+.2f} total/$100={sum(bp) * bet_size:+.2f}")


def evaluate_market_control(r, price_map, window_minutes, min_confidence):
    """Control: ignores the majority-time signal entirely. Just buys whichever
    side Kalshi's OWN price already favors at the same detection minute, if
    it's at least min_confidence confident. Isolates whether the majority-
    time signal adds anything beyond 'buy the favorite when Kalshi is sure'."""
    open_ts = dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")).timestamp()
    result = r["result"]
    if result not in ("yes", "no"):
        return None
    minute_ts = int(open_ts) // 60 * 60
    entry_ts = minute_ts + window_minutes * 60

    kalshi_prices = prices_from_candles(r["candles"])
    entry_price = None
    for ts, p in kalshi_prices:
        if ts <= entry_ts:
            entry_price = p
        else:
            break
    if entry_price is None or entry_price in (0, 1):
        return None

    confidence = max(entry_price, 1 - entry_price)
    if confidence < min_confidence:
        return None
    predicted = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if predicted == "yes" else (1 - entry_price)
    payoff = (1 - cost) if predicted == result else -cost
    return {"payoff": payoff, "cost": cost}


def run_control(records, window_minutes, min_confidence, bet_size=100.0):
    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    for label, data in (("TRAIN", train), ("HOLDOUT", test)):
        results = []
        for r in data:
            out = evaluate_market_control(r, price_map=None, window_minutes=window_minutes, min_confidence=min_confidence)
            if out:
                results.append(out)
        n = len(results)
        if n == 0:
            print(f"  {label}: no qualifying events found")
            continue
        payoffs = [x["payoff"] for x in results]
        avg_cost = statistics.mean(x["cost"] for x in results)
        print(f"  {label}: n={n:4d} avg_cost={avg_cost:.1%} "
              f"avgPay/$100={statistics.mean(payoffs) * bet_size:+.2f} total/$100={sum(payoffs) * bet_size:+.2f}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--series", default="KXBTC15M")
    parser.add_argument("--symbol", default="BTC-USD")
    args = parser.parse_args()

    records = load_records(series=args.series)
    print(f"Loaded {len(records)} historical market price paths.")
    price_map = build_price_series(records, symbol=args.symbol)
    print(f"Got {len(price_map)} spot minute bars.\n")

    print("=== FULL-WINDOW (descriptive - uses all 15min, not tradeable in real time) ===")
    print("--- any majority (>50% of minutes on one side) ---")
    run(records, price_map, None, 0.50001)
    print("--- strong majority (>=70% of minutes on one side, your example) ---")
    run(records, price_map, None, 0.70)
    print()

    print("=== PARTIAL-WINDOW (actionable - only first N minutes known) ===")
    for detect_minutes in [5, 7, 10]:
        print(f"--- first {detect_minutes}min, any majority (>50%) ---")
        run(records, price_map, detect_minutes, 0.50001)
        print(f"--- first {detect_minutes}min, strong majority (>=70%) ---")
        run(records, price_map, detect_minutes, 0.70)
        print()

    print("=== ECONOMIC (pays Kalshi's own contract price at the detection moment) ===")
    for detect_minutes in [5, 7, 10]:
        print(f"--- first {detect_minutes}min, any majority (>50%) ---")
        run_economic(records, detect_minutes, 0.50001, price_map)
        print(f"--- first {detect_minutes}min, strong majority (>=70%) ---")
        run_economic(records, detect_minutes, 0.70, price_map)
        print()

    print("=== CONTROL (no majority-time signal at all - just buy Kalshi's own favorite when confident) ===")
    for detect_minutes in [5, 7, 10]:
        for min_conf in [0.65, 0.75, 0.85]:
            print(f"--- first {detect_minutes}min, kalshi confidence >= {min_conf:.0%} ---")
            run_control(records, detect_minutes, min_conf)
        print()


if __name__ == "__main__":
    main()
