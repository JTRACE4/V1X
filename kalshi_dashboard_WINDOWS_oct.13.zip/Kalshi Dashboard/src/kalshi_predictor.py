"""Read-only price predictor - shows a live prediction for BTC and ETH's
active 15-min Kalshi markets, using the same validated signals as the
trading bot (confidence floor, strict-direction confirmation, liquidity
sweep detection). NEVER places any order, buys, or sells anything - this
is purely informational output for you to look at.

Honest scope: this predicts DIRECTION/PROBABILITY (the same thing Kalshi's
own price already represents), not an exact dollar price. Nothing validated
today does reliable exact-price forecasting - only "how likely is yes vs no"
directional confidence, which is what's shown here.
"""
import argparse
import datetime as dt
import time

from src.kalshi_live_bot import (
    get_active_market, get_kalshi_price, get_spot_closes, spot_return_from_closes,
    had_recent_sweep, ASSETS,
)


def predict_for_asset(asset):
    active = get_active_market(asset["series"])
    if active is None:
        print(f"{asset['name']}: no active market right now.")
        return

    ticker = active["ticker"]
    close_time = dt.datetime.fromisoformat(active["close_time"].replace("Z", "+00:00"))
    now = dt.datetime.now(dt.timezone.utc)
    seconds_left = (close_time - now).total_seconds()
    kalshi_price = get_kalshi_price(active)

    if kalshi_price is None:
        print(f"{asset['name']} ({ticker}): no price data available right now.")
        return

    confidence = max(kalshi_price, 1 - kalshi_price)
    leaning = "YES" if kalshi_price > 0.5 else "NO"

    spot_closes = get_spot_closes(asset["symbol"], asset["sweep_lookback_minutes"])
    spot_ret = spot_return_from_closes(spot_closes)
    swept = had_recent_sweep(spot_closes, asset["sweep_lookback_minutes"],
                              asset["sweep_recent_minutes"], asset["sweep_margin"])

    if spot_ret is None:
        momentum_desc = "no spot data"
    else:
        confirms = (leaning == "YES" and spot_ret >= asset["strict_direction_margin"]) or \
                   (leaning == "NO" and spot_ret <= -asset["strict_direction_margin"])
        opposes = (leaning == "YES" and spot_ret <= -asset["strict_direction_margin"]) or \
                  (leaning == "NO" and spot_ret >= asset["strict_direction_margin"])
        if confirms:
            momentum_desc = f"confirming {leaning} ({spot_ret:+.4%})"
        elif opposes:
            momentum_desc = f"opposing {leaning} ({spot_ret:+.4%}) - real-time move against the lean"
        else:
            momentum_desc = f"flat/unclear ({spot_ret:+.4%})"

    below_floor = confidence < asset["entry_confidence_floor"]

    print(f"\n=== {asset['name']} - {ticker} ===")
    print(f"  time left: {int(seconds_left // 60)}m {int(seconds_left % 60)}s")
    print(f"  PREDICTION: {leaning} @ {confidence:.1%} implied probability"
          f"{' (below our own confidence floor - historically too uncertain to act on)' if below_floor else ''}")
    print(f"  spot momentum: {momentum_desc}")
    print(f"  liquidity sweep in last {asset['sweep_recent_minutes']}min: "
          f"{'YES - recent whipsaw risk' if swept else 'none detected'}")

    if not below_floor and spot_ret is not None and (
        (leaning == "YES" and spot_ret >= asset["strict_direction_margin"]) or
        (leaning == "NO" and spot_ret <= -asset["strict_direction_margin"])
    ) and not swept:
        print(f"  READ: this is exactly the setup our validated bot would trade on.")
    else:
        print(f"  READ: doesn't currently meet our validated trading bar (would sit out).")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--poll-seconds", type=int, default=10)
    args = parser.parse_args()

    print("Read-only predictor - never places any order. Ctrl+C to stop.")
    while True:
        for asset in ASSETS:
            try:
                predict_for_asset(asset)
            except Exception as exc:
                print(f"{asset['name']}: error - {exc}")
        if args.once:
            break
        time.sleep(args.poll_seconds)


if __name__ == "__main__":
    main()
