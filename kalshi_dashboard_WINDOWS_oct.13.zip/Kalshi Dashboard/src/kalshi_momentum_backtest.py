import argparse
import datetime as dt
import itertools
import pickle
import statistics

from src.data import fetch_history
from src.kalshi_exit_sim import prices_from_candles, simulate_exit
from src.kalshi_fetch_paths import CACHE_PATH, cache_path_for

EPS = 1e-9


def load_records(series=None):
    path = cache_path_for(series) if series else CACHE_PATH
    with open(path, "rb") as f:
        return pickle.load(f)


def build_spot_minute_map(records, symbol="BTC-USD"):
    open_times = [dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")) for r in records]
    span_start = min(open_times)
    days = (dt.datetime.now(dt.timezone.utc) - span_start).days + 2
    print(f"Fetching {symbol} spot 1m data covering {days} days (this may re-pull if the cache doesn't reach back far enough)...")
    spot_df = fetch_history(symbol=symbol, interval="1m", days=days)
    spot_df["minute_ts"] = spot_df["open_time"] // 1000
    spot_map = dict(zip(spot_df["minute_ts"], spot_df["close"]))
    print(f"Got {len(spot_map)} spot minute bars.")
    return spot_map


def simulate_momentum_trade(candles, close_ts, result, spot_map,
                             jump_threshold, min_seconds_left,
                             lock_in, trail, hard_stop):
    prices = prices_from_candles(candles)
    if len(prices) < 3:
        return None

    for i, (ts, p) in enumerate(prices):
        if i == 0:
            continue
        if close_ts - ts < min_seconds_left:
            break

        spot_now = spot_map.get(ts)
        spot_prev = spot_map.get(ts - 60)
        if spot_now is None or spot_prev is None or spot_prev == 0:
            continue
        spot_ret = spot_now / spot_prev - 1
        if abs(spot_ret) < jump_threshold:
            continue

        side = "yes" if spot_ret > 0 else "no"
        entry_price = p
        if entry_price <= 0.0 or entry_price >= 1.0:
            continue
        cost = entry_price if side == "yes" else (1 - entry_price)
        return simulate_exit(prices, i, cost, side, result, lock_in, trail, hard_stop)

    return None


def evaluate(records, spot_map, jump_threshold, min_seconds_left, lock_in, trail, hard_stop):
    payoffs = []
    reasons = {"trailing_stop": 0, "breakeven_stop": 0, "settlement": 0}
    for r in records:
        out = simulate_momentum_trade(r["candles"], r["close_ts"], r["result"], spot_map,
                                       jump_threshold, min_seconds_left, lock_in, trail, hard_stop)
        if out is None:
            continue
        payoffs.append(out["payoff"])
        reasons[out["reason"]] += 1

    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS)
    losers = [p for p in payoffs if p < -EPS]
    winners = [p for p in payoffs if p > EPS]
    return {
        "jump_threshold": jump_threshold, "lock_in": lock_in, "trail": trail, "hard_stop": hard_stop,
        "n": n, "coverage": n / len(records),
        "pct_non_negative": non_negative / n,
        "avg_payoff": statistics.mean(payoffs),
        "avg_loser": statistics.mean(losers) if losers else 0.0,
        "n_losers": len(losers),
        "reasons": reasons,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bet-size", type=float, default=100.0)
    args = parser.parse_args()

    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.")
    spot_map = build_spot_minute_map(records)

    jump_options = [0.0003, 0.0004, 0.0005, 0.0007, 0.0010]
    lock_in_options = [0.02, 0.03, 0.05]
    trail_options = [0.02, 0.03]
    hard_stop_options = [0.0, 0.01]
    min_seconds_left = 90

    results = []
    for jump, lock_in, trail, hard_stop in itertools.product(
        jump_options, lock_in_options, trail_options, hard_stop_options
    ):
        res = evaluate(records, spot_map, jump, min_seconds_left, lock_in, trail, hard_stop)
        if res:
            results.append(res)

    print(f"\nEvaluated {len(results)} parameter combinations.\n")
    results.sort(key=lambda r: (-r["pct_non_negative"], -r["avg_payoff"]))

    print("--- Top 15 momentum-entry strategies by % non-negative, tie-broken by avg payoff ---")
    print(f"{'jump%':>7} {'lock_in':>8} {'trail':>7} {'hstop':>7} {'n':>6} {'cov':>6} "
          f"{'%non-neg':>9} {'avgPay/$100':>12} {'avgLoss/$100':>13}")
    for r in results[:15]:
        print(f"{r['jump_threshold']:>7.4f} {r['lock_in']:>8.2f} {r['trail']:>7.2f} {r['hard_stop']:>7.2f} "
              f"{r['n']:>6} {r['coverage']:>6.1%} {r['pct_non_negative']:>8.2%} "
              f"{r['avg_payoff'] * args.bet_size:>12.2f} {r['avg_loser'] * args.bet_size:>13.2f}")

    high_safety = [r for r in results if r["pct_non_negative"] >= 0.90]
    high_safety.sort(key=lambda r: -r["avg_payoff"])
    print("\n--- Among >=90% non-negative momentum strategies, best avg payoff ---")
    for r in high_safety[:5]:
        print(f"jump={r['jump_threshold']} lock_in={r['lock_in']} trail={r['trail']} hard_stop={r['hard_stop']}: "
              f"n={r['n']} (coverage {r['coverage']:.1%}) non-neg={r['pct_non_negative']:.2%} "
              f"avgPay/$100={r['avg_payoff'] * args.bet_size:+.2f} reasons={r['reasons']}")


if __name__ == "__main__":
    main()
