"""Tests whether a confirmed swing-structure trend (higher-highs + higher-
lows for an uptrend, lower-highs + lower-lows for a downtrend) forming in
the first N minutes of a market predicts the eventual settlement direction.
Classic Dow Theory pattern - genuinely different from everything tested
today since it's about the SEQUENCE of swings, not a single indicator
value. Entirely local/cached data, no API calls, runs fast."""
import argparse
import datetime as dt
import statistics

from src.data import fetch_history
from src.kalshi_momentum_backtest import load_records

EPS = 1e-9


def find_swings(prices, swing_window=2):
    """A swing high at index i: price[i] is the max of prices[i-w:i+w+1].
    Same for swing low with min. Returns lists of (index, price) tuples."""
    highs, lows = [], []
    for i in range(swing_window, len(prices) - swing_window):
        window = prices[i - swing_window:i + swing_window + 1]
        if prices[i] == max(window) and window.count(prices[i]) == 1:
            highs.append((i, prices[i]))
        if prices[i] == min(window) and window.count(prices[i]) == 1:
            lows.append((i, prices[i]))
    return highs, lows


def detect_trend(prices, swing_window=2):
    """Returns 'up', 'down', or None based on the last two swing highs and
    last two swing lows."""
    highs, lows = find_swings(prices, swing_window)
    if len(highs) < 2 or len(lows) < 2:
        return None
    hh = highs[-1][1] > highs[-2][1]
    hl = lows[-1][1] > lows[-2][1]
    lh = highs[-1][1] < highs[-2][1]
    ll = lows[-1][1] < lows[-2][1]
    if hh and hl:
        return "up"
    if lh and ll:
        return "down"
    return None


def build_price_map(records, symbol="BTC-USD"):
    open_times = [dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")) for r in records]
    span_start = min(open_times)
    days = (dt.datetime.now(dt.timezone.utc) - span_start).days + 2
    spot_df = fetch_history(symbol=symbol, interval="1m", days=days)
    spot_df["minute_ts"] = spot_df["open_time"] // 1000
    spot_df = spot_df.sort_values("minute_ts")
    return dict(zip(spot_df["minute_ts"], spot_df["close"]))


def evaluate_market(r, price_map, detect_minutes):
    open_ts = dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")).timestamp()
    result = r["result"]
    if result not in ("yes", "no"):
        return None

    minute_ts = int(open_ts) // 60 * 60
    prices = []
    for i in range(detect_minutes):
        p = price_map.get(minute_ts + i * 60)
        if p is None:
            return None
        prices.append(p)

    trend = detect_trend(prices)
    if trend is None:
        return None
    # BTC/ETH 15-min markets resolve "yes" if price ends >= the open-time
    # reference roughly (target is close to open) - use trend direction as
    # the predicted side and check against the real result.
    predicted = "yes" if trend == "up" else "no"
    correct = predicted == result
    return {"trend": trend, "correct": correct}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--series", default="KXBTC15M")
    parser.add_argument("--symbol", default="BTC-USD")
    args = parser.parse_args()

    records = load_records(series=args.series)
    print(f"Loaded {len(records)} historical market price paths.")
    price_map = build_price_map(records, symbol=args.symbol)

    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    for detect_minutes in [5, 7, 10]:
        print(f"--- trend confirmed within first {detect_minutes} minutes ---")
        for label, data in (("TRAIN", train), ("HOLDOUT", test)):
            results = []
            for r in data:
                out = evaluate_market(r, price_map, detect_minutes)
                if out:
                    results.append(out)
            n = len(results)
            if n == 0:
                print(f"  {label}: no trend-confirmed events found")
                continue
            accuracy = sum(1 for x in results if x["correct"]) / n
            up_n = sum(1 for x in results if x["trend"] == "up")
            print(f"  {label}: n={n} (up={up_n}, down={n-up_n}) accuracy={accuracy:.2%}")
        print()


if __name__ == "__main__":
    main()
