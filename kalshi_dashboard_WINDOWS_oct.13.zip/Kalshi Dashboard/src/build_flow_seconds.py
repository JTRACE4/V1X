"""Collapse the Coinbase tick logs (bot_state/ticks_<SYM>.csv: every trade
with maker side) into per-second aggressive buy/sell volume + last price.
Coinbase 'side' is the MAKER side: side=sell -> aggressive BUY.
Output: data_cache/flow_seconds_<SYM>.parquet (new file; ticks untouched)."""
import os
import sys

import pandas as pd

ROOT = os.path.join(os.path.dirname(__file__), "..")


def build(sym, since="2026-09-20"):
    out = os.path.join(ROOT, "data_cache", f"flow_seconds_{sym}.pkl")
    parts = []
    for chunk in pd.read_csv(os.path.join(ROOT, "bot_state", f"ticks_{sym}.csv"),
                             usecols=["time", "side", "price", "size"], chunksize=2_000_000):
        chunk = chunk[chunk["time"] >= since]
        if chunk.empty:
            continue
        chunk["t"] = pd.to_datetime(chunk["time"], format="ISO8601", utc=True, errors="coerce").dt.floor("s")
        chunk = chunk.dropna(subset=["t"])
        chunk["usd"] = chunk["price"] * chunk["size"]
        chunk["buy_usd"] = chunk["usd"].where(chunk["side"] == "sell", 0.0)
        chunk["sell_usd"] = chunk["usd"].where(chunk["side"] == "buy", 0.0)
        g = chunk.groupby("t").agg(buy_usd=("buy_usd", "sum"), sell_usd=("sell_usd", "sum"), price=("price", "last"))
        parts.append(g)
        print(sym, "chunk ->", len(g), "seconds", flush=True)
    df = pd.concat(parts)
    df = df.groupby(level=0).agg(buy_usd=("buy_usd", "sum"), sell_usd=("sell_usd", "sum"), price=("price", "last"))
    df.to_pickle(out)
    print(sym, "saved", len(df), "seconds", df.index.min(), "->", df.index.max(), flush=True)


if __name__ == "__main__":
    for s in sys.argv[1:] or ("BTC-USD", "XRP-USD"):
        build(s)
