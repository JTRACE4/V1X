"""Back-fills the pattern memory (bot_state/pattern_stats.json 'hist') by replaying recorded candles candle by candle
(no look-ahead): at each candle the detector sees only candles up to it, and the move over the next horizon is scored
hit / miss / flat exactly like the live tracker. Re-run any time; it replaces 'hist' and keeps 'live'/'pending'."""
import json, math, os, sys, time
import pandas as pd
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from src import mtf_structure as M
from src.pattern_detector import _structure, _candle_patterns, _atr

ROOT = M.ROOT
def load_1m(sym):
    df = pd.read_pickle(os.path.join(M.DATA, f"{sym}_1m.pkl")).sort_values("open_time")
    return [[int(r.open_time // 1000), float(r.open), float(r.high), float(r.low), float(r.close)] for r in df.itertuples()]

def run(asset, product, hist):
    one = load_1m(product)
    daily = M.fetch_daily_history(product)
    series = {"1m": one, "5m": M.resample_seconds(one, 300), "15m": M.resample_seconds(one, 900), "1h": M.resample_seconds(one, 3600),
              "3h": M.resample_seconds(one, 10800), "6h": M.resample_seconds(one, 21600), "12h": M.resample_seconds(one, 43200),
              "1d": daily, "1w": M.resample_calendar(daily, "w")}
    for tf, cs in series.items():
        tfm = M.TF_MIN[tf]; hmin = M.HORIZONS[tf][0]; hc = max(1, math.ceil(hmin / tfm))
        stride = 2 if tf == "1m" else 1
        last = {}; t0 = time.time(); n_ev = 0
        for i in range(60, len(cs) - hc - 1, stride):
            w = cs[max(0, i - 89): i + 1]
            try:
                labs = _structure(w, tf) + _candle_patterns(w, tf)
            except Exception:
                continue
            if not labs: continue
            atr = _atr(w[:-1])
            if atr <= 0: continue
            thr = M.HIT_ATR * atr * math.sqrt(max(1.0, hmin / tfm))
            for l in labs:
                if l["bias"] not in ("bullish", "bearish"): continue
                key = M.label_key(l["name"])
                if i - last.get(key, -10**9) < hc: continue
                last[key] = i
                move = (cs[i + hc][4] - cs[i][4]) * (1 if l["bias"] == "bullish" else -1)
                res = "hit" if move >= thr else ("miss" if move <= -thr else "flat")
                d = hist.setdefault(f"{asset}|{tf}|{key}", {"hit": 0, "miss": 0, "flat": 0}); d[res] += 1; n_ev += 1
        print(f"  {asset} {tf:>3}: {len(cs):>7} candles, {n_ev:>6} pattern calls scored in {time.time()-t0:.0f}s", flush=True)

if __name__ == "__main__":
    hist = {}
    for asset, product in (("XRP", "XRP-USD"), ("BTC", "BTC-USD")):
        run(asset, product, hist)
    try: d = json.load(open(M.STATS_FILE))
    except (OSError, ValueError): d = {}
    d["hist"] = hist; d.setdefault("live", {}); d.setdefault("pending", [])
    json.dump(d, open(M.STATS_FILE, "w"))
    print("saved", len(hist), "pattern/timeframe records to", M.STATS_FILE)
