import argparse
import os

import joblib
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import accuracy_score, classification_report

from src.data import fetch_history
from src.features import build_dataset, FEATURE_COLUMNS

MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "models", "model.joblib")


def train(symbol="BTC-USD", interval="5m", days=4300, test_size=0.15):
    print(f"Fetching {days}d of {interval} candles for {symbol}...")
    raw = fetch_history(symbol=symbol, interval=interval, days=days)
    print(f"Fetched {len(raw)} raw candles.")

    data = build_dataset(raw)
    print(f"Usable rows after feature/label prep: {len(data)}")

    split_idx = int(len(data) * (1 - test_size))
    train_df = data.iloc[:split_idx]
    test_df = data.iloc[split_idx:]

    X_train, y_train = train_df[FEATURE_COLUMNS], train_df["label"]
    X_test, y_test = test_df[FEATURE_COLUMNS], test_df["label"]

    model = HistGradientBoostingClassifier(
        max_iter=300, learning_rate=0.05, random_state=42
    )
    model.fit(X_train, y_train)

    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds)
    baseline_acc = max(y_test.mean(), 1 - y_test.mean())

    print(f"\nHoldout accuracy: {acc:.4f}")
    print(f"Naive baseline (always predict majority class): {baseline_acc:.4f}")
    print("\n" + classification_report(y_test, preds, target_names=["down", "up"]))

    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    joblib.dump(
        {
            "model": model,
            "features": FEATURE_COLUMNS,
            "symbol": symbol,
            "interval": interval,
        },
        MODEL_PATH,
    )
    print(f"\nSaved model to {os.path.abspath(MODEL_PATH)}")

    return model, test_df


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbol", default="BTC-USD")
    parser.add_argument("--interval", default="5m")
    parser.add_argument("--days", type=int, default=4300)
    parser.add_argument("--test-size", type=float, default=0.15)
    args = parser.parse_args()

    train(symbol=args.symbol, interval=args.interval, days=args.days, test_size=args.test_size)
