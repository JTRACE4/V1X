"""Tracks real live trading performance against the current goal, and gives
an honest diagnosis of why we're on or off track - reusing the same
categorization already done manually today (bug losses vs working-as-intended
defensive exits vs genuine unpredicted losses). Re-run anytime for a status
check. Read-only - never places orders or changes bot parameters."""
import csv
import datetime as dt
import json
import os

STATE_DIR = os.path.join(os.path.dirname(__file__), "..", "bot_state")
LIVE_TRADES_PATH = os.path.join(STATE_DIR, "live_trades.csv")
GOAL_PATH = os.path.join(STATE_DIR, "trading_goal.json")

# known bug-caused losses, so they're excluded from "is the current strategy
# working" analysis but still shown for transparency. Add to this list only
# when a fix has genuinely been deployed and confirmed - do not use this to
# quietly explain away real losses.
KNOWN_FIXED_BUG_LOSSES = {
    "KXBTC15M-26AUG020130-30": "re-entry bug (fixed 2026-08-02): bought back in immediately after a "
                                 "defensive exit fired, on a market that had already proven volatile",
    "KXBTC15M-26AUG020300-00": "re-entry bug (fixed 2026-08-02): same as above",
}

DEFAULT_GOAL = {
    "phase": 1,
    "description": "Prove the strategy's edge is real under current market conditions before setting "
                    "any growth target. Backtest projects ~98% non-negative rate and solidly positive "
                    "P&L; real trading needs to demonstrate it can track that before Phase 2 (a real "
                    "compounding growth target) is meaningful.",
    "target_net_pnl": 0.0,
    "target_non_negative_rate": 0.95,
    "set_date": "2026-08-02",
}


def load_goal():
    if os.path.exists(GOAL_PATH):
        with open(GOAL_PATH) as f:
            return json.load(f)
    with open(GOAL_PATH, "w") as f:
        json.dump(DEFAULT_GOAL, f, indent=2)
    return DEFAULT_GOAL


def load_real_trades():
    trades = []
    with open(LIVE_TRADES_PATH) as f:
        r = csv.reader(f)
        next(r)
        for row in r:
            if len(row) < 13:
                continue
            ticker, strategy, time_, action, side, count, price, cost_dollars, order_id, dry_run, \
                exit_reason, result, payoff = row
            if dry_run == "True":
                continue
            if action in ("settle", "sell") and payoff:
                trades.append({
                    "ticker": ticker, "time": time_, "exit_reason": exit_reason,
                    "payoff": float(payoff),
                })
    return trades


def main():
    goal = load_goal()
    trades = load_real_trades()

    print(f"=== GOAL (Phase {goal['phase']}, set {goal['set_date']}) ===")
    print(goal["description"])
    print(f"Target: net P&L >= ${goal['target_net_pnl']:.2f}, non-negative rate >= "
          f"{goal['target_non_negative_rate']:.0%}\n")

    n = len(trades)
    wins = sum(1 for t in trades if t["payoff"] >= -1e-9)
    losses = n - wins
    net_pnl = sum(t["payoff"] for t in trades)
    non_neg_rate = wins / n if n else 0

    bug_losses = [t for t in trades if t["ticker"] in KNOWN_FIXED_BUG_LOSSES and t["payoff"] < 0]
    bug_loss_total = sum(t["payoff"] for t in bug_losses)
    clean_trades = [t for t in trades if t["ticker"] not in KNOWN_FIXED_BUG_LOSSES]
    clean_n = len(clean_trades)
    clean_wins = sum(1 for t in clean_trades if t["payoff"] >= -1e-9)
    clean_net = sum(t["payoff"] for t in clean_trades)
    clean_non_neg = clean_wins / clean_n if clean_n else 0

    print(f"=== ACTUAL (all {n} real trades) ===")
    print(f"wins={wins} losses={losses} non-neg={non_neg_rate:.2%} net=${net_pnl:+.2f}\n")

    print(f"=== ACTUAL excluding known fixed-bug losses ({len(bug_losses)} trades, "
          f"${bug_loss_total:+.2f}) ===")
    print(f"n={clean_n} wins={clean_wins} non-neg={clean_non_neg:.2%} net=${clean_net:+.2f}\n")

    on_track_raw = net_pnl >= goal["target_net_pnl"] and non_neg_rate >= goal["target_non_negative_rate"]
    on_track_clean = clean_net >= goal["target_net_pnl"] and clean_non_neg >= goal["target_non_negative_rate"]

    print("=== DIAGNOSIS ===")
    if on_track_raw:
        print("ON TRACK - real performance is meeting the Phase 1 goal.")
    else:
        gap_pnl = goal["target_net_pnl"] - net_pnl
        gap_rate = goal["target_non_negative_rate"] - non_neg_rate
        print(f"OFF TRACK - net P&L is ${gap_pnl:.2f} short of target, "
              f"non-negative rate is {gap_rate:.1%} below target.")
        if on_track_clean:
            print("However: excluding the known, already-fixed bug losses, the CLEAN trade record "
                  "would already be on track. The gap is fully explained by bugs that have since been "
                  "fixed, not by the strategy itself failing.")
        else:
            clean_gap_pnl = goal["target_net_pnl"] - clean_net
            clean_gap_rate = goal["target_non_negative_rate"] - clean_non_neg
            print(f"Even excluding known bug losses, still off track by ${clean_gap_pnl:.2f} / "
                  f"{clean_gap_rate:.1%} non-neg rate. This is the real, unresolved gap - not explained "
                  "by bugs, and not yet explained by any tested predictive signal (see "
                  "strategy_research_log.json - 7+ signals tested today, all rejected on proper "
                  "validation). Current mitigation: position size cut from 100 to 50 contracts. "
                  "Recommend re-running this tracker after more real trades accumulate to see if the "
                  "gap narrows (supports 'rough patch' explanation) or persists (supports 'backtest "
                  "doesn't match current regime' explanation).")

    print(f"\n=== Loss breakdown (all {losses} real losses) ===")
    for t in trades:
        if t["payoff"] < 0:
            note = KNOWN_FIXED_BUG_LOSSES.get(t["ticker"], "no known bug - genuine unpredicted loss")
            print(f"  {t['time']}  {t['ticker']}  {t['exit_reason']:12s}  ${t['payoff']:+.2f}  -- {note}")


if __name__ == "__main__":
    main()
