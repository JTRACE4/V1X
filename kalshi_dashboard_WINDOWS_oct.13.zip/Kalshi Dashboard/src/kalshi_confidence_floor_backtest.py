"""Tests skipping the close_favorite entry until the market's own confidence
reaches a floor (e.g. 65%), instead of entering at a fixed time-before-close
regardless of how weak the favorite is. Layers on top of the already-validated
entry filter + adaptive-gap defensive exit, so this isolates the floor's effect."""
import argparse
import statistics

from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records, build_spot_minute_map
from src.kalshi_adaptive_gap_backtest import adaptive_threshold

EPS = 1e-9


def simulate(candles, close_ts, result, spot_map, entry_minutes, entry_filter_threshold,
             base_threshold, min_threshold, confidence_floor):
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None

    window_start_ts = close_ts - entry_minutes * 60

    entry_idx = None
    if confidence_floor <= 0.5:
        # baseline behavior: enter at the first point at/before the window opens
        for i, (ts, _) in enumerate(prices):
            if ts <= window_start_ts:
                entry_idx = i
            else:
                break
        if entry_idx is None:
            entry_idx = 0
    else:
        # scan forward through the entry window for the first point confidence
        # reaches the floor; if it never does before close, skip this market.
        for i, (ts, p) in enumerate(prices):
            if ts < window_start_ts or ts >= close_ts:
                continue
            if max(p, 1 - p) >= confidence_floor:
                entry_idx = i
                break
        if entry_idx is None:
            return None

    if entry_idx >= len(prices) - 1:
        return None

    entry_price = prices[entry_idx][1]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    if entry_filter_threshold is not None:
        entry_ts_actual = prices[entry_idx][0]
        spot_now = spot_map.get(entry_ts_actual)
        spot_prev = spot_map.get(entry_ts_actual - 60)
        if spot_now is not None and spot_prev is not None and spot_prev != 0:
            spot_ret = spot_now / spot_prev - 1
            adverse_at_entry = (side == "yes" and spot_ret <= -entry_filter_threshold) or \
                                (side == "no" and spot_ret >= entry_filter_threshold)
            if adverse_at_entry:
                return None

    for ts, p in prices[entry_idx + 1:]:
        confidence = max(p, 1 - p)
        threshold = adaptive_threshold(confidence, base_threshold, min_threshold)
        spot_now = spot_map.get(ts)
        spot_prev = spot_map.get(ts - 60)
        if spot_now is not None and spot_prev is not None and spot_prev != 0:
            spot_ret = spot_now / spot_prev - 1
            adverse = (side == "yes" and spot_ret <= -threshold) or \
                      (side == "no" and spot_ret >= threshold)
            if adverse:
                price_side_now = p if side == "yes" else (1 - p)
                return {"payoff": price_side_now - cost, "reason": "defensive_exit"}

    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff, "reason": "settlement"}


def evaluate(records, spot_map, entry_minutes, entry_filter, base_threshold, min_threshold,
             confidence_floor, bet_size=100.0):
    payoffs = []
    skipped = 0
    for r in records:
        out = simulate(r["candles"], r["close_ts"], r["result"], spot_map, entry_minutes,
                        entry_filter, base_threshold, min_threshold, confidence_floor)
        if out is None:
            skipped += 1
            continue
        payoffs.append(out["payoff"])
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "skipped": skipped, "non_negative": non_negative,
            "avg_payoff": statistics.mean(payoffs) * bet_size,
            "total_payoff": sum(payoffs) * bet_size}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--entry-minutes", type=float, default=3.5)
    parser.add_argument("--entry-filter", type=float, default=0.00005)
    parser.add_argument("--base-threshold", type=float, default=0.00035)
    parser.add_argument("--min-threshold", type=float, default=0.00005)
    parser.add_argument("--confidence-floor", type=float, default=0.65)
    args = parser.parse_args()

    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.")
    spot_map = build_spot_minute_map(records)

    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    for label, data in (("FULL", records), ("TRAIN", train), ("HOLDOUT", test)):
        baseline = evaluate(data, spot_map, args.entry_minutes, args.entry_filter,
                             args.base_threshold, args.min_threshold, confidence_floor=0.0)
        floored = evaluate(data, spot_map, args.entry_minutes, args.entry_filter,
                            args.base_threshold, args.min_threshold,
                            confidence_floor=args.confidence_floor)
        print(f"--- {label} ---")
        print(f"baseline (no floor):        n={baseline['n']:4d} non-neg={baseline['non_negative']:.2%} "
              f"avgPay/$100={baseline['avg_payoff']:+.2f} total=${baseline['total_payoff']:+.2f}")
        print(f"floor={args.confidence_floor:.0%}:              n={floored['n']:4d} "
              f"(skipped {floored['skipped']}) non-neg={floored['non_negative']:.2%} "
              f"avgPay/$100={floored['avg_payoff']:+.2f} total=${floored['total_payoff']:+.2f}\n")


if __name__ == "__main__":
    main()
