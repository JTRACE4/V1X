"""Systematic scan for NEW candidate signals not yet tested - each one has to
clear the same bar everything else did today: real out-of-sample accuracy
(train/holdout split), AND actual economic edge beyond what Kalshi's own
contract price already reflects at the same moment (checked via a control
and an agree/disagree-with-Kalshi breakdown, same method that caught the
majority-time-signal being redundant earlier).

Candidates tested, all using the first `DETECT_MINUTES` minutes of each
15-min market:
  1. Acceleration - is the most recent 1-min return larger than the one
     before it, in the same direction (momentum speeding up, not just moving)?
  2. Volume-confirmed move - did the move happen on above-average volume?
  3. Mean-reversion - is price stretched far from its own short moving
     average (a contrarian bet, opposite of everything trend-following
     tested today)?
  4. Cross-asset lead - does the OTHER asset's move (e.g. ETH) predict THIS
     asset's settlement, on the theory one might lead the other?

Entirely local/cached data, no live API calls, runs fast.
"""
import argparse
import datetime as dt
import statistics

from src.data import fetch_history
from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records

EPS = 1e-9
DETECT_MINUTES = 7


def build_ohlcv_map(records, symbol):
    open_times = [dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")) for r in records]
    span_start = min(open_times)
    days = (dt.datetime.now(dt.timezone.utc) - span_start).days + 2
    df = fetch_history(symbol=symbol, interval="1m", days=days)
    df["minute_ts"] = df["open_time"] // 1000
    df = df.sort_values("minute_ts")
    out = {}
    for row in df.itertuples():
        out[row.minute_ts] = {"close": row.close, "volume": row.volume, "high": row.high, "low": row.low}
    return out


def get_window(ohlcv_map, minute_ts, n):
    """Returns list of the n+1 bars from minute_ts (inclusive) to
    minute_ts + n*60, or None if any are missing."""
    bars = []
    for i in range(n + 1):
        bar = ohlcv_map.get(minute_ts + i * 60)
        if bar is None:
            return None
        bars.append(bar)
    return bars


# ---- candidate signals - each returns 'yes'/'no'/None ----

def sig_acceleration(bars):
    closes = [b["close"] for b in bars]
    rets = [closes[i] / closes[i - 1] - 1 for i in range(1, len(closes))]
    if len(rets) < 2:
        return None
    last, prev = rets[-1], rets[-2]
    if last > 0 and last > prev:
        return "yes"
    if last < 0 and last < prev:
        return "no"
    return None


def sig_volume_confirm(bars, vol_mult=1.5, min_move=0.0003):
    closes = [b["close"] for b in bars]
    vols = [b["volume"] for b in bars]
    if len(bars) < 4:
        return None
    last_vol = vols[-1]
    baseline = statistics.mean(vols[:-1])
    if baseline <= 0 or last_vol < baseline * vol_mult:
        return None
    move = closes[-1] / closes[-2] - 1
    if move >= min_move:
        return "yes"
    if move <= -min_move:
        return "no"
    return None


def sig_mean_reversion(bars, stretch_threshold=0.0015):
    closes = [b["close"] for b in bars]
    sma = statistics.mean(closes)
    last = closes[-1]
    if sma == 0:
        return None
    dist = (last - sma) / sma
    if dist >= stretch_threshold:
        return "no"   # stretched too far above -> bet on reversion down
    if dist <= -stretch_threshold:
        return "yes"  # stretched too far below -> bet on reversion up
    return None


def sig_cross_asset(other_bars, margin=0.0004):
    closes = [b["close"] for b in other_bars]
    ret = closes[-1] / closes[0] - 1
    if ret >= margin:
        return "yes"
    if ret <= -margin:
        return "no"
    return None


SIGNALS = {
    "acceleration": lambda bars, other_bars: sig_acceleration(bars),
    "volume_confirm": lambda bars, other_bars: sig_volume_confirm(bars),
    "mean_reversion": lambda bars, other_bars: sig_mean_reversion(bars),
    "cross_asset_lead": lambda bars, other_bars: sig_cross_asset(other_bars),
}


def evaluate_market(r, ohlcv_map, other_ohlcv_map, sig_fn, detect_minutes):
    open_ts = dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")).timestamp()
    result = r["result"]
    if result not in ("yes", "no"):
        return None
    minute_ts = int(open_ts) // 60 * 60
    bars = get_window(ohlcv_map, minute_ts, detect_minutes)
    other_bars = get_window(other_ohlcv_map, minute_ts, detect_minutes) if other_ohlcv_map else None
    if bars is None or (other_ohlcv_map is not None and other_bars is None):
        return None

    predicted = sig_fn(bars, other_bars)
    if predicted is None:
        return None

    entry_ts = minute_ts + detect_minutes * 60
    kalshi_prices = prices_from_candles(r["candles"])
    entry_price = None
    for ts, p in kalshi_prices:
        if ts <= entry_ts:
            entry_price = p
        else:
            break
    if entry_price is None or entry_price in (0, 1):
        return None

    cost = entry_price if predicted == "yes" else (1 - entry_price)
    payoff = (1 - cost) if predicted == result else -cost
    kalshi_leaning = "yes" if entry_price > 0.5 else "no"
    agrees = predicted == kalshi_leaning
    correct = predicted == result
    return {"correct": correct, "payoff": payoff, "cost": cost, "agrees": agrees}


def run(records, ohlcv_map, other_ohlcv_map, sig_fn, detect_minutes, bet_size=100.0):
    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]

    for label, data in (("TRAIN", train), ("HOLDOUT", test)):
        results = []
        for r in data:
            out = evaluate_market(r, ohlcv_map, other_ohlcv_map, sig_fn, detect_minutes)
            if out:
                results.append(out)
        n = len(results)
        if n == 0:
            print(f"    {label}: no qualifying events found")
            continue
        acc = sum(1 for x in results if x["correct"]) / n
        payoffs = [x["payoff"] for x in results]
        agree_n = sum(1 for x in results if x["agrees"])
        disagree = [x for x in results if not x["agrees"]]
        dis_payoff = statistics.mean(x["payoff"] for x in disagree) * bet_size if disagree else None
        print(f"    {label}: n={n:4d} accuracy={acc:.2%} avgPay/$100={statistics.mean(payoffs)*bet_size:+.2f} "
              f"total/$100={sum(payoffs)*bet_size:+.2f}  (agree-w/-Kalshi={agree_n}/{n}, "
              f"disagree-n={len(disagree)}, disagree-avgPay/$100="
              f"{f'{dis_payoff:+.2f}' if dis_payoff is not None else 'n/a'})")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--series", default="KXBTC15M")
    parser.add_argument("--symbol", default="BTC-USD")
    parser.add_argument("--other-symbol", default="ETH-USD")
    parser.add_argument("--detect-minutes", type=int, default=DETECT_MINUTES)
    args = parser.parse_args()

    records = load_records(series=args.series)
    print(f"Loaded {len(records)} historical market price paths for {args.series}.\n")
    ohlcv_map = build_ohlcv_map(records, args.symbol)
    other_ohlcv_map = build_ohlcv_map(records, args.other_symbol)
    print(f"Got OHLCV for {args.symbol} ({len(ohlcv_map)} bars) and {args.other_symbol} ({len(other_ohlcv_map)} bars).\n")

    for name, sig_fn in SIGNALS.items():
        print(f"=== {name} (detect within first {args.detect_minutes}min) ===")
        run(records, ohlcv_map, other_ohlcv_map, sig_fn, args.detect_minutes)
        print()


if __name__ == "__main__":
    main()
