"""Self-improving research loop for the close_favorite strategy.

Reads bot_state/strategy_research_log.json (everything already tried), picks
the next untested idea from a defined candidate space, backtests it with the
same walk-forward discipline as every manual test today (train on first 80%
chronologically, confirm on the untouched last 20%), and appends the honest
result back to the log - whether it validates or not.

SAFETY BOUNDARY: this agent only researches and records. It never writes to
kalshi_live_bot.py or kalshi_paper_bot.py, and never changes live trading
parameters. Deploying a validated finding is a separate, human-reviewed step.

The candidate space is intentionally bounded and logged - this is NOT an
LLM generating arbitrary new code each run. An unbounded auto-generating loop
against a fixed historical dataset is a textbook overfitting machine; keeping
the search space defined and this log complete is what keeps that in check.
"""
import argparse
import datetime as dt
import json
import os
import statistics

from src.data import fetch_history
from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records
from src.kalshi_adaptive_gap_backtest import adaptive_threshold

STATE_DIR = os.path.join(os.path.dirname(__file__), "..", "bot_state")
LOG_PATH = os.path.join(STATE_DIR, "strategy_research_log.json")

EPS = 1e-9
BASE_ENTRY_MINUTES = 3.5
BASE_ENTRY_FILTER = 0.00005
BASE_THRESHOLD = 0.00035
BASE_MIN_THRESHOLD = 0.00005
BASE_CONFIDENCE_FLOOR = 0.58

# --- bounded candidate space: interaction effects between signals already
# individually rejected, and a soft-sizing mechanism not yet tried. Every
# rejected signal FAMILY (price, volume, choppiness at 4/15/20/30min) is
# excluded - retrying the same family with new numbers is how p-hacking
# happens. These are genuinely different mechanisms/combinations. ---
CANDIDATES = [
    {
        "id": "combo_floor_plus_spot_direction_strict",
        "description": "Combine the validated 58% confidence floor with a STRICTER spot-momentum "
                        "requirement (spot must be moving WITH our side, not just not-against it) - "
                        "an interaction between two already-individually-tested factors, not a new "
                        "signal family.",
        "kind": "entry_combo_strict_direction",
    },
    {
        "id": "position_size_soft_scale_by_confidence",
        "description": "Instead of a hard confidence floor (skip entirely below 58%), scale position "
                        "size proportionally with confidence - smaller bets on weaker favorites, full "
                        "size on strong ones. Different mechanism (soft sizing) than every filter tested "
                        "today (all were hard skip/enter).",
        "kind": "soft_size_by_confidence",
    },
    {
        "id": "entry_minutes_confidence_floor_joint_sweep",
        "description": "Joint search over entry_minutes (currently fixed at 3.5) and confidence_floor "
                        "together, instead of tuning them one at a time - checks for an interaction "
                        "effect between timing and confidence that neither alone would show.",
        "kind": "joint_entry_minutes_floor",
    },
]


def already_tested(candidate_id):
    if not os.path.exists(LOG_PATH):
        return False
    with open(LOG_PATH) as f:
        log = json.load(f)
    return any(e["id"] == candidate_id for e in log["entries"])


def append_to_log(entry):
    with open(LOG_PATH) as f:
        log = json.load(f)
    log["entries"].append(entry)
    with open(LOG_PATH, "w") as f:
        json.dump(log, f, indent=2)


def build_price_map(records, symbol="BTC-USD"):
    open_times = [dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")) for r in records]
    span_start = min(open_times)
    days = (dt.datetime.now(dt.timezone.utc) - span_start).days + 2
    spot_df = fetch_history(symbol=symbol, interval="1m", days=days)
    spot_df["minute_ts"] = spot_df["open_time"] // 1000
    return dict(zip(spot_df["minute_ts"], spot_df["close"]))


def find_entry_idx(prices, close_ts, entry_minutes, confidence_floor):
    window_start_ts = close_ts - entry_minutes * 60
    if confidence_floor <= 0.5:
        entry_idx = None
        for i, (ts, _) in enumerate(prices):
            if ts <= window_start_ts:
                entry_idx = i
            else:
                break
        return entry_idx if entry_idx is not None else 0
    for i, (ts, p) in enumerate(prices):
        if ts < window_start_ts or ts >= close_ts:
            continue
        if max(p, 1 - p) >= confidence_floor:
            return i
    return None


def simulate_strict_direction(candles, close_ts, result, price_map, strict_margin):
    """entry filter requires spot to be moving WITH our side by at least
    strict_margin, not just not-against it (baseline entry_filter only
    blocks when spot is adverse; this additionally requires favorable)."""
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None
    entry_idx = find_entry_idx(prices, close_ts, BASE_ENTRY_MINUTES, BASE_CONFIDENCE_FLOOR)
    if entry_idx is None or entry_idx >= len(prices) - 1:
        return None
    entry_ts, entry_price = prices[entry_idx]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    spot_now = price_map.get(entry_ts)
    spot_prev = price_map.get(entry_ts - 60)
    if spot_now is None or spot_prev is None or spot_prev == 0:
        return None
    spot_ret = spot_now / spot_prev - 1
    favorable = (side == "yes" and spot_ret >= strict_margin) or (side == "no" and spot_ret <= -strict_margin)
    if not favorable:
        return None

    for ts, p in prices[entry_idx + 1:]:
        confidence = max(p, 1 - p)
        threshold = adaptive_threshold(confidence, BASE_THRESHOLD, BASE_MIN_THRESHOLD)
        spot_now2 = price_map.get(ts)
        spot_prev2 = price_map.get(ts - 60)
        if spot_now2 is not None and spot_prev2 is not None and spot_prev2 != 0:
            spot_ret2 = spot_now2 / spot_prev2 - 1
            adverse = (side == "yes" and spot_ret2 <= -threshold) or (side == "no" and spot_ret2 >= threshold)
            if adverse:
                price_side_now = p if side == "yes" else (1 - p)
                return {"payoff": price_side_now - cost}
    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff}


def simulate_soft_size(candles, close_ts, result, price_map, min_size_frac):
    """position size scales linearly with confidence at entry: min_size_frac
    at 50% confidence, 1.0 (full size) at 100% confidence. Payoff scales with
    size. No entries are skipped - this replaces the hard floor entirely."""
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None
    entry_idx = find_entry_idx(prices, close_ts, BASE_ENTRY_MINUTES, 0.0)
    if entry_idx is None or entry_idx >= len(prices) - 1:
        return None
    entry_ts, entry_price = prices[entry_idx]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)
    confidence = max(entry_price, 1 - entry_price)
    size_frac = min_size_frac + (1 - min_size_frac) * ((confidence - 0.5) / 0.5)

    spot_now = price_map.get(entry_ts)
    spot_prev = price_map.get(entry_ts - 60)
    if spot_now is not None and spot_prev is not None and spot_prev != 0:
        spot_ret = spot_now / spot_prev - 1
        adverse_at_entry = (side == "yes" and spot_ret <= -BASE_ENTRY_FILTER) or \
                            (side == "no" and spot_ret >= BASE_ENTRY_FILTER)
        if adverse_at_entry:
            return None

    for ts, p in prices[entry_idx + 1:]:
        conf2 = max(p, 1 - p)
        threshold = adaptive_threshold(conf2, BASE_THRESHOLD, BASE_MIN_THRESHOLD)
        spot_now2 = price_map.get(ts)
        spot_prev2 = price_map.get(ts - 60)
        if spot_now2 is not None and spot_prev2 is not None and spot_prev2 != 0:
            spot_ret2 = spot_now2 / spot_prev2 - 1
            adverse = (side == "yes" and spot_ret2 <= -threshold) or (side == "no" and spot_ret2 >= threshold)
            if adverse:
                price_side_now = p if side == "yes" else (1 - p)
                return {"payoff": (price_side_now - cost) * size_frac}
    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff * size_frac}


def evaluate(records, price_map, sim_fn, param, bet_size=100.0):
    payoffs = []
    for r in records:
        out = sim_fn(r["candles"], r["close_ts"], r["result"], price_map, param)
        if out is None:
            continue
        payoffs.append(out["payoff"])
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "non_negative": non_negative,
            "avg_payoff": statistics.mean(payoffs) * bet_size,
            "total_payoff": sum(payoffs) * bet_size}


def run_strict_direction(records, price_map, train, test):
    print("--- combo_floor_plus_spot_direction_strict ---")
    best = None
    for margin in [0.00002, 0.00005, 0.0001, 0.0002, 0.0003]:
        res = evaluate(train, price_map, lambda c, cl, r, pm, m=margin: simulate_strict_direction(c, cl, r, pm, m), margin)
        if res:
            print(f"  strict_margin={margin}: n={res['n']} non-neg={res['non_negative']:.2%} "
                  f"avgPay/$100={res['avg_payoff']:+.2f} total=${res['total_payoff']:+.2f}")
            if best is None or res["non_negative"] > best[0]["non_negative"]:
                best = (res, margin)
    baseline_train = evaluate(train, price_map, lambda c, cl, r, pm, m=0: simulate_strict_direction(c, cl, r, pm, -1), 0)
    if best:
        _, best_margin = best
        test_res = evaluate(test, price_map, lambda c, cl, r, pm, m=best_margin: simulate_strict_direction(c, cl, r, pm, m), best_margin)
        baseline_test = evaluate(test, price_map, lambda c, cl, r, pm, m=0: simulate_strict_direction(c, cl, r, pm, -1), 0)
        print(f"\nHOLDOUT baseline (no strict direction requirement): n={baseline_test['n']} "
              f"non-neg={baseline_test['non_negative']:.2%} avgPay/$100={baseline_test['avg_payoff']:+.2f} "
              f"total=${baseline_test['total_payoff']:+.2f}")
        print(f"HOLDOUT strict_margin={best_margin}: n={test_res['n']} non-neg={test_res['non_negative']:.2%} "
              f"avgPay/$100={test_res['avg_payoff']:+.2f} total=${test_res['total_payoff']:+.2f}")
        return {
            "train_result": f"best margin={best_margin}: n={best[0]['n']} non-neg={best[0]['non_negative']:.2%} "
                             f"avgPay/$100={best[0]['avg_payoff']:+.2f}",
            "holdout_result": f"baseline: n={baseline_test['n']} non-neg={baseline_test['non_negative']:.2%} "
                               f"avgPay/$100={baseline_test['avg_payoff']:+.2f} total=${baseline_test['total_payoff']:+.2f} "
                               f"| strict: n={test_res['n']} non-neg={test_res['non_negative']:.2%} "
                               f"avgPay/$100={test_res['avg_payoff']:+.2f} total=${test_res['total_payoff']:+.2f}",
        }
    return None


def simulate_joint(candles, close_ts, result, price_map, entry_minutes, confidence_floor):
    """Same logic as the deployed strategy (entry filter + adaptive-gap
    defensive exit), but entry_minutes and confidence_floor are searched
    jointly instead of one at a time."""
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None
    entry_idx = find_entry_idx(prices, close_ts, entry_minutes, confidence_floor)
    if entry_idx is None or entry_idx >= len(prices) - 1:
        return None
    entry_ts, entry_price = prices[entry_idx]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    spot_now = price_map.get(entry_ts)
    spot_prev = price_map.get(entry_ts - 60)
    if spot_now is not None and spot_prev is not None and spot_prev != 0:
        spot_ret = spot_now / spot_prev - 1
        adverse_at_entry = (side == "yes" and spot_ret <= -BASE_ENTRY_FILTER) or \
                            (side == "no" and spot_ret >= BASE_ENTRY_FILTER)
        if adverse_at_entry:
            return None

    for ts, p in prices[entry_idx + 1:]:
        confidence = max(p, 1 - p)
        threshold = adaptive_threshold(confidence, BASE_THRESHOLD, BASE_MIN_THRESHOLD)
        spot_now2 = price_map.get(ts)
        spot_prev2 = price_map.get(ts - 60)
        if spot_now2 is not None and spot_prev2 is not None and spot_prev2 != 0:
            spot_ret2 = spot_now2 / spot_prev2 - 1
            adverse = (side == "yes" and spot_ret2 <= -threshold) or (side == "no" and spot_ret2 >= threshold)
            if adverse:
                price_side_now = p if side == "yes" else (1 - p)
                return {"payoff": price_side_now - cost}
    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff}


def evaluate_joint(records, price_map, entry_minutes, confidence_floor, bet_size=100.0):
    payoffs = []
    for r in records:
        out = simulate_joint(r["candles"], r["close_ts"], r["result"], price_map, entry_minutes, confidence_floor)
        if out is None:
            continue
        payoffs.append(out["payoff"])
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "non_negative": non_negative,
            "avg_payoff": statistics.mean(payoffs) * bet_size,
            "total_payoff": sum(payoffs) * bet_size}


def run_joint_sweep(records, price_map, train, test):
    print("--- entry_minutes_confidence_floor_joint_sweep ---")
    baseline = evaluate_joint(test, price_map, BASE_ENTRY_MINUTES, BASE_CONFIDENCE_FLOOR)
    print(f"  current deployed setting (3.5min, 58% floor) HOLDOUT: n={baseline['n']} "
          f"non-neg={baseline['non_negative']:.2%} avgPay/$100={baseline['avg_payoff']:+.2f} "
          f"total=${baseline['total_payoff']:+.2f}")
    best = None
    grid = []
    for em in [2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0]:
        for cf in [0.50, 0.55, 0.58, 0.62, 0.65, 0.70]:
            res = evaluate_joint(train, price_map, em, cf)
            if res and res["n"] >= 30:
                grid.append((res, em, cf))
    grid.sort(key=lambda x: (-x[0]["non_negative"], -x[0]["total_payoff"]))
    print("  top 5 TRAIN combos by non-neg then total payoff:")
    for res, em, cf in grid[:5]:
        print(f"    entry_minutes={em} floor={cf:.0%}: n={res['n']} non-neg={res['non_negative']:.2%} "
              f"avgPay/$100={res['avg_payoff']:+.2f} total=${res['total_payoff']:+.2f}")
    if grid:
        _, best_em, best_cf = grid[0]
        test_res = evaluate_joint(test, price_map, best_em, best_cf)
        print(f"\nHOLDOUT best combo (entry_minutes={best_em}, floor={best_cf:.0%}): n={test_res['n']} "
              f"non-neg={test_res['non_negative']:.2%} avgPay/$100={test_res['avg_payoff']:+.2f} "
              f"total=${test_res['total_payoff']:+.2f}")
        return {
            "train_result": f"best combo entry_minutes={best_em} floor={best_cf:.0%}: n={grid[0][0]['n']} "
                             f"non-neg={grid[0][0]['non_negative']:.2%} avgPay/$100={grid[0][0]['avg_payoff']:+.2f}",
            "holdout_result": f"current deployed (3.5min/58%): n={baseline['n']} non-neg={baseline['non_negative']:.2%} "
                               f"total=${baseline['total_payoff']:+.2f} | best joint combo "
                               f"(entry_minutes={best_em}/floor={best_cf:.0%}): n={test_res['n']} "
                               f"non-neg={test_res['non_negative']:.2%} avgPay/$100={test_res['avg_payoff']:+.2f} "
                               f"total=${test_res['total_payoff']:+.2f}",
        }
    return None


def run_soft_size(records, price_map, train, test):
    print("--- position_size_soft_scale_by_confidence ---")
    baseline_train = evaluate(train, price_map, lambda c, cl, r, pm, m=1.0: simulate_soft_size(c, cl, r, pm, m), 1.0)
    print(f"  TRAIN baseline (full size always, no floor): n={baseline_train['n']} "
          f"non-neg={baseline_train['non_negative']:.2%} avgPay/$100={baseline_train['avg_payoff']:+.2f} "
          f"total=${baseline_train['total_payoff']:+.2f}")
    best = None
    for min_frac in [0.1, 0.2, 0.3, 0.4, 0.5]:
        res = evaluate(train, price_map, lambda c, cl, r, pm, m=min_frac: simulate_soft_size(c, cl, r, pm, m), min_frac)
        if res:
            print(f"  min_size_frac={min_frac}: n={res['n']} non-neg={res['non_negative']:.2%} "
                  f"avgPay/$100={res['avg_payoff']:+.2f} total=${res['total_payoff']:+.2f}")
            if best is None or res["total_payoff"] > best[0]["total_payoff"]:
                best = (res, min_frac)
    if best:
        _, best_frac = best
        test_res = evaluate(test, price_map, lambda c, cl, r, pm, m=best_frac: simulate_soft_size(c, cl, r, pm, m), best_frac)
        baseline_test = evaluate(test, price_map, lambda c, cl, r, pm, m=1.0: simulate_soft_size(c, cl, r, pm, m), 1.0)
        print(f"\nHOLDOUT baseline (full size, no floor): n={baseline_test['n']} "
              f"non-neg={baseline_test['non_negative']:.2%} avgPay/$100={baseline_test['avg_payoff']:+.2f} "
              f"total=${baseline_test['total_payoff']:+.2f}")
        print(f"HOLDOUT min_size_frac={best_frac}: n={test_res['n']} non-neg={test_res['non_negative']:.2%} "
              f"avgPay/$100={test_res['avg_payoff']:+.2f} total=${test_res['total_payoff']:+.2f}")
        return {
            "train_result": f"best min_size_frac={best_frac}: n={best[0]['n']} non-neg={best[0]['non_negative']:.2%} "
                             f"avgPay/$100={best[0]['avg_payoff']:+.2f} total=${best[0]['total_payoff']:+.2f}",
            "holdout_result": f"baseline(full size): n={baseline_test['n']} non-neg={baseline_test['non_negative']:.2%} "
                               f"total=${baseline_test['total_payoff']:+.2f} | soft-sized: n={test_res['n']} "
                               f"non-neg={test_res['non_negative']:.2%} total=${test_res['total_payoff']:+.2f}",
        }
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-all", action="store_true", help="Run every untested candidate.")
    args = parser.parse_args()

    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.")
    price_map = build_price_map(records)
    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    runners = {
        "combo_floor_plus_spot_direction_strict": run_strict_direction,
        "position_size_soft_scale_by_confidence": run_soft_size,
        "entry_minutes_confidence_floor_joint_sweep": run_joint_sweep,
    }

    ran_any = False
    for candidate in CANDIDATES:
        if candidate["kind"] not in ("entry_combo_strict_direction", "soft_size_by_confidence",
                                       "joint_entry_minutes_floor"):
            continue
        if already_tested(candidate["id"]):
            print(f"[SKIP] {candidate['id']} already in the research log.\n")
            continue
        runner = runners.get(candidate["id"])
        if runner is None:
            continue
        print(f"\n{'=' * 70}\nTESTING: {candidate['id']}\n{candidate['description']}\n{'=' * 70}")
        result = runner(records, price_map, train, test)
        ran_any = True
        if result:
            verdict = "NEEDS HUMAN REVIEW"  # agent never self-declares VALIDATED for deployment
            entry = {
                "id": candidate["id"],
                "date": dt.date.today().isoformat(),
                "hypothesis": candidate["description"],
                "data_source": "1-min Kalshi candles + 1-min spot candles, generated by kalshi_research_agent.py",
                "train_result": result["train_result"],
                "holdout_result": result["holdout_result"],
                "verdict": verdict,
                "notes": "Auto-generated by the research agent. Requires human review before any deployment "
                         "- see SAFETY BOUNDARY in kalshi_research_agent.py.",
            }
            append_to_log(entry)
            print(f"\n[LOGGED] {candidate['id']} -> {LOG_PATH}")
        if not args.run_all:
            break

    if not ran_any:
        print("No untested candidates remain in the current candidate space.")


if __name__ == "__main__":
    main()
