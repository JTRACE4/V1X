def prices_from_candles(candles):
    sorted_candles = sorted(candles, key=lambda c: c["end_period_ts"])
    prices = []
    for c in sorted_candles:
        p = c.get("price", {}).get("close_dollars")
        if p is not None:
            prices.append((c["end_period_ts"], float(p)))
    return prices


def simulate_exit(prices, entry_idx, cost, side, result, lock_in_threshold, trail_amount, hard_stop_amount):
    """Walk forward from prices[entry_idx+1:], applying a breakeven stop until the
    position locks in >= lock_in_threshold profit, after which a trailing stop of
    `trail_amount` takes over. Falls back to settlement if neither ever triggers."""
    peak_payoff = 0.0
    for ts, p in prices[entry_idx + 1:]:
        price_side_now = p if side == "yes" else (1 - p)
        payoff_now = price_side_now - cost
        peak_payoff = max(peak_payoff, payoff_now)

        if peak_payoff >= lock_in_threshold:
            if payoff_now <= peak_payoff - trail_amount:
                return {"payoff": payoff_now, "reason": "trailing_stop", "cost": cost}
        else:
            if payoff_now <= -hard_stop_amount:
                return {"payoff": payoff_now, "reason": "breakeven_stop", "cost": cost}

    settlement_payoff = (1 - cost) if result == side else -cost
    return {"payoff": settlement_payoff, "reason": "settlement", "cost": cost}
