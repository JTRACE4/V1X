"""Run the full validated strategy pipeline (fetch history, baseline, defensive exit
sweep + walk-forward check, entry filter sweep + walk-forward check) for any
Kalshi 15-min crypto series, not just BTC. Mirrors the process used to validate
close_favorite on BTC, applied to a new asset."""
import argparse

from src.kalshi_fetch_paths import fetch_and_cache, cache_path_for
from src.kalshi_path_backtest import load_records as load_records_path, evaluate as evaluate_path
from src.kalshi_momentum_backtest import build_spot_minute_map
from src.kalshi_defensive_exit_backtest import evaluate as evaluate_defensive
from src.kalshi_entry_filter_backtest import evaluate as evaluate_entry_filter

ENTRY_MINUTES = 3
DEFENSIVE_THRESHOLDS = [0.0002, 0.00025, 0.0003, 0.00035, 0.0004, 0.00045, 0.0005]
ENTRY_FILTER_THRESHOLDS = [0.00005, 0.0001, 0.00015, 0.0002, 0.00025, 0.0003]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--series", required=True, help="e.g. KXETH15M")
    parser.add_argument("--symbol", required=True, help="Coinbase symbol, e.g. ETH-USD")
    parser.add_argument("--n-markets", type=int, default=4000)
    parser.add_argument("--bet-size", type=float, default=100.0)
    args = parser.parse_args()

    import os
    cache_path = cache_path_for(args.series)
    if os.path.exists(cache_path):
        print(f"Using existing cache at {cache_path}")
        records = load_records_path(series=args.series)
    else:
        records = fetch_and_cache(args.n_markets, series=args.series)

    print(f"\n{len(records)} usable markets for {args.series} / {args.symbol}")
    spot_map = build_spot_minute_map(records, symbol=args.symbol)

    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}")

    print(f"\n=== {args.series}: baseline (hold to settlement, entry={ENTRY_MINUTES}min) ===")
    baseline = evaluate_path(records, ENTRY_MINUTES, lock_in=999, trail=999, hard_stop=999)
    if baseline:
        print(f"n={baseline['n']} non-neg={baseline['pct_non_negative']:.2%} "
              f"avgPay/$100={baseline['avg_payoff'] * args.bet_size:+.2f}")
    else:
        print("Not enough data to evaluate baseline.")
        return

    print(f"\n=== defensive exit: selecting threshold on TRAIN only ===")
    best_def_threshold, best_def_nonneg = None, -1
    for threshold in DEFENSIVE_THRESHOLDS:
        res = evaluate_defensive(train, spot_map, ENTRY_MINUTES, threshold)
        if res:
            print(f"  {threshold:.5f}: train non-neg={res['non_negative']:.2%} "
                  f"avgPay/$100={res['avg_payoff'] * args.bet_size:+.2f}")
            if res["non_negative"] > best_def_nonneg:
                best_def_nonneg, best_def_threshold = res["non_negative"], threshold

    if best_def_threshold is None:
        print("No usable defensive-exit result on train data.")
        return

    print(f"\n=== defensive exit ({best_def_threshold}) validated on HOLDOUT ===")
    base_test = evaluate_defensive(test, spot_map, ENTRY_MINUTES, 999)
    def_test = evaluate_defensive(test, spot_map, ENTRY_MINUTES, best_def_threshold)
    print(f"hold-only on holdout:      n={base_test['n']} non-neg={base_test['non_negative']:.2%} "
          f"avgPay/$100={base_test['avg_payoff'] * args.bet_size:+.2f}")
    print(f"+ defensive exit holdout:  n={def_test['n']} non-neg={def_test['non_negative']:.2%} "
          f"avgPay/$100={def_test['avg_payoff'] * args.bet_size:+.2f}")

    print(f"\n=== entry filter: selecting threshold on TRAIN only (using defensive exit {best_def_threshold}) ===")
    best_ef_threshold, best_ef_nonneg = None, -1
    for threshold in ENTRY_FILTER_THRESHOLDS:
        res = evaluate_entry_filter(train, spot_map, ENTRY_MINUTES, best_def_threshold, threshold)
        if res:
            print(f"  {threshold:.5f}: train non-neg={res['non_negative']:.2%} "
                  f"avgPay/$100={res['avg_payoff'] * args.bet_size:+.2f} skipped={res['skipped']}")
            if res["non_negative"] > best_ef_nonneg:
                best_ef_nonneg, best_ef_threshold = res["non_negative"], threshold

    if best_ef_threshold is not None:
        print(f"\n=== entry filter ({best_ef_threshold}) validated on HOLDOUT ===")
        ef_test = evaluate_entry_filter(test, spot_map, ENTRY_MINUTES, best_def_threshold, best_ef_threshold)
        print(f"defensive exit only on holdout:      n={def_test['n']} non-neg={def_test['non_negative']:.2%} "
              f"avgPay/$100={def_test['avg_payoff'] * args.bet_size:+.2f}")
        print(f"+ entry filter on holdout:            n={ef_test['n']} skipped={ef_test['skipped']} "
              f"non-neg={ef_test['non_negative']:.2%} avgPay/$100={ef_test['avg_payoff'] * args.bet_size:+.2f}")

    print(f"\n=== SUMMARY for {args.series} ===")
    print(f"recommended defensive_exit_threshold = {best_def_threshold}")
    print(f"recommended entry_filter_threshold = {best_ef_threshold}")


if __name__ == "__main__":
    main()
