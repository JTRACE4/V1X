"""Tests whether REAL spot market activity (Coinbase BTC-USD volume + price,
not Kalshi's own lagging/noisy trade data) in the minute before entry predicts
a reversal. Hypothesis: a genuine volume surge in the real market right before
entry - not just any small price wiggle - is what precedes an actual violent
move, since that's a real burst of trading activity (news, liquidations, etc),
not noise. Entirely local/cached data, no live API calls needed."""
import argparse
import datetime as dt
import statistics

from src.data import fetch_history
from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records
from src.kalshi_adaptive_gap_backtest import adaptive_threshold

EPS = 1e-9


def build_spot_maps(records, symbol="BTC-USD"):
    open_times = [dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")) for r in records]
    span_start = min(open_times)
    days = (dt.datetime.now(dt.timezone.utc) - span_start).days + 2
    print(f"Loading {symbol} spot 1m data covering {days} days...")
    spot_df = fetch_history(symbol=symbol, interval="1m", days=days)
    spot_df["minute_ts"] = spot_df["open_time"] // 1000
    price_map = dict(zip(spot_df["minute_ts"], spot_df["close"]))
    volume_map = dict(zip(spot_df["minute_ts"], spot_df["volume"]))
    avg_volume = spot_df["volume"].mean()
    print(f"Got {len(price_map)} spot minute bars. Average 1min volume: {avg_volume:.2f} BTC")
    return price_map, volume_map, avg_volume


def simulate(candles, close_ts, result, price_map, volume_map, avg_volume, entry_minutes,
             entry_filter_threshold, base_threshold, min_threshold, confidence_floor,
             volume_ratio_threshold):
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None

    window_start_ts = close_ts - entry_minutes * 60

    entry_idx = None
    if confidence_floor <= 0.5:
        for i, (ts, _) in enumerate(prices):
            if ts <= window_start_ts:
                entry_idx = i
            else:
                break
        if entry_idx is None:
            entry_idx = 0
    else:
        for i, (ts, p) in enumerate(prices):
            if ts < window_start_ts or ts >= close_ts:
                continue
            if max(p, 1 - p) >= confidence_floor:
                entry_idx = i
                break
        if entry_idx is None:
            return None

    if entry_idx >= len(prices) - 1:
        return None

    entry_ts, entry_price = prices[entry_idx]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    # real-market volume spike filter: skip if the last 1-2 minutes of spot
    # volume is running well above its normal average right at entry - a sign
    # of genuine active price discovery, not a stable/settled market.
    if volume_ratio_threshold is not None:
        minute_ts = int(entry_ts) // 60 * 60
        recent_vol = (volume_map.get(minute_ts, 0) or 0) + (volume_map.get(minute_ts - 60, 0) or 0)
        ratio = (recent_vol / 2) / avg_volume if avg_volume else 0
        if ratio > volume_ratio_threshold:
            return None

    if entry_filter_threshold is not None:
        spot_now = price_map.get(entry_ts)
        spot_prev = price_map.get(entry_ts - 60)
        if spot_now is not None and spot_prev is not None and spot_prev != 0:
            spot_ret = spot_now / spot_prev - 1
            adverse_at_entry = (side == "yes" and spot_ret <= -entry_filter_threshold) or \
                                (side == "no" and spot_ret >= entry_filter_threshold)
            if adverse_at_entry:
                return None

    for ts, p in prices[entry_idx + 1:]:
        confidence = max(p, 1 - p)
        threshold = adaptive_threshold(confidence, base_threshold, min_threshold)
        spot_now = price_map.get(ts)
        spot_prev = price_map.get(ts - 60)
        if spot_now is not None and spot_prev is not None and spot_prev != 0:
            spot_ret = spot_now / spot_prev - 1
            adverse = (side == "yes" and spot_ret <= -threshold) or \
                      (side == "no" and spot_ret >= threshold)
            if adverse:
                price_side_now = p if side == "yes" else (1 - p)
                return {"payoff": price_side_now - cost, "reason": "defensive_exit"}

    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff, "reason": "settlement"}


def evaluate(records, price_map, volume_map, avg_volume, entry_minutes, entry_filter,
             base_threshold, min_threshold, confidence_floor, volume_ratio_threshold, bet_size=100.0):
    payoffs = []
    skipped = 0
    for r in records:
        out = simulate(r["candles"], r["close_ts"], r["result"], price_map, volume_map, avg_volume,
                        entry_minutes, entry_filter, base_threshold, min_threshold, confidence_floor,
                        volume_ratio_threshold)
        if out is None:
            skipped += 1
            continue
        payoffs.append(out["payoff"])
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "skipped": skipped, "non_negative": non_negative,
            "avg_payoff": statistics.mean(payoffs) * bet_size,
            "total_payoff": sum(payoffs) * bet_size}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--entry-minutes", type=float, default=3.5)
    parser.add_argument("--entry-filter", type=float, default=0.00005)
    parser.add_argument("--base-threshold", type=float, default=0.00035)
    parser.add_argument("--min-threshold", type=float, default=0.00005)
    parser.add_argument("--confidence-floor", type=float, default=0.58)
    args = parser.parse_args()

    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.")
    price_map, volume_map, avg_volume = build_spot_maps(records)

    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    print("--- current setup (58% floor, no volume filter) baseline ---")
    for label, data in (("TRAIN", train), ("HOLDOUT", test)):
        res = evaluate(data, price_map, volume_map, avg_volume, args.entry_minutes, args.entry_filter,
                        args.base_threshold, args.min_threshold, args.confidence_floor, None)
        print(f"{label}: n={res['n']} non-neg={res['non_negative']:.2%} "
              f"avgPay/$100={res['avg_payoff']:+.2f} total=${res['total_payoff']:+.2f}")

    print("\n--- sweeping volume-ratio threshold on TRAIN (1.0 = normal avg volume) ---")
    best = None
    for vol_ratio in [1.5, 2.0, 2.5, 3.0, 4.0, 5.0, 8.0]:
        res = evaluate(train, price_map, volume_map, avg_volume, args.entry_minutes, args.entry_filter,
                        args.base_threshold, args.min_threshold, args.confidence_floor, vol_ratio)
        if res:
            print(f"  vol_ratio={vol_ratio:.1f}x: n={res['n']} (skipped {res['skipped']}) "
                  f"non-neg={res['non_negative']:.2%} avgPay/$100={res['avg_payoff']:+.2f} "
                  f"total=${res['total_payoff']:+.2f}")
            if best is None or res["non_negative"] > best[0]["non_negative"]:
                best = (res, vol_ratio)

    if best:
        _, best_ratio = best
        print(f"\n--- volume filter (ratio={best_ratio}x) validated on HOLDOUT ---")
        res = evaluate(test, price_map, volume_map, avg_volume, args.entry_minutes, args.entry_filter,
                        args.base_threshold, args.min_threshold, args.confidence_floor, best_ratio)
        print(f"n={res['n']} (skipped {res['skipped']}) non-neg={res['non_negative']:.2%} "
              f"avgPay/$100={res['avg_payoff']:+.2f} total=${res['total_payoff']:+.2f}")


if __name__ == "__main__":
    main()
