"""Tests how much WAITING costs once a defensive exit trigger fires, using
real historical trade data (not simulated fills). Motivated by a real loss:
the exit trigger correctly fired at spot_ret=-0.18% while price was still
~0.63, but the order kept failing to fill (buffer capped too low) and by the
time it finally executed 6 attempts later, price had crashed to 0.008. This
tests 5 configs for how many seconds/attempts to tolerate before forcing a
guaranteed-fill price, using the REAL market price N seconds after each
trigger (from Kalshi's trades endpoint) as the realistic exit price for that
config - not a fill-probability model, but a direct measurement of what
price was actually available at each point in time."""
import argparse
import csv
import datetime as dt
import os
import statistics
import time

from src.kalshi_favorite_backtest import BASE, _get, fetch_settled_markets
from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records, build_spot_minute_map
from src.kalshi_adaptive_gap_backtest import adaptive_threshold

EPS = 1e-9
ENTRY_MINUTES = 3.5
BASE_THRESHOLD = 0.00035
MIN_THRESHOLD = 0.00005

# each config = how many seconds after the trigger we're willing to keep
# trying a moderate price before forcing a guaranteed-cross exit. Fine-grained
# sweep (every ~1s) to pinpoint the exact best cutoff, not just compare a
# handful of coarse options.
CONFIGS = {f"force_after_{s}s" + (" (current fix)" if s == 3 else ""): s
           for s in [0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 15, 20]}


def find_trigger(candles, close_ts, spot_map, entry_minutes=ENTRY_MINUTES):
    """Finds the entry (fixed 3.5min mark, matching current live default) and
    the first point the adaptive-gap defensive exit would trigger. Returns
    (side, cost, trigger_ts, trigger_kalshi_price) or None if no trigger
    happened (position would have held to settlement)."""
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None
    entry_ts = close_ts - entry_minutes * 60
    entry_idx = None
    for i, (ts, _) in enumerate(prices):
        if ts <= entry_ts:
            entry_idx = i
        else:
            break
    if entry_idx is None:
        entry_idx = 0
    if entry_idx >= len(prices) - 1:
        return None
    entry_price = prices[entry_idx][1]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    for ts, p in prices[entry_idx + 1:]:
        confidence = max(p, 1 - p)
        threshold = adaptive_threshold(confidence, BASE_THRESHOLD, MIN_THRESHOLD)
        spot_now = spot_map.get(ts)
        spot_prev = spot_map.get(ts - 60)
        if spot_now is not None and spot_prev is not None and spot_prev != 0:
            spot_ret = spot_now / spot_prev - 1
            adverse = (side == "yes" and spot_ret <= -threshold) or (side == "no" and spot_ret >= threshold)
            if adverse:
                return {"side": side, "cost": cost, "trigger_ts": ts, "trigger_price": p}
    return None


def fetch_trades_after(ticker, trigger_ts, window_seconds=15, limit=1000):
    data = _get(f"{BASE}/markets/trades", params={"ticker": ticker, "limit": limit})
    trades = data.get("trades", [])
    out = []
    for t in trades:
        ts = dt.datetime.fromisoformat(t["created_time"].replace("Z", "+00:00")).timestamp()
        if trigger_ts <= ts <= trigger_ts + window_seconds:
            out.append((ts, float(t["yes_price_dollars"])))
    return sorted(out)


def price_at_delay(trigger_ts, delay_seconds, trigger_price, trades):
    """Real market price `delay_seconds` after the trigger. Falls back to the
    trigger price itself if no trade data is available at that offset (i.e.
    market didn't move further - a fine approximation)."""
    target = trigger_ts + delay_seconds
    eligible = [(ts, p) for ts, p in trades if ts <= target]
    if eligible:
        return eligible[-1][1]
    return trigger_price


def evaluate_market(m, spot_map, records_by_ticker):
    ticker = m["ticker"]
    r = records_by_ticker.get(ticker)
    if r is None:
        return None
    trigger = find_trigger(r["candles"], r["close_ts"], spot_map)
    if trigger is None:
        return None  # no defensive exit would have fired - not relevant to this test

    trades = fetch_trades_after(ticker, trigger["trigger_ts"], window_seconds=25)
    out = {}
    for label, delay in CONFIGS.items():
        exit_price = price_at_delay(trigger["trigger_ts"], delay, trigger["trigger_price"], trades)
        price_side_now = exit_price if trigger["side"] == "yes" else (1 - exit_price)
        payoff = price_side_now - trigger["cost"]
        out[label] = payoff
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-markets", type=int, default=600)
    args = parser.parse_args()

    print("Loading cached BTC price paths and spot data...")
    records = load_records(series="KXBTC15M")
    spot_map = build_spot_minute_map(records)
    records_by_ticker = {r["ticker"]: r for r in records}

    print(f"Fetching last {args.n_markets} settled markets to check for trigger events...")
    markets = fetch_settled_markets(args.n_markets, series="KXBTC15M")
    print(f"Got {len(markets)} settled markets. Finding trigger events and pulling real trade data...")

    csv_path = os.path.join(os.path.dirname(__file__), "..", "bot_state", "exit_speed_per_event.csv")
    csv_fields = ["ticker"] + list(CONFIGS.keys())
    csv_file = open(csv_path, "w", newline="")
    csv_writer = csv.DictWriter(csv_file, fieldnames=csv_fields)
    csv_writer.writeheader()

    results = {label: [] for label in CONFIGS}
    n_triggers = 0
    for i, m in enumerate(markets):
        try:
            out = evaluate_market(m, spot_map, records_by_ticker)
        except Exception as exc:
            out = None
        if out is not None:
            n_triggers += 1
            for label, payoff in out.items():
                results[label].append(payoff)
            csv_writer.writerow({"ticker": m["ticker"], **out})
            csv_file.flush()
        if (i + 1) % 100 == 0:
            print(f"  ...{i + 1}/{len(markets)} processed, {n_triggers} trigger events found so far")
        time.sleep(0.1)

    csv_file.close()
    print(f"\n=== {n_triggers} real defensive-exit trigger events found across {len(markets)} markets ===")
    print(f"Per-event data saved to {csv_path}\n")
    if n_triggers == 0:
        print("No trigger events found - nothing to compare.")
        return

    bet_size = 100.0
    print("--- ALL trigger events ---")
    print(f"{'config':>32} | {'n':>5} | {'non-neg':>8} | {'avg payoff/$100':>16} | {'total/$100':>12}")
    for label in CONFIGS:
        payoffs = results[label]
        n = len(payoffs)
        non_neg = sum(1 for p in payoffs if p >= -EPS) / n if n else 0
        avg = statistics.mean(payoffs) * bet_size if n else 0
        total = sum(payoffs) * bet_size if n else 0
        print(f"{label:>32} | {n:>5} | {non_neg:>7.2%} | {avg:>+15.2f} | {total:>+11.2f}")

    # worst-case tail: rank events by their force_after_0s outcome (a proxy
    # for "how bad did the underlying move get"), then compare configs only
    # within the worst 10% - this is the regime last night's real loss was in.
    zero_s_label = "force_after_0s"
    n_all = len(results[zero_s_label])
    order = sorted(range(n_all), key=lambda i: results[zero_s_label][i])
    worst_n = max(1, n_all // 10)
    worst_idx = set(order[:worst_n])

    print(f"\n--- WORST 10% of events by outcome (n={worst_n}) - the regime last night's loss was in ---")
    print(f"{'config':>32} | {'n':>5} | {'non-neg':>8} | {'avg payoff/$100':>16} | {'total/$100':>12}")
    for label in CONFIGS:
        payoffs = [results[label][i] for i in worst_idx]
        n = len(payoffs)
        non_neg = sum(1 for p in payoffs if p >= -EPS) / n if n else 0
        avg = statistics.mean(payoffs) * bet_size if n else 0
        total = sum(payoffs) * bet_size if n else 0
        print(f"{label:>32} | {n:>5} | {non_neg:>7.2%} | {avg:>+15.2f} | {total:>+11.2f}")


if __name__ == "__main__":
    main()
