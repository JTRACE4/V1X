"""Tests the actual trading claim behind a linear regression channel: when price
touches the upper/lower band, does it tend to revert back toward the regression
line (mean reversion, the classic use of this indicator) or break through and
continue (momentum)? Tested against real BTC-USD 1-minute history."""
import numpy as np

from src.data import fetch_history

LOOKBACKS = [20, 50, 100]
BAND_MULTIPLIERS = [2.0]
HORIZONS_MIN = [1, 3, 5, 10]


def compute_channel_signals(closes, lookback, band_mult):
    """For each point t, fit a linear regression on closes[t-lookback:t], and check
    whether closes[t] is at/beyond the upper or lower band. Returns a list of
    (index, direction) for touch events, direction=+1 for upper touch, -1 for lower."""
    n = len(closes)
    touches = []
    x = np.arange(lookback)
    for t in range(lookback, n):
        window = closes[t - lookback:t]
        slope, intercept = np.polyfit(x, window, 1)
        fitted = slope * x + intercept
        resid_std = np.std(window - fitted)
        if resid_std == 0:
            continue
        # projected regression value at the current point (one step past the window)
        projected = slope * lookback + intercept
        upper = projected + band_mult * resid_std
        lower = projected - band_mult * resid_std
        price = closes[t]
        if price >= upper:
            touches.append((t, 1, projected))
        elif price <= lower:
            touches.append((t, -1, projected))
    return touches


def evaluate(closes, touches, horizon_min):
    """For each touch event, does price over the next horizon_min minutes move
    back toward the regression line (reversion, positive score) or away from it
    (continuation, negative score)?"""
    reversion_count = 0
    continuation_count = 0
    moves = []
    for t, direction, projected in touches:
        if t + horizon_min >= len(closes):
            continue
        future_price = closes[t + horizon_min]
        move = future_price - closes[t]
        # if direction==1 (touched upper band), reversion means price falls (move<0)
        # if direction==-1 (touched lower band), reversion means price rises (move>0)
        signed_move = -move * direction
        moves.append(signed_move)
        if signed_move > 0:
            reversion_count += 1
        elif signed_move < 0:
            continuation_count += 1
    n = len(moves)
    if n == 0:
        return None
    return {
        "n": n,
        "reversion_pct": reversion_count / n,
        "continuation_pct": continuation_count / n,
        "avg_signed_move": np.mean(moves),
        "avg_signed_move_pct": np.mean(moves) / np.mean(closes) * 100,
    }


def main():
    print("Fetching BTC-USD 1-minute history...")
    df = fetch_history(symbol="BTC-USD", interval="1m", days=45)
    closes = df["close"].values
    print(f"Got {len(closes)} minute bars.\n")

    for lookback in LOOKBACKS:
        for band_mult in BAND_MULTIPLIERS:
            touches = compute_channel_signals(closes, lookback, band_mult)
            n_upper = sum(1 for _, d, _ in touches if d == 1)
            n_lower = sum(1 for _, d, _ in touches if d == -1)
            print(f"=== lookback={lookback}min, band={band_mult}std: "
                  f"{len(touches)} touch events ({n_upper} upper, {n_lower} lower) ===")
            print(f"  {'horizon':>8} {'n':>6} {'reversion%':>11} {'continuation%':>14} {'avg_signed_move($)':>19}")
            for horizon in HORIZONS_MIN:
                res = evaluate(closes, touches, horizon)
                if res:
                    print(f"  {horizon:>7}m {res['n']:>6} {res['reversion_pct']:>10.1%} "
                          f"{res['continuation_pct']:>13.1%} {res['avg_signed_move']:>19.2f}")
            print()


if __name__ == "__main__":
    main()
