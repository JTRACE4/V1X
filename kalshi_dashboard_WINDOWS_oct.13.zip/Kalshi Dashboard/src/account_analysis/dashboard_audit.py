"""Read-only audit of the live dashboard: every number it shows is re-derived from an independent source and compared.
Run: python -m src.account_analysis.dashboard_audit   (needs the dashboard running on :8765)
Prints PASS / WARN / FAIL per check. Never writes anything and never touches trading."""
import csv
import datetime as dt
import html as _html
import json
import math
import os
import re
import sys
import time
import urllib.request
from zoneinfo import ZoneInfo

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
B = "http://127.0.0.1:8765"
ET = ZoneInfo("America/New_York")
ROOT = os.path.join(os.path.dirname(__file__), "..", "..")
RES = []


def get(url, data=None, headers=None, timeout=15):
    h = {"User-Agent": "audit"}
    h.update(headers or {})
    return json.loads(urllib.request.urlopen(urllib.request.Request(url, data=data, headers=h), timeout=timeout).read())


def rec(level, name, detail):
    RES.append((level, name, detail))
    print(f"[{level}] {name}: {detail}")


def txt(s):
    return re.sub(r"\s+", " ", _html.unescape(re.sub(r"<[^>]+>", " ", s))).strip()


def cards():
    h = json.loads(urllib.request.urlopen(B + "/data", timeout=15).read())["html"]
    parts = re.split(r'(?=<div class="card" data-asset=")', h)
    out = {}
    for p in parts:
        m = re.match(r'<div class="card" data-asset="(\w+)"', p)
        if m:
            out[m.group(1)] = p
    return out


def money(s):
    return float(re.sub(r"[^\d.]", "", s))


def main():
    cs = cards()
    for asset in ("BTC", "XRP"):
        c = cs.get(asset)
        if not c:
            rec("FAIL", f"{asset} card", "missing from the page")
            continue
        sym = "BTC-USD" if asset == "BTC" else "XRP-USD"
        # ---------------- live price vs the exchanges
        try:
            m = re.search(r'class="live-price-inline">.*?class="big[^"]*">\$?([\d,\.]+)<', c, re.S)
            shown = money(m.group(1))
            cb = float(get(f"https://api.exchange.coinbase.com/products/{sym}/ticker")["price"])
            kr = float(next(iter(get(f"https://api.kraken.com/0/public/Ticker?pair={'XBTUSD' if asset == 'BTC' else 'XRPUSD'}")["result"].values()))["c"][0])
            dev = max(abs(shown - cb), abs(shown - kr)) / cb * 1e4
            rec("PASS" if dev < 4 else "WARN", f"{asset} live price", f"shown {shown} | coinbase {cb} | kraken {kr} | max gap {dev:.1f} bps")
        except Exception as e:
            rec("FAIL", f"{asset} live price", repr(e)[:120])
        # ---------------- Kalshi target and Kalshi's own price
        try:
            lk = json.loads(urllib.request.urlopen(B + "/locked", timeout=10).read())[asset]
            ticker = lk["ticker"]
            mk = get(f"https://external-api.kalshi.com/trade-api/v2/markets/{ticker}")["market"]
            m = re.search(r'class="live-price-inline">.*?Kalshi target</div>\s*<div class="big">\$?([\d,\.]+)<', c, re.S)
            tgt = money(m.group(1))
            strike = float(mk.get("floor_strike") or 0)
            rec("PASS" if abs(tgt - strike) < 0.01 * max(1, strike) * 1e-3 + 0.011 else "FAIL", f"{asset} Kalshi target", f"shown {tgt} | Kalshi floor_strike {strike}")
            yes_mid = None
            if mk.get("yes_bid_dollars") is not None:
                yes_mid = (float(mk["yes_bid_dollars"]) + float(mk["yes_ask_dollars"])) / 2
            elif mk.get("yes_bid") is not None:
                yes_mid = (mk["yes_bid"] + mk["yes_ask"]) / 200
            m = re.search(r"(YES|NO) @ ([\d\.]+)%", txt(c))
            if m and yes_mid is not None:
                conf = float(m.group(2)) / 100
                shown_yes = conf if m.group(1) == "YES" else 1 - conf
                rec("PASS" if abs(shown_yes - yes_mid) < 0.06 else "WARN", f"{asset} Kalshi price", f"shown YES {shown_yes:.3f} | Kalshi bid/ask mid {yes_mid:.3f}")
            # ---------------- clock vs the ticker's close time
            fresh = cards().get(asset, c)          # re-read the page right now (the copy from the start of the audit is several seconds old by here)
            m = re.search(r'class="clock[^"]*"[^>]*>.*?<span>(\d+):(\d\d)</span>', fresh, re.S)
            close = dt.datetime.fromisoformat(mk["close_time"].replace("Z", "+00:00"))
            left = (close - dt.datetime.now(dt.timezone.utc)).total_seconds()
            shown_left = int(m.group(1)) * 60 + int(m.group(2))
            rec("PASS" if abs(left - shown_left) <= 6 else "FAIL", f"{asset} timer", f"shown {shown_left}s | real {left:.0f}s to close")
            # ---------------- Kalshi arrow vs its own numbers
            m2 = re.search(r'class="kalshi-arrow" data-name="\w+" data-angle="([-\d.]+)" data-color="(#\w+)"', c)
            m3 = re.search(r"(YES|NO) @ ([\d\.]+)%", txt(c))
            if m2 and m3:
                conf = float(m3.group(2)) / 100
                yes = conf if m3.group(1) == "YES" else 1 - conf
                exp = -(yes - 0.5) / 0.5 * 90
                rec("PASS" if abs(float(m2.group(1)) - exp) < 2.5 else "WARN", f"{asset} knight sword angle", f"shown {m2.group(1)} deg | expected {exp:.1f} deg for YES {yes:.2f} (can lag one refresh)")
        except Exception as e:
            rec("FAIL", f"{asset} kalshi checks", repr(e)[:150])
        # ---------------- flip chance gauge recomputed
        try:
            import src.kalshi_web_dashboard as d
            m = re.search(r'data-flip-chance-pct="([\d.]+)"', c)
            pct = float(m.group(1))
            mm = re.search(r"(YES|NO) @ ([\d\.]+)%", txt(c))
            lock = json.loads(urllib.request.urlopen(B + "/locked", timeout=10).read())[asset]
            if lock["locked_call"] and mm:
                conf = float(mm.group(2)) / 100
                lean = mm.group(1)
                kp = conf if lean == "YES" else 1 - conf
                exp = d.flip_chance_vs_locked_call(kp, lock["locked_call"], conf) * 100
                rec("PASS" if abs(exp - pct) < 1.5 else "WARN", f"{asset} flip chance", f"shown {pct:.1f}% | recomputed {exp:.1f}% (locked {lock['locked_call']}, Kalshi {lean} {conf:.1%})")
            else:
                rec("PASS", f"{asset} flip chance", f"no locked call right now; gauge shows {pct:.1f}%")
        except Exception as e:
            rec("WARN", f"{asset} flip chance", repr(e)[:120])
        # ---------------- pressure table: Coinbase + Binance rows vs independent trade tapes
        try:
            rows = re.findall(r"<tr[^>]*><td>([^<]+)</td><td><div class=\"press-mini\">.*?</td><td>([^<]*)</td><td>([^<]*)</td><td>([^<]*)</td><td>([^<]*)</td></tr>", c, re.S)
            table = {r[0]: r for r in rows}
            # Coinbase: last 60s of real trades, taker side = opposite of the resting (maker) side
            tr = get(f"https://api.exchange.coinbase.com/products/{sym}/trades?limit=1000")
            now = time.time()
            buy = sell = 0.0
            for t in tr:
                ts = dt.datetime.fromisoformat(t["time"].replace("Z", "+00:00")).timestamp()
                if now - ts <= 60:
                    usd = float(t["price"]) * float(t["size"])
                    if t["side"] == "sell":   # maker sold -> taker bought
                        buy += usd
                    else:
                        sell += usd
            ref_pct = 100 * buy / (buy + sell) if buy + sell else None
            row = table.get("Coinbase")
            if row and row[1] and ref_pct is not None:
                shown_pct = float(row[1].strip("%"))
                rec("PASS" if abs(shown_pct - ref_pct) < 18 else "WARN", f"{asset} Coinbase buy% (table vs REST tape)", f"table {shown_pct:.0f}% | tape {ref_pct:.0f}% over ~60s (tapes are sampled a few seconds apart)")
            # Binance spot via the public data endpoint
            bs = get(f"https://data-api.binance.vision/api/v3/trades?symbol={asset}USDT&limit=1000")
            bb = bsell = 0.0
            for t in bs:
                if now * 1000 - t["time"] <= 60000:
                    usd = float(t["quoteQty"])
                    if t["isBuyerMaker"]:
                        bsell += usd
                    else:
                        bb += usd
            ref_b = 100 * bb / (bb + bsell) if bb + bsell else None
            row = table.get("Binance")
            if row and row[1] and ref_b is not None:
                shown_pct = float(row[1].strip("%"))
                rec("PASS" if abs(shown_pct - ref_b) < 18 else "WARN", f"{asset} Binance buy% (table vs REST tape)", f"table {shown_pct:.0f}% | tape {ref_b:.0f}% over ~60s")
            # internal consistency of the bar
            m = re.search(r'class="press-buy" style="width:([\d.]+)%".*?class="press-sell" style="width:([\d.]+)%"', c, re.S)
            if m:
                rec("PASS" if abs(float(m.group(1)) + float(m.group(2)) - 100) < 0.2 else "FAIL", f"{asset} pressure bar", f"buy {m.group(1)}% + sell {m.group(2)}% = {float(m.group(1)) + float(m.group(2)):.1f}")
            live = re.search(r"(\d+) exchanges live", txt(c))
            rec("PASS" if live and int(live.group(1)) >= 13 else "WARN", f"{asset} exchanges feeding", live.group(0) if live else "not found")
        except Exception as e:
            rec("WARN", f"{asset} pressure cross-check", repr(e)[:150])
        # ---------------- derivatives line
        try:
            t = txt(c)
            m = re.search(r"open interest \$([\d\.]+)([BM])", t)
            if m:
                shown = float(m.group(1)) * (1e9 if m.group(2) == "B" else 1e6)
                inst = f"{asset}-USDT-SWAP"
                okx = float(get(f"https://www.okx.com/api/v5/public/open-interest?instId={inst}")["data"][0]["oiUsd"])
                hl = get("https://api.hyperliquid.xyz/info", json.dumps({"type": "metaAndAssetCtxs"}).encode(), {"Content-Type": "application/json"})
                names = [u["name"] for u in hl[0]["universe"]]
                x = hl[1][names.index(asset)]
                hlusd = float(x["openInterest"]) * float(x["markPx"])
                exp = okx + hlusd + (float(get("https://www.deribit.com/api/v2/public/ticker?instrument_name=BTC-PERPETUAL")["result"]["open_interest"]) if asset == "BTC" else 0)
                rec("PASS" if abs(shown - exp) / exp < 0.08 else "WARN", f"{asset} open interest", f"shown ${shown/1e6:.0f}M | OKX+Hyperliquid{'+Deribit' if asset == 'BTC' else ''} ${exp/1e6:.0f}M")
        except Exception as e:
            rec("WARN", f"{asset} derivatives", repr(e)[:120])
        # ---------------- whale row vs the whale log (last 5 minutes)
        try:
            t = txt(c)
            m = re.search(r"Whale trades.*?\(currently \$([\d\.]+)([kM])\+\)\s*BUY \$([\d\.]+)([kM]) \((\d+)\) vs SELL \$([\d\.]+)([kM]) \((\d+)\)", t)
            if m:
                f = lambda v, u: float(v) * (1e6 if u == "M" else 1e3)
                shown_buy, shown_sell = f(m.group(3), m.group(4)), f(m.group(6), m.group(7))
                n_buy, n_sell = int(m.group(5)), int(m.group(8))
                now = dt.datetime.now(dt.timezone.utc)
                b = s = nb = ns = 0
                with open(os.path.join(ROOT, "bot_state", "whale_log.csv"), encoding="utf-8") as fh:
                    for r in csv.DictReader(fh):
                        if r["symbol"] != sym:
                            continue
                        ts = dt.datetime.strptime(r["ts_utc"], "%Y-%m-%dT%H:%M:%S.%f").replace(tzinfo=dt.timezone.utc)
                        if (now - ts).total_seconds() <= 300:
                            if r["side"] == "buy":
                                b += float(r["usd"]); nb += 1
                            else:
                                s += float(r["usd"]); ns += 1
                ok = abs(b - shown_buy) < 0.35 * max(shown_buy, b, 1e5) and abs(s - shown_sell) < 0.35 * max(shown_sell, s, 1e5)
                rec("PASS" if ok else "WARN", f"{asset} whale row", f"page BUY ${shown_buy/1e3:.0f}k({n_buy}) SELL ${shown_sell/1e3:.0f}k({n_sell}) | log (5 min) BUY ${b/1e3:.0f}k({nb}) SELL ${s/1e3:.0f}k({ns})")
            else:
                rec("PASS", f"{asset} whale row", "no whale-sized trades shown right now (nothing to compare)")
        except Exception as e:
            rec("WARN", f"{asset} whale row", repr(e)[:120])
        # ---------------- RSI: composite vs a Coinbase-only RSI
        try:
            import src.kalshi_web_dashboard as d
            m = re.search(r'data-rsi-name="%s" data-rsi="([\d\.]+)"' % asset, c)
            shown = float(m.group(1))
            from src.data import fetch_klines
            df = fetch_klines(symbol=sym, interval="1m", limit=65)
            closes = [float(x) for x in df["close"].tolist()][:-1][-61:]
            ref = d.compute_rsi(closes)
            rec("PASS" if abs(shown - ref) < 14 else "WARN", f"{asset} RSI", f"all-exchange {shown:.1f} | Coinbase-only {ref:.1f} (differ by construction, should be close)")
        except Exception as e:
            rec("WARN", f"{asset} RSI", repr(e)[:120])
        # ---------------- streak table adds up
        try:
            sp = re.search(r'<details class="streak-pull".*?</details>', c, re.S)
            bad = 0
            for tr in re.findall(r"<tr><td>([^<]*)</td>(.*?)</tr>", sp.group(0), re.S):
                cells = [txt(x) for x in re.findall(r"<td>(.*?)</td>", tr[1], re.S)]
                total = int(cells[0])
                w, l = [int(x) for x in re.findall(r"\d+", cells[1])] if re.findall(r"\d+", cells[1]) else (0, 0)
                nocall = int(cells[3]) if cells[3].isdigit() else 0
                off = int(cells[4]) if cells[4].isdigit() else 0
                if w + l + nocall + off != total:
                    bad += 1
                    rec("FAIL", f"{asset} streak row '{tr[0]}'", f"{w}+{l}+{nocall}+{off} != {total}")
            if not bad:
                rec("PASS", f"{asset} streak table", "every row: won + lost + no call + bot off = windows")
        except Exception as e:
            rec("WARN", f"{asset} streak table", repr(e)[:120])
    # ---------------- flip counts line vs history
    try:
        import src.kalshi_web_dashboard as d
        d._load_history()
        for asset in ("BTC", "XRP"):
            exp = d.flip_counts(d._history.get(asset, []))
            line = txt(cs[asset])
            m = re.search(r"this hour \(since [^)]*\) (\d+) of (\d+) \| since [^)]*?(\d+) of (\d+)", line)
            if m:
                shown = (int(m.group(1)), int(m.group(2)), int(m.group(3)), int(m.group(4)))
                want = (exp["1h"][0], exp["1h"][1], exp["2h"][0], exp["2h"][1])
                rec("PASS" if shown == want else "WARN", f"{asset} flip counts", f"shown {shown} | from history {want}")
    except Exception as e:
        rec("WARN", "flip counts", repr(e)[:120])
    # ---------------- safety
    ls = json.loads(urllib.request.urlopen(B + "/live_status", timeout=10).read())
    rec("PASS" if not any(ls["armed"].values()) and not any(ls["flip_armed"].values()) and not ls["open_position"] else "WARN", "trading safety",
        f"armed {ls['armed']} | flip_armed {ls['flip_armed']} | open_position {ls['open_position']}")
    fails = [r for r in RES if r[0] == "FAIL"]
    warns = [r for r in RES if r[0] == "WARN"]
    print(f"\nSUMMARY: {len([r for r in RES if r[0]=='PASS'])} pass, {len(warns)} warn, {len(fails)} fail")


if __name__ == "__main__":
    main()
