"""Tests a defensive exit that watches Kalshi's OWN order flow (volume +
direction, continuously, not just at entry) during the hold, combined with
price trend - not spot BTC. Motivated by a real loss: KXBTC15M-26AUG021215-15
flipped from ~85% no-favored to 94% yes-favored in about 10 seconds, driven by
a 7:1 taker-volume imbalance (41,710 yes-side contracts vs 5,875 no-side) that
our spot-based defensive exit had zero visibility into. Requires full trade
coverage of the entire hold period per market - much heavier than prior tests,
so this runs on a smaller sample first."""
import argparse
import datetime as dt
import statistics
import time

from src.kalshi_favorite_backtest import BASE, _get, fetch_settled_markets

EPS = 1e-9


def fetch_all_trades_in_window(ticker, start_ts, end_ts, max_pages=25, page_limit=1000):
    """Paginates backward from the market's most recent trade until coverage
    reaches start_ts, or max_pages is hit. Returns None if never reached."""
    cursor = None
    collected = []
    for _ in range(max_pages):
        params = {"ticker": ticker, "limit": page_limit}
        if cursor:
            params["cursor"] = cursor
        data = _get(f"{BASE}/markets/trades", params=params)
        trades = data.get("trades", [])
        cursor = data.get("cursor")
        if not trades:
            break
        for t in trades:
            ts = dt.datetime.fromisoformat(t["created_time"].replace("Z", "+00:00")).timestamp()
            if ts < start_ts - 5:
                continue
            collected.append({
                "ts": ts,
                "price": float(t["yes_price_dollars"]),
                "count": float(t.get("count_fp", 0) or 0),
                "taker_side": t.get("taker_side"),
            })
        oldest = min((t["ts"] for t in collected), default=end_ts)
        if oldest <= start_ts or not cursor:
            break
    if not collected:
        return None
    oldest = min(t["ts"] for t in collected)
    if oldest > start_ts + 5:
        return None
    collected.sort(key=lambda x: x["ts"])
    return collected


def rolling_flow_imbalance(trades, at_ts, window_seconds=15):
    net = 0.0
    for t in trades:
        if at_ts - window_seconds <= t["ts"] <= at_ts:
            if t["taker_side"] == "yes":
                net += t["count"]
            elif t["taker_side"] == "no":
                net -= t["count"]
    return net


def price_at_or_before(trades, ts):
    eligible = [t for t in trades if t["ts"] <= ts]
    return eligible[-1]["price"] if eligible else None


def simulate_market(m, entry_minutes=3.5, flow_window=15, flow_trigger=None, check_every=5):
    result = m.get("result")
    if result not in ("yes", "no"):
        return None
    ticker = m["ticker"]
    close_ts = dt.datetime.fromisoformat(m["close_time"].replace("Z", "+00:00")).timestamp()
    entry_ts = close_ts - entry_minutes * 60

    trades = fetch_all_trades_in_window(ticker, entry_ts, close_ts)
    if trades is None:
        return None

    entry_price = price_at_or_before(trades, entry_ts)
    if entry_price is None or entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    baseline_payoff = (1 - cost) if side == result else -cost

    if flow_trigger is None:
        return {"baseline_payoff": baseline_payoff, "flow_payoff": baseline_payoff, "flow_exited": False}

    # walk forward in check_every-second steps, watching rolling taker flow
    t = entry_ts + check_every
    flow_payoff = None
    flow_exited = False
    while t < close_ts:
        flow = rolling_flow_imbalance(trades, t, flow_window)
        # flow_against_side: positive = recent aggression running against our position
        flow_against_side = -flow if side == "yes" else flow
        if flow_against_side >= flow_trigger:
            exit_price = price_at_or_before(trades, t)
            if exit_price is not None:
                price_side_now = exit_price if side == "yes" else (1 - exit_price)
                flow_payoff = price_side_now - cost
                flow_exited = True
                break
        t += check_every

    if flow_payoff is None:
        flow_payoff = baseline_payoff

    return {"baseline_payoff": baseline_payoff, "flow_payoff": flow_payoff, "flow_exited": flow_exited}


def evaluate(records, use_flow, bet_size=100.0):
    payoffs = []
    exits = 0
    for r in records:
        p = r["flow_payoff"] if use_flow else r["baseline_payoff"]
        payoffs.append(p)
        if use_flow and r["flow_exited"]:
            exits += 1
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "flow_exits": exits, "non_negative": non_negative,
            "avg_payoff": statistics.mean(payoffs) * bet_size,
            "total_payoff": sum(payoffs) * bet_size}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-markets", type=int, default=200)
    parser.add_argument("--entry-minutes", type=float, default=3.5)
    parser.add_argument("--flow-window", type=float, default=15)
    args = parser.parse_args()

    print(f"Fetching last {args.n_markets} settled KXBTC15M markets...")
    markets = fetch_settled_markets(args.n_markets, series="KXBTC15M")
    print(f"Got {len(markets)} settled markets. Pulling full-hold trade data per market "
          f"(this fetches many pages per market - slow)...")

    raw = []
    skipped = 0
    for i, m in enumerate(markets):
        try:
            trades_data = fetch_all_trades_in_window(
                m["ticker"],
                dt.datetime.fromisoformat(m["close_time"].replace("Z", "+00:00")).timestamp() - args.entry_minutes * 60,
                dt.datetime.fromisoformat(m["close_time"].replace("Z", "+00:00")).timestamp(),
            )
        except Exception:
            trades_data = None
        if trades_data is None:
            skipped += 1
        else:
            entry_ts = dt.datetime.fromisoformat(m["close_time"].replace("Z", "+00:00")).timestamp() - args.entry_minutes * 60
            entry_price = price_at_or_before(trades_data, entry_ts)
            result = m.get("result")
            if entry_price is not None and entry_price != 0.5 and result in ("yes", "no"):
                side = "yes" if entry_price > 0.5 else "no"
                cost = entry_price if side == "yes" else (1 - entry_price)
                baseline_payoff = (1 - cost) if side == result else -cost
                raw.append({"trades": trades_data, "entry_ts": entry_ts, "close_ts": entry_ts + args.entry_minutes * 60,
                            "side": side, "cost": cost, "result": result, "baseline_payoff": baseline_payoff})
            else:
                skipped += 1
        if (i + 1) % 25 == 0:
            print(f"  ...{i + 1}/{len(markets)} processed, {len(raw)} usable so far")
        time.sleep(0.1)

    print(f"\nUsable records: {len(raw)} (skipped/no-data: {skipped})\n")
    if len(raw) < 20:
        print("Too few usable records to proceed.")
        return

    split = int(len(raw) * 0.8)
    train, test = raw[:split], raw[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    def apply_flow(records, flow_trigger, flow_window):
        out = []
        for r in records:
            t = r["entry_ts"] + 5
            flow_payoff = None
            exited = False
            while t < r["close_ts"]:
                flow = rolling_flow_imbalance(r["trades"], t, flow_window)
                flow_against_side = -flow if r["side"] == "yes" else flow
                if flow_against_side >= flow_trigger:
                    exit_price = price_at_or_before(r["trades"], t)
                    if exit_price is not None:
                        price_side_now = exit_price if r["side"] == "yes" else (1 - exit_price)
                        flow_payoff = price_side_now - r["cost"]
                        exited = True
                        break
                t += 5
            if flow_payoff is None:
                flow_payoff = r["baseline_payoff"]
            out.append({"payoff": flow_payoff, "exited": exited})
        return out

    def summarize(payoff_dicts, bet_size=100.0):
        payoffs = [d["payoff"] for d in payoff_dicts]
        exits = sum(1 for d in payoff_dicts if d["exited"])
        n = len(payoffs)
        non_negative = sum(1 for p in payoffs if p >= -EPS) / n
        return {"n": n, "exits": exits, "non_negative": non_negative,
                "avg_payoff": statistics.mean(payoffs) * bet_size, "total_payoff": sum(payoffs) * bet_size}

    print("--- baseline (buy and hold to settlement, no flow exit) ---")
    for label, data in (("TRAIN", train), ("HOLDOUT", test)):
        payoffs = [d["baseline_payoff"] for d in data]
        n = len(payoffs)
        non_negative = sum(1 for p in payoffs if p >= -EPS) / n
        print(f"{label}: n={n} non-neg={non_negative:.2%} avgPay/$100={statistics.mean(payoffs)*100:+.2f} "
              f"total=${sum(payoffs)*100:+.2f}")

    print(f"\n--- sweeping flow trigger on TRAIN (contracts of net aggression against position, "
          f"{args.flow_window}s rolling window) ---")
    best = None
    for flow_trigger in [500, 1000, 2000, 3000, 5000, 8000, 12000]:
        res_dicts = apply_flow(train, flow_trigger, args.flow_window)
        res = summarize(res_dicts)
        print(f"  flow_trigger={flow_trigger}: n={res['n']} (flow exits: {res['exits']}) "
              f"non-neg={res['non_negative']:.2%} avgPay/$100={res['avg_payoff']:+.2f} "
              f"total=${res['total_payoff']:+.2f}")
        if best is None or res["non_negative"] > best[0]["non_negative"] or \
           (res["non_negative"] == best[0]["non_negative"] and res["avg_payoff"] > best[0]["avg_payoff"]):
            best = (res, flow_trigger)

    if best:
        _, best_trigger = best
        print(f"\n--- flow defensive exit (trigger={best_trigger}) validated on HOLDOUT ---")
        res_dicts = apply_flow(test, best_trigger, args.flow_window)
        res = summarize(res_dicts)
        print(f"n={res['n']} (flow exits: {res['exits']}) non-neg={res['non_negative']:.2%} "
              f"avgPay/$100={res['avg_payoff']:+.2f} total=${res['total_payoff']:+.2f}")


if __name__ == "__main__":
    main()
