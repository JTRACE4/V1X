import argparse
import itertools
import pickle
import statistics

from src.kalshi_fetch_paths import CACHE_PATH, cache_path_for
from src.kalshi_exit_sim import prices_from_candles, simulate_exit

EPS = 1e-9


def load_records(series=None):
    path = cache_path_for(series) if series else CACHE_PATH
    with open(path, "rb") as f:
        return pickle.load(f)


def simulate_trade(candles, close_ts, result, entry_minutes_before_close,
                    lock_in_threshold, trail_amount, hard_stop_amount):
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None

    entry_ts = close_ts - entry_minutes_before_close * 60
    entry_idx = None
    for i, (ts, _) in enumerate(prices):
        if ts <= entry_ts:
            entry_idx = i
        else:
            break
    if entry_idx is None:
        entry_idx = 0
    if entry_idx >= len(prices) - 1:
        return None  # no room left to trade

    entry_price = prices[entry_idx][1]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    return simulate_exit(prices, entry_idx, cost, side, result,
                          lock_in_threshold, trail_amount, hard_stop_amount)


def evaluate(records, entry_minutes, lock_in, trail, hard_stop):
    payoffs = []
    reasons = {"trailing_stop": 0, "breakeven_stop": 0, "settlement": 0}
    for r in records:
        out = simulate_trade(r["candles"], r["close_ts"], r["result"],
                              entry_minutes, lock_in, trail, hard_stop)
        if out is None:
            continue
        payoffs.append(out["payoff"])
        reasons[out["reason"]] += 1

    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS)
    losers = [p for p in payoffs if p < -EPS]
    winners = [p for p in payoffs if p > EPS]
    return {
        "entry_minutes": entry_minutes, "lock_in": lock_in, "trail": trail, "hard_stop": hard_stop,
        "n": n,
        "pct_non_negative": non_negative / n,
        "avg_payoff": statistics.mean(payoffs),
        "avg_winner": statistics.mean(winners) if winners else 0.0,
        "avg_loser": statistics.mean(losers) if losers else 0.0,
        "n_losers": len(losers),
        "reasons": reasons,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bet-size", type=float, default=100.0)
    args = parser.parse_args()

    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.\n")

    entry_options = [15, 10, 7, 5, 3]
    lock_in_options = [0.01, 0.02, 0.03, 0.05]
    trail_options = [0.01, 0.02, 0.03]
    hard_stop_options = [0.0, 0.01, 0.02]

    results = []
    for entry_minutes, lock_in, trail, hard_stop in itertools.product(
        entry_options, lock_in_options, trail_options, hard_stop_options
    ):
        res = evaluate(records, entry_minutes, lock_in, trail, hard_stop)
        if res:
            results.append(res)

    print(f"Evaluated {len(results)} parameter combinations.\n")

    results.sort(key=lambda r: (-r["pct_non_negative"], -r["avg_payoff"]))

    print("--- Top 15 by % non-negative close, tie-broken by avg payoff ---")
    print(f"{'entry_min':>9} {'lock_in':>8} {'trail':>7} {'hstop':>7} {'n':>6} "
          f"{'%non-neg':>9} {'avgPay/$100':>12} {'avgLoss/$100':>13} {'n_loss':>7}")
    for r in results[:15]:
        print(f"{r['entry_minutes']:>9} {r['lock_in']:>8.2f} {r['trail']:>7.2f} {r['hard_stop']:>7.2f} "
              f"{r['n']:>6} {r['pct_non_negative']:>8.2%} "
              f"{r['avg_payoff'] * args.bet_size:>12.2f} {r['avg_loser'] * args.bet_size:>13.2f} {r['n_losers']:>7}")

    # among strategies with very high non-negative rate, find the one with best avg payoff
    high_safety = [r for r in results if r["pct_non_negative"] >= 0.95]
    high_safety.sort(key=lambda r: -r["avg_payoff"])
    print("\n--- Among >=95% non-negative strategies, best avg payoff ---")
    for r in high_safety[:5]:
        print(f"entry={r['entry_minutes']}min lock_in={r['lock_in']} trail={r['trail']} hard_stop={r['hard_stop']}: "
              f"n={r['n']} non-neg={r['pct_non_negative']:.2%} avgPay/$100={r['avg_payoff'] * args.bet_size:+.2f} "
              f"reasons={r['reasons']}")

    # baseline for comparison: naive hold-to-settlement (equivalent to hard_stop huge, lock_in huge)
    print("\n--- Baseline: hold to settlement, no stop, by entry point ---")
    for entry_minutes in entry_options:
        res = evaluate(records, entry_minutes, lock_in=999, trail=999, hard_stop=999)
        if res:
            print(f"entry={entry_minutes}min: n={res['n']} non-neg={res['pct_non_negative']:.2%} "
                  f"avgPay/$100={res['avg_payoff'] * args.bet_size:+.2f}")


if __name__ == "__main__":
    main()
