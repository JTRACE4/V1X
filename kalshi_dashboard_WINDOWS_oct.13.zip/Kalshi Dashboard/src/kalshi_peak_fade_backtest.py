import argparse
import statistics

from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_path_backtest import load_records

EPS = 1e-9


def simulate_peak_fade(candles, result, sell_threshold, rebuy_threshold):
    """Buy the favorite at market open. Sell (take profit) the first time confidence
    crosses sell_threshold. If confidence later pulls back to rebuy_threshold, buy back
    in and hold to settlement. If it never pulls back, stay out (cash) for the rest of
    the window - this is the direct backtest of "sell at the peak, rebuy on the dip"."""
    prices = prices_from_candles(candles)
    if len(prices) < 3:
        return None

    open_price = prices[0][1]
    if open_price == 0.5:
        return None
    side = "yes" if open_price > 0.5 else "no"
    entry_cost = open_price if side == "yes" else (1 - open_price)

    def side_price(p):
        return p if side == "yes" else (1 - p)

    sold_at = None
    rebought_cost = None
    for ts, p in prices[1:]:
        sp = side_price(p)
        if sold_at is None:
            if sp >= sell_threshold:
                sold_at = sp
        else:
            if rebought_cost is None and sp <= rebuy_threshold:
                rebought_cost = sp

    if sold_at is None:
        # never hit the sell threshold at all - just held the original entry to settlement
        settlement_payoff = (1 - entry_cost) if side == result else -entry_cost
        return {"payoff": settlement_payoff, "reason": "never_peaked"}

    leg1_payoff = sold_at - entry_cost  # realized selling the initial position at the peak

    if rebought_cost is None:
        # sold at the peak, never got a comfy rebuy - stayed in cash for the rest
        return {"payoff": leg1_payoff, "reason": "sold_no_rebuy"}

    leg2_payoff = (1 - rebought_cost) if side == result else -rebought_cost
    return {"payoff": leg1_payoff + leg2_payoff, "reason": "sold_and_rebought"}


def simulate_baseline_hold(candles, result):
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None
    open_price = prices[0][1]
    if open_price == 0.5:
        return None
    side = "yes" if open_price > 0.5 else "no"
    cost = open_price if side == "yes" else (1 - open_price)
    payoff = (1 - cost) if side == result else -cost
    return {"payoff": payoff}


def evaluate(records, sell_threshold, rebuy_threshold):
    fade_payoffs, hold_payoffs = [], []
    reasons = {"never_peaked": 0, "sold_no_rebuy": 0, "sold_and_rebought": 0}
    for r in records:
        fade = simulate_peak_fade(r["candles"], r["result"], sell_threshold, rebuy_threshold)
        hold = simulate_baseline_hold(r["candles"], r["result"])
        if fade is None or hold is None:
            continue
        fade_payoffs.append(fade["payoff"])
        hold_payoffs.append(hold["payoff"])
        reasons[fade["reason"]] += 1

    n = len(fade_payoffs)
    if n == 0:
        return None
    return {
        "n": n, "reasons": reasons,
        "fade_non_neg": sum(1 for p in fade_payoffs if p >= -EPS) / n,
        "fade_avg": statistics.mean(fade_payoffs),
        "hold_non_neg": sum(1 for p in hold_payoffs if p >= -EPS) / n,
        "hold_avg": statistics.mean(hold_payoffs),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bet-size", type=float, default=100.0)
    args = parser.parse_args()

    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.\n")

    print(f"{'sell@':>7} {'rebuy@':>7} {'n':>6} {'fade non-neg':>13} {'fade avgPay/100':>16} "
          f"{'hold non-neg':>13} {'hold avgPay/100':>16}  reasons")
    for sell_threshold in [0.85, 0.90, 0.95]:
        for rebuy_threshold in [0.60, 0.70, 0.75, 0.80]:
            res = evaluate(records, sell_threshold, rebuy_threshold)
            if res:
                print(f"{sell_threshold:>7.2f} {rebuy_threshold:>7.2f} {res['n']:>6} "
                      f"{res['fade_non_neg']:>12.2%} {res['fade_avg'] * args.bet_size:>16.2f} "
                      f"{res['hold_non_neg']:>12.2%} {res['hold_avg'] * args.bet_size:>16.2f}  {res['reasons']}")


if __name__ == "__main__":
    main()
