"""Real backtest for gold, now that we know KXGOLD15M actually has ~28 days
of settled-market history (2247 usable records, see kalshi_gold_fetch.py) -
the earlier "only 12 hours" read was wrong, just an artifact of a too-small
API page size. Same framework as kalshi_real_xrp_backtest.py: real Kalshi
price path + the same live-style entry filters, using real gold futures
spot data (Yahoo GC=F) for the regime/momentum/sweep filters instead of a
crypto proxy."""
import argparse
import pickle
import time
import urllib.error
import urllib.request
import json

from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_live_bot import had_recent_sweep
from src.kalshi_web_dashboard import (
    GOLD_REAL_ASSET, BEAR_MIN_CONFIDENCE, REGIME_VETO_OVERRIDE_CONFIDENCE, momentum_confirms,
)

REGIME_LOOKBACK_MINUTES = 240
REGIME_THRESHOLD = 0.002


def load_records():
    with open("data_cache/kalshi_paths_KXGOLD15M.pkl", "rb") as f:
        return pickle.load(f)


def fetch_gold_range(days):
    """Yahoo's free endpoint caps 1-min bars at ~8 days per request - chain
    a few day-range requests won't extend that (Yahoo enforces it server-
    side regardless of the range param), so this is the real ceiling for
    free 1-min gold data. 28 days of settled markets exist, but we can only
    get ~8 days of matching real spot data - the rest falls outside overlap
    and those markets get skipped (no look-ahead risk, just less coverage)."""
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/GC=F?interval=1m&range={days}d"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=20) as r:
        data = json.loads(r.read())
    result = data["chart"]["result"][0]
    ts = result["timestamp"]
    closes = result["indicators"]["quote"][0]["close"]
    return {t: c for t, c in zip(ts, closes) if c is not None}


def regime_at(ts, spot_map):
    now_p = spot_map.get(ts)
    past_p = spot_map.get(ts - REGIME_LOOKBACK_MINUTES * 60)
    if now_p is None or past_p is None or past_p == 0:
        return None, None
    ret = now_p / past_p - 1
    if ret >= REGIME_THRESHOLD:
        return ret, "BULL"
    elif ret <= -REGIME_THRESHOLD:
        return ret, "BEAR"
    return ret, "NEUTRAL"


def closes_up_to(ts, spot_map, minutes):
    out = []
    for m in range(minutes, -1, -1):
        p = spot_map.get(ts - m * 60)
        if p is not None:
            out.append(p)
    return out


def simulate_market(candles, result, spot_map, use_filters=True):
    prices = prices_from_candles(candles)
    if len(prices) < 3:
        return None

    for ts, kalshi_price in prices:
        if kalshi_price <= 0.0 or kalshi_price >= 1.0:
            continue
        minute_ts = int(ts) // 60 * 60
        leaning = "YES" if kalshi_price > 0.5 else "NO"
        confidence = max(kalshi_price, 1 - kalshi_price)

        if not use_filters:
            my_call = leaning
        else:
            if minute_ts not in spot_map and (minute_ts - 60) not in spot_map:
                continue  # outside real spot data coverage - skip, not guess
            regime_ret, regime = regime_at(minute_ts, spot_map)
            required_floor = GOLD_REAL_ASSET["entry_confidence_floor"]
            if regime == "BEAR":
                required_floor = max(required_floor, BEAR_MIN_CONFIDENCE)
            below_floor = confidence < required_floor

            recent_closes = closes_up_to(minute_ts, spot_map, 5)
            direction_confirms = momentum_confirms(recent_closes, leaning,
                                                     GOLD_REAL_ASSET["strict_direction_margin"])

            against_regime = ((regime == "BEAR" and leaning == "YES") or
                               (regime == "BULL" and leaning == "NO")) and (
                confidence < REGIME_VETO_OVERRIDE_CONFIDENCE)

            sweep_closes = closes_up_to(minute_ts, spot_map, GOLD_REAL_ASSET["sweep_lookback_minutes"])
            swept = had_recent_sweep(sweep_closes, GOLD_REAL_ASSET["sweep_lookback_minutes"],
                                      GOLD_REAL_ASSET["sweep_recent_minutes"], GOLD_REAL_ASSET["sweep_margin"])

            my_call = leaning if (not below_floor and direction_confirms and not swept
                                   and not against_regime) else None

        if my_call is not None:
            correct = my_call.lower() == (result or "").lower()
            return {"correct": correct}

    return None


def evaluate(records, spot_map, use_filters):
    results = []
    skipped_no_data = 0
    for r in records:
        out = simulate_market(r["candles"], r["result"], spot_map, use_filters)
        if out is not None:
            results.append(out)
    return results


def summarize(results, n_total, label):
    n = len(results)
    if n == 0:
        print(f"    {label}: no calls formed")
        return
    acc = sum(1 for r in results if r["correct"]) / n
    print(f"    {label}: n={n:5d}/{n_total} (coverage={n/n_total:.1%}) accuracy={acc:.2%}")


def main():
    print("Loading real KXGOLD15M settled markets...")
    records = load_records()
    print(f"Loaded {len(records)} real settled gold markets.")

    print("Fetching real gold futures spot data (Yahoo GC=F, ~8 day cap)...")
    spot_map = fetch_gold_range(8)
    print(f"Got {len(spot_map)} spot minute bars.")

    # only keep markets whose close_ts falls within real spot data coverage
    spot_min_ts, spot_max_ts = min(spot_map), max(spot_map)
    covered = [r for r in records if spot_min_ts <= r["close_ts"] <= spot_max_ts]
    print(f"{len(covered)}/{len(records)} markets fall within the real spot-data window.\n")

    records_sorted = sorted(covered, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, holdout = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(holdout)}\n")

    print("=== UNFILTERED (take leaning at first available tick) ===")
    for label, data in (("TRAIN", train), ("HOLDOUT", holdout)):
        results = evaluate(data, spot_map, use_filters=False)
        summarize(results, len(data), label)
    print()

    print("=== WITH live-style filters (floor/regime/momentum/sweep, same as BTC/XRP) ===")
    for label, data in (("TRAIN", train), ("HOLDOUT", holdout)):
        results = evaluate(data, spot_map, use_filters=True)
        summarize(results, len(data), label)
    print()

    print(f"(Note: only {len(covered)} of {len(records)} total settled markets fall inside the "
          f"real spot-data window - Yahoo's free API only gives ~8 days of 1-min gold history, "
          f"so this validates on fewer markets than the full 28-day settled-market history.)")


if __name__ == "__main__":
    main()
