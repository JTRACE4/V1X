"""Tests an absolute price-floor stop: sell if the position's price ever falls to
X (e.g. 55%) regardless of entry cost, capping catastrophic reversals - distinct
from a relative stop (loss vs entry cost) and from the gain-protection tests."""
import argparse
import statistics

from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records, build_spot_minute_map

EPS = 1e-9


def simulate(candles, close_ts, result, spot_map, entry_minutes,
             entry_filter_threshold, defensive_exit_threshold, floor):
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None

    entry_ts = close_ts - entry_minutes * 60
    entry_idx = None
    for i, (ts, _) in enumerate(prices):
        if ts <= entry_ts:
            entry_idx = i
        else:
            break
    if entry_idx is None:
        entry_idx = 0
    if entry_idx >= len(prices) - 1:
        return None

    entry_price = prices[entry_idx][1]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    if entry_filter_threshold is not None:
        entry_ts_actual = prices[entry_idx][0]
        spot_now = spot_map.get(entry_ts_actual)
        spot_prev = spot_map.get(entry_ts_actual - 60)
        if spot_now is not None and spot_prev is not None and spot_prev != 0:
            spot_ret = spot_now / spot_prev - 1
            adverse_at_entry = (side == "yes" and spot_ret <= -entry_filter_threshold) or \
                                (side == "no" and spot_ret >= entry_filter_threshold)
            if adverse_at_entry:
                return None

    for ts, p in prices[entry_idx + 1:]:
        price_side_now = p if side == "yes" else (1 - p)

        if floor is not None and price_side_now <= floor:
            return {"payoff": price_side_now - cost, "reason": "floor_stop"}

        spot_now = spot_map.get(ts)
        spot_prev = spot_map.get(ts - 60)
        if spot_now is not None and spot_prev is not None and spot_prev != 0:
            spot_ret = spot_now / spot_prev - 1
            adverse = (side == "yes" and spot_ret <= -defensive_exit_threshold) or \
                      (side == "no" and spot_ret >= defensive_exit_threshold)
            if adverse:
                return {"payoff": price_side_now - cost, "reason": "defensive_exit"}

    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff, "reason": "settlement"}


def evaluate(records, spot_map, entry_minutes, entry_filter, defensive_exit, floor, bet_size=100.0):
    payoffs = []
    reasons = {"floor_stop": 0, "defensive_exit": 0, "settlement": 0}
    for r in records:
        out = simulate(r["candles"], r["close_ts"], r["result"], spot_map, entry_minutes,
                        entry_filter, defensive_exit, floor)
        if out is None:
            continue
        payoffs.append(out["payoff"])
        reasons[out["reason"]] += 1
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "non_negative": non_negative,
            "avg_payoff": statistics.mean(payoffs) * bet_size, "reasons": reasons}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--entry-minutes", type=float, default=3.5)
    parser.add_argument("--entry-filter", type=float, default=0.00005)
    parser.add_argument("--defensive-exit", type=float, default=0.00035)
    args = parser.parse_args()

    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.")
    spot_map = build_spot_minute_map(records)

    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    print("--- current combo (entry filter + defensive exit, no floor stop) ---")
    current = evaluate(records, spot_map, args.entry_minutes, args.entry_filter, args.defensive_exit, None)
    print(f"n={current['n']} non-neg={current['non_negative']:.2%} avgPay/$100={current['avg_payoff']:+.2f}\n")

    print("--- + floor stop: selecting threshold on TRAIN ---")
    best = None
    for floor in [0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75]:
        res = evaluate(train, spot_map, args.entry_minutes, args.entry_filter, args.defensive_exit, floor)
        if res:
            print(f"  floor={floor:.2f}: n={res['n']} non-neg={res['non_negative']:.2%} "
                  f"avgPay/$100={res['avg_payoff']:+.2f} reasons={res['reasons']}")
            if best is None or res["non_negative"] > best[0]["non_negative"]:
                best = (res, floor)

    _, best_floor = best
    print(f"\n--- best floor ({best_floor}) validated on HOLDOUT, plus your suggested 0.55 for direct comparison ---")
    current_test = evaluate(test, spot_map, args.entry_minutes, args.entry_filter, args.defensive_exit, None)
    best_test = evaluate(test, spot_map, args.entry_minutes, args.entry_filter, args.defensive_exit, best_floor)
    fifty5_test = evaluate(test, spot_map, args.entry_minutes, args.entry_filter, args.defensive_exit, 0.55)
    print(f"current combo holdout:         n={current_test['n']} non-neg={current_test['non_negative']:.2%} "
          f"avgPay/$100={current_test['avg_payoff']:+.2f}")
    print(f"+ floor={best_floor} holdout:   n={best_test['n']} non-neg={best_test['non_negative']:.2%} "
          f"avgPay/$100={best_test['avg_payoff']:+.2f} reasons={best_test['reasons']}")
    print(f"+ floor=0.55 holdout:          n={fifty5_test['n']} non-neg={fifty5_test['non_negative']:.2%} "
          f"avgPay/$100={fifty5_test['avg_payoff']:+.2f} reasons={fifty5_test['reasons']}")


if __name__ == "__main__":
    main()
