import datetime as dt

import numpy as np

from src.data import fetch_history
from src.kalshi_favorite_backtest import fetch_settled_markets
from src.kalshi_favorite_sweep import fetch_candles

N_MARKETS = 1000
LAGS = [-2, -1, 0, 1, 2, 3]  # positive lag = spot move happens `lag` minutes BEFORE the kalshi move


def build_kalshi_minute_series(markets):
    """Return dict: minute-timestamp (int, floor to the minute) -> kalshi yes price."""
    series = {}
    for i, m in enumerate(markets):
        result = m.get("result")
        if result not in ("yes", "no"):
            continue
        candles, close_ts = fetch_candles(m["ticker"], m["open_time"], m["close_time"])
        for c in candles:
            price = c.get("price", {}).get("close_dollars")
            if price is None:
                continue
            minute_ts = c["end_period_ts"] - (c["end_period_ts"] % 60)
            series[minute_ts] = float(price)
        if (i + 1) % 100 == 0:
            print(f"  ...kalshi candles {i + 1}/{len(markets)}")
    return series


def main():
    print(f"Fetching last {N_MARKETS} settled KXBTC15M markets...")
    markets = fetch_settled_markets(N_MARKETS)
    print(f"Got {len(markets)} markets.")

    open_times = [dt.datetime.fromisoformat(m["open_time"].replace("Z", "+00:00")) for m in markets]
    close_times = [dt.datetime.fromisoformat(m["close_time"].replace("Z", "+00:00")) for m in markets]
    span_start = min(open_times)
    span_end = max(close_times)
    days = (dt.datetime.now(dt.timezone.utc) - span_start).days + 2
    print(f"Market span: {span_start} to {span_end} ({days} days of spot data needed)")

    print("Fetching Coinbase BTC-USD 1-minute spot data for that span...")
    spot_df = fetch_history(symbol="BTC-USD", interval="1m", days=days)
    spot_df["minute_ts"] = spot_df["open_time"] // 1000
    spot_price = dict(zip(spot_df["minute_ts"], spot_df["close"]))
    print(f"Got {len(spot_price)} spot minute bars.")

    print("Fetching Kalshi per-minute price series for each market...")
    kalshi_price = build_kalshi_minute_series(markets)
    print(f"Got {len(kalshi_price)} kalshi minute bars.")

    common_minutes = sorted(set(kalshi_price) & set(spot_price) & set(m - 60 for m in spot_price))

    spot_ret = {}
    kalshi_chg = {}
    for t in common_minutes:
        if t in spot_price and (t - 60) in spot_price:
            spot_ret[t] = spot_price[t] / spot_price[t - 60] - 1
        if t in kalshi_price and (t - 60) in kalshi_price:
            kalshi_chg[t] = kalshi_price[t] - kalshi_price[t - 60]

    print(f"\n{'lag (min, +=spot leads)':>26} {'n pairs':>10} {'correlation':>12}")
    for lag in LAGS:
        xs, ys = [], []
        for t, chg in kalshi_chg.items():
            spot_t = t - lag * 60
            r = spot_ret.get(spot_t)
            if r is not None:
                xs.append(r)
                ys.append(chg)
        if len(xs) < 30:
            print(f"{lag:>26} {len(xs):>10}          n/a")
            continue
        corr = np.corrcoef(xs, ys)[0, 1]
        print(f"{lag:>26} {len(xs):>10} {corr:>12.4f}")

    # detailed dose-response at lag=1 (spot leads kalshi by 1 minute)
    xs, ys = [], []
    for t, chg in kalshi_chg.items():
        r = spot_ret.get(t - 60)
        if r is not None:
            xs.append(r)
            ys.append(chg)
    xs = np.array(xs)
    ys = np.array(ys)

    beta, intercept = np.polyfit(xs, ys, 1)
    ss_res = np.sum((ys - (beta * xs + intercept)) ** 2)
    ss_tot = np.sum((ys - ys.mean()) ** 2)
    r2 = 1 - ss_res / ss_tot
    print(f"\nRegression at lag=1: kalshi_change = {beta:.3f} * spot_return + {intercept:.5f}  (R^2={r2:.4f})")
    print(f"-> a 1% spot move in one minute predicts roughly a {beta * 0.01:+.4f} move in Kalshi's yes-price the next minute")

    print(f"\n{'spot move decile':>18} {'avg spot ret':>14} {'avg next kalshi chg':>20} {'n':>8}")
    order = np.argsort(xs)
    xs_sorted, ys_sorted = xs[order], ys[order]
    n = len(xs_sorted)
    for d in range(10):
        lo = n * d // 10
        hi = n * (d + 1) // 10
        print(f"{d + 1:>18} {xs_sorted[lo:hi].mean():>14.5f} {ys_sorted[lo:hi].mean():>20.5f} {hi - lo:>8}")


if __name__ == "__main__":
    main()
