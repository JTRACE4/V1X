"""Tests whether filtering the defensive-exit trigger by wick pullback-depth (only
exit on a shallow-pullback adverse wick, i.e. a "confirmed" move) beats the existing
close-to-close defensive exit, using the same walk-forward validation as everything else."""
import argparse
import datetime as dt
import statistics

from src.data import fetch_history
from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records

EPS = 1e-9


def build_spot_maps(records, symbol="BTC-USD"):
    open_times = [dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")) for r in records]
    span_start = min(open_times)
    days = (dt.datetime.now(dt.timezone.utc) - span_start).days + 2
    spot_df = fetch_history(symbol=symbol, interval="1m", days=days)
    spot_df["minute_ts"] = spot_df["open_time"] // 1000
    close_map = dict(zip(spot_df["minute_ts"], spot_df["close"]))
    high_map = dict(zip(spot_df["minute_ts"], spot_df["high"]))
    low_map = dict(zip(spot_df["minute_ts"], spot_df["low"]))
    return close_map, high_map, low_map


def wick_signal(ts, close_map, high_map, low_map):
    c_prev, c_now = close_map.get(ts - 60), close_map.get(ts)
    h_now, l_now = high_map.get(ts), low_map.get(ts)
    if None in (c_prev, c_now, h_now, l_now) or c_prev == 0:
        return None, None
    up, down = h_now / c_prev - 1, l_now / c_prev - 1
    wick_ret = up if abs(up) >= abs(down) else down
    if wick_ret > 0:
        excursion, giveback = h_now - c_prev, h_now - c_now
    else:
        excursion, giveback = c_prev - l_now, c_now - l_now
    pullback_ratio = giveback / excursion if excursion > 0 else None
    return wick_ret, pullback_ratio


def simulate(candles, close_ts, result, close_map, high_map, low_map,
             entry_minutes, exit_mode, close_threshold, wick_threshold, pullback_cutoff):
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None

    entry_ts = close_ts - entry_minutes * 60
    entry_idx = None
    for i, (ts, _) in enumerate(prices):
        if ts <= entry_ts:
            entry_idx = i
        else:
            break
    if entry_idx is None:
        entry_idx = 0
    if entry_idx >= len(prices) - 1:
        return None

    entry_price = prices[entry_idx][1]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    for ts, p in prices[entry_idx + 1:]:
        triggered = False

        if exit_mode in ("close", "either"):
            c_now, c_prev = close_map.get(ts), close_map.get(ts - 60)
            if c_now is not None and c_prev is not None and c_prev != 0:
                close_ret = c_now / c_prev - 1
                if (side == "yes" and close_ret <= -close_threshold) or \
                   (side == "no" and close_ret >= close_threshold):
                    triggered = True

        if not triggered and exit_mode in ("wick_quality", "either"):
            wr, ratio = wick_signal(ts, close_map, high_map, low_map)
            if wr is not None and ratio is not None and abs(wr) >= wick_threshold and ratio <= pullback_cutoff:
                if (side == "yes" and wr < 0) or (side == "no" and wr > 0):
                    triggered = True

        if triggered:
            price_side_now = p if side == "yes" else (1 - p)
            return {"payoff": price_side_now - cost, "reason": exit_mode}

    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff, "reason": "settlement"}


def evaluate(records, close_map, high_map, low_map, entry_minutes, exit_mode,
             close_threshold, wick_threshold, pullback_cutoff):
    payoffs = []
    for r in records:
        out = simulate(r["candles"], r["close_ts"], r["result"], close_map, high_map, low_map,
                        entry_minutes, exit_mode, close_threshold, wick_threshold, pullback_cutoff)
        if out is None:
            continue
        payoffs.append(out["payoff"])
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "non_negative": non_negative, "avg_payoff": statistics.mean(payoffs)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--entry-minutes", type=float, default=3)
    parser.add_argument("--bet-size", type=float, default=100.0)
    args = parser.parse_args()

    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.")
    close_map, high_map, low_map = build_spot_maps(records)
    print("Got spot maps with high/low.\n")

    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    CLOSE_THRESHOLD = 0.00035  # already validated

    print("=== selecting best wick_quality params on TRAIN ===")
    best = None
    for wick_threshold in [0.0003, 0.0004, 0.0005]:
        for pullback_cutoff in [0.25, 0.5, 0.75]:
            res = evaluate(train, close_map, high_map, low_map, args.entry_minutes, "wick_quality",
                            CLOSE_THRESHOLD, wick_threshold, pullback_cutoff)
            if res:
                print(f"  wick_thr={wick_threshold:.4f} pullback<={pullback_cutoff:.2f}: "
                      f"n={res['n']} non-neg={res['non_negative']:.2%} "
                      f"avgPay/100={res['avg_payoff'] * args.bet_size:+.2f}")
                if best is None or res["non_negative"] > best[0]["non_negative"]:
                    best = (res, wick_threshold, pullback_cutoff)

    print("\n=== holdout comparison ===")
    baseline_test = evaluate(test, close_map, high_map, low_map, args.entry_minutes, "close",
                              CLOSE_THRESHOLD, 999, 0)
    print(f"existing close-based defensive exit: n={baseline_test['n']} "
          f"non-neg={baseline_test['non_negative']:.2%} avgPay/100={baseline_test['avg_payoff'] * args.bet_size:+.2f}")

    if best:
        _, wt, pc = best
        wick_only_test = evaluate(test, close_map, high_map, low_map, args.entry_minutes, "wick_quality",
                                   CLOSE_THRESHOLD, wt, pc)
        either_test = evaluate(test, close_map, high_map, low_map, args.entry_minutes, "either",
                                CLOSE_THRESHOLD, wt, pc)
        print(f"wick_quality only (thr={wt}, pullback<={pc}): n={wick_only_test['n']} "
              f"non-neg={wick_only_test['non_negative']:.2%} avgPay/100={wick_only_test['avg_payoff'] * args.bet_size:+.2f}")
        print(f"close OR wick_quality (whichever fires first): n={either_test['n']} "
              f"non-neg={either_test['non_negative']:.2%} avgPay/100={either_test['avg_payoff'] * args.bet_size:+.2f}")


if __name__ == "__main__":
    main()
