"""Does a call that locks in FAST (within the first minute of a window) mean
anything different from one that takes longer to form? Uses the exact same
live-style filter stack each asset actually runs (including BTC's
choppiness veto), replayed against real settled markets, and buckets
results by how many seconds into the window the first real call formed."""
import argparse
import datetime as dt

from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records, build_spot_minute_map
from src.kalshi_live_bot import had_recent_sweep
from src.kalshi_web_dashboard import (
    BEAR_MIN_CONFIDENCE, REGIME_VETO_OVERRIDE_CONFIDENCE, momentum_confirms,
    CHOPPINESS_VETO_THRESHOLD, CHOPPINESS_LOOKBACK_MINUTES, get_choppiness,
)

REGIME_LOOKBACK_MINUTES = 240
REGIME_THRESHOLD = 0.002
FIRST_MINUTE_SECONDS = 60

BTC_ASSET = {"entry_confidence_floor": 0.58, "strict_direction_margin": 0.0002,
             "sweep_lookback_minutes": 10, "sweep_recent_minutes": 2, "sweep_margin": 0.0003}
XRP_VOL_SCALE = 1.28
XRP_ASSET = {"entry_confidence_floor": 0.58, "strict_direction_margin": 0.0002 * XRP_VOL_SCALE,
             "sweep_lookback_minutes": 10, "sweep_recent_minutes": 2, "sweep_margin": 0.0003 * XRP_VOL_SCALE}


def regime_at(ts, spot_map):
    now_p = spot_map.get(ts)
    past_p = spot_map.get(ts - REGIME_LOOKBACK_MINUTES * 60)
    if now_p is None or past_p is None or past_p == 0:
        return None
    ret = now_p / past_p - 1
    if ret >= REGIME_THRESHOLD:
        return "BULL"
    elif ret <= -REGIME_THRESHOLD:
        return "BEAR"
    return "NEUTRAL"


def closes_up_to(ts, spot_map, minutes):
    return [spot_map[t] for t in (ts - m * 60 for m in range(minutes, -1, -1)) if t in spot_map]


def simulate_market(candles, open_time, result, spot_map, asset_cfg, asset_name, use_choppiness):
    prices = prices_from_candles(candles)
    if len(prices) < 3:
        return None
    open_ts = int(dt.datetime.fromisoformat(open_time.replace("Z", "+00:00")).timestamp())

    for ts, kalshi_price in prices:
        if kalshi_price <= 0.0 or kalshi_price >= 1.0:
            continue
        minute_ts = int(ts) // 60 * 60
        if minute_ts not in spot_map and (minute_ts - 60) not in spot_map:
            continue
        leaning = "YES" if kalshi_price > 0.5 else "NO"
        confidence = max(kalshi_price, 1 - kalshi_price)

        regime = regime_at(minute_ts, spot_map)
        floor = asset_cfg["entry_confidence_floor"]
        if regime == "BEAR":
            floor = max(floor, BEAR_MIN_CONFIDENCE)
        below_floor = confidence < floor

        direction_confirms = momentum_confirms(closes_up_to(minute_ts, spot_map, 5), leaning,
                                                 asset_cfg["strict_direction_margin"])
        against_regime = ((regime == "BEAR" and leaning == "YES") or
                           (regime == "BULL" and leaning == "NO")) and confidence < REGIME_VETO_OVERRIDE_CONFIDENCE
        swept = had_recent_sweep(closes_up_to(minute_ts, spot_map, asset_cfg["sweep_lookback_minutes"]),
                                  asset_cfg["sweep_lookback_minutes"], asset_cfg["sweep_recent_minutes"],
                                  asset_cfg["sweep_margin"])
        chopped = False
        if use_choppiness:
            chop_thresh = CHOPPINESS_VETO_THRESHOLD.get(asset_name)
            if chop_thresh is not None:
                cc = closes_up_to(minute_ts, spot_map, CHOPPINESS_LOOKBACK_MINUTES)
                chop = get_choppiness(cc, CHOPPINESS_LOOKBACK_MINUTES)
                chopped = chop is not None and chop > chop_thresh

        if not below_floor and direction_confirms and not swept and not against_regime and not chopped:
            correct = leaning.lower() == (result or "").lower()
            seconds_into_window = ts - open_ts
            return {"correct": correct, "seconds_in": seconds_into_window}
    return None


def run(label, series, symbol, asset_cfg, use_choppiness):
    print(f"=== {label} ===")
    records = load_records(series=series) if series else load_records()
    records = [r for r in records if r.get("result") in ("yes", "no")]
    print(f"Loaded {len(records)} real settled markets.")
    spot_map = build_spot_minute_map(records, symbol=symbol)

    results = []
    for r in records:
        out = simulate_market(r["candles"], r["open_time"], r["result"], spot_map,
                               asset_cfg, label, use_choppiness)
        if out is not None:
            results.append(out)

    n = len(results)
    first_min = [x for x in results if x["seconds_in"] <= FIRST_MINUTE_SECONDS]
    later = [x for x in results if x["seconds_in"] > FIRST_MINUTE_SECONDS]

    def acc(lst):
        return (sum(1 for x in lst if x["correct"]) / len(lst)) if lst else None

    print(f"Total calls formed: {n}")
    a1 = acc(first_min)
    print(f"  Locked within first {FIRST_MINUTE_SECONDS}s:  n={len(first_min):5d}  "
          f"accuracy={a1:.2%}" if a1 is not None else f"  Locked within first {FIRST_MINUTE_SECONDS}s:  n=0")
    a2 = acc(later)
    print(f"  Locked later in window:      n={len(later):5d}  "
          f"accuracy={a2:.2%}" if a2 is not None else "  Locked later in window: n=0")
    print()


def main():
    run("BTC", None, "BTC-USD", BTC_ASSET, use_choppiness=True)
    run("XRP", "KXXRP15M", "XRP-USD", XRP_ASSET, use_choppiness=False)


if __name__ == "__main__":
    main()
