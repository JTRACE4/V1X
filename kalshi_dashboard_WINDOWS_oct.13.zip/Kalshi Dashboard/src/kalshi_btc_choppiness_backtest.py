"""Tests a choppiness veto against the DASHBOARD's actual mechanic - lock the
first call that clears the entry bar and HOLD IT to settlement (no defensive
exit, unlike the live trading bot). kalshi_spot_choppiness_backtest.py tested
choppiness against the live bot's defensive-exit economics and found no real
edge there - but that's a different mechanic (a bad chop-driven entry gets
cut early by the exit logic). The dashboard has no such safety net, so
choppiness could matter a lot more here. Real settled KXBTC15M markets +
real spot data, same framework as the other backtests in this project."""
import argparse
import statistics

from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records, build_spot_minute_map
from src.kalshi_live_bot import had_recent_sweep
from src.kalshi_web_dashboard import (
    BEAR_MIN_CONFIDENCE, REGIME_VETO_OVERRIDE_CONFIDENCE, momentum_confirms,
)

REGIME_LOOKBACK_MINUTES = 240
REGIME_THRESHOLD = 0.002
BTC_ASSET = {
    "entry_confidence_floor": 0.58,
    "strict_direction_margin": 0.0002,
    "sweep_lookback_minutes": 10,
    "sweep_recent_minutes": 2,
    "sweep_margin": 0.0003,
}


def regime_at(ts, spot_map):
    now_p = spot_map.get(ts)
    past_p = spot_map.get(ts - REGIME_LOOKBACK_MINUTES * 60)
    if now_p is None or past_p is None or past_p == 0:
        return None, None
    ret = now_p / past_p - 1
    if ret >= REGIME_THRESHOLD:
        return ret, "BULL"
    elif ret <= -REGIME_THRESHOLD:
        return ret, "BEAR"
    return ret, "NEUTRAL"


def closes_up_to(ts, spot_map, minutes):
    out = []
    for m in range(minutes, -1, -1):
        p = spot_map.get(ts - m * 60)
        if p is not None:
            out.append(p)
    return out


def choppiness_at(ts, spot_map, lookback_minutes):
    minute_ts = int(ts) // 60 * 60
    total = 0.0
    count = 0
    for i in range(lookback_minutes):
        t = minute_ts - i * 60
        p_now = spot_map.get(t)
        p_prev = spot_map.get(t - 60)
        if p_now is not None and p_prev is not None and p_prev != 0:
            total += abs(p_now / p_prev - 1)
            count += 1
    return total if count > 0 else None


def simulate_market(candles, result, spot_map, chop_threshold, chop_lookback):
    prices = prices_from_candles(candles)
    if len(prices) < 3:
        return None

    for ts, kalshi_price in prices:
        if kalshi_price <= 0.0 or kalshi_price >= 1.0:
            continue
        leaning = "YES" if kalshi_price > 0.5 else "NO"
        confidence = max(kalshi_price, 1 - kalshi_price)

        regime_ret, regime = regime_at(ts, spot_map)
        required_floor = BTC_ASSET["entry_confidence_floor"]
        if regime == "BEAR":
            required_floor = max(required_floor, BEAR_MIN_CONFIDENCE)
        below_floor = confidence < required_floor

        recent_closes = closes_up_to(ts, spot_map, 5)
        direction_confirms = momentum_confirms(recent_closes, leaning, BTC_ASSET["strict_direction_margin"])

        against_regime = ((regime == "BEAR" and leaning == "YES") or
                           (regime == "BULL" and leaning == "NO")) and (
            confidence < REGIME_VETO_OVERRIDE_CONFIDENCE)

        sweep_closes = closes_up_to(ts, spot_map, BTC_ASSET["sweep_lookback_minutes"])
        swept = had_recent_sweep(sweep_closes, BTC_ASSET["sweep_lookback_minutes"],
                                  BTC_ASSET["sweep_recent_minutes"], BTC_ASSET["sweep_margin"])

        chopped = False
        if chop_threshold is not None:
            chop = choppiness_at(ts, spot_map, chop_lookback)
            if chop is not None and chop > chop_threshold:
                chopped = True

        my_call = leaning if (not below_floor and direction_confirms and not swept
                               and not against_regime and not chopped) else None

        if my_call is not None:
            correct = my_call.lower() == (result or "").lower()
            return {"correct": correct}

    return None


def evaluate(records, spot_map, chop_threshold, chop_lookback):
    results = []
    for r in records:
        out = simulate_market(r["candles"], r["result"], spot_map, chop_threshold, chop_lookback)
        if out is not None:
            results.append(out)
    return results


def summarize(results, n_total, label):
    n = len(results)
    if n == 0:
        print(f"    {label}: no calls formed")
        return
    acc = sum(1 for r in results if r["correct"]) / n
    print(f"    {label}: n={n:5d}/{n_total} (coverage={n/n_total:.1%}) accuracy={acc:.2%}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lookback", type=int, default=4)
    args = parser.parse_args()

    print("Loading real KXBTC15M settled markets...")
    records = load_records()
    records = [r for r in records if r.get("result") in ("yes", "no")]
    print(f"{len(records)} with a valid yes/no result.")

    print("Loading BTC-USD spot 1-min data...")
    spot_map = build_spot_minute_map(records, symbol="BTC-USD")
    print()

    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, holdout = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(holdout)}\n")

    print("=== BASELINE (current live filters, no choppiness veto) ===")
    for label, data in (("TRAIN", train), ("HOLDOUT", holdout)):
        results = evaluate(data, spot_map, None, args.lookback)
        summarize(results, len(data), label)
    print()

    print(f"=== sweeping choppiness threshold on TRAIN (sum |1min ret| over last {args.lookback}min) ===")
    best = None
    for thresh in [0.0005, 0.0010, 0.0015, 0.0020, 0.0030, 0.0050, 0.0080]:
        results = evaluate(train, spot_map, thresh, args.lookback)
        n = len(results)
        if n == 0:
            continue
        acc = sum(1 for r in results if r["correct"]) / n
        print(f"  chop_threshold={thresh:.4f}: n={n:5d} accuracy={acc:.2%}")
        if best is None or acc > best[0]:
            best = (acc, thresh)

    if best:
        _, best_thresh = best
        print(f"\n=== best threshold ({best_thresh}) validated on HOLDOUT ===")
        results = evaluate(holdout, spot_map, best_thresh, args.lookback)
        summarize(results, len(holdout), "HOLDOUT")


if __name__ == "__main__":
    main()
