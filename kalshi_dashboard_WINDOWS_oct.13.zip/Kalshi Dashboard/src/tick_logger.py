"""Pure data-collection script - logs every real trade tick from Coinbase's live feed
to CSV, for building a real historical tick dataset over time. Does NOT feed into any
trading decision; completely separate from kalshi_paper_bot.py / kalshi_live_bot.py."""
import csv
import json
import os
import threading
import time

import websocket

STATE_DIR = os.path.join(os.path.dirname(__file__), "..", "bot_state")
PRODUCTS = ["BTC-USD", "ETH-USD", "XRP-USD", "BNB-USD"]
WS_URL = "wss://ws-feed.exchange.coinbase.com"

FIELDS = ["time", "product_id", "trade_id", "side", "price", "size"]
_files = {}
_writers = {}
_lock = threading.Lock()


def _tick_path(product_id):
    return os.path.join(STATE_DIR, f"ticks_{product_id}.csv")


def _ensure_writer(product_id):
    if product_id in _writers:
        return _writers[product_id]
    os.makedirs(STATE_DIR, exist_ok=True)
    path = _tick_path(product_id)
    is_new = not os.path.exists(path)
    f = open(path, "a", newline="")
    writer = csv.DictWriter(f, fieldnames=FIELDS)
    if is_new:
        writer.writeheader()
    _files[product_id] = f
    _writers[product_id] = writer
    return writer


def on_message(ws, message):
    data = json.loads(message)
    if data.get("type") != "match":
        return
    product_id = data.get("product_id")
    row = {
        "time": data.get("time"),
        "product_id": product_id,
        "trade_id": data.get("trade_id"),
        "side": data.get("side"),
        "price": data.get("price"),
        "size": data.get("size"),
    }
    with _lock:
        writer = _ensure_writer(product_id)
        writer.writerow(row)
        _files[product_id].flush()


def on_error(ws, error):
    print(f"  websocket error: {error}")


def on_close(ws, close_status_code, close_msg):
    print(f"  websocket closed (code={close_status_code}): {close_msg}")


def on_open(ws):
    sub_msg = {"type": "subscribe", "product_ids": PRODUCTS, "channels": ["matches"]}
    ws.send(json.dumps(sub_msg))
    print(f"Subscribed to trade ticks for {PRODUCTS}")
    print(f"Logging to {[_tick_path(p) for p in PRODUCTS]}")


def run_forever():
    while True:
        ws = websocket.WebSocketApp(
            WS_URL, on_open=on_open, on_message=on_message, on_error=on_error, on_close=on_close
        )
        ws.run_forever(ping_interval=30, ping_timeout=10)
        print("  connection dropped, reconnecting in 5s...")
        time.sleep(5)


if __name__ == "__main__":
    print("Tick logger started. Pure data collection - does not affect any trading bot.")
    run_forever()
