"""Tests whether reacting to a candle's high/low (available mid-candle, before it
closes) catches real predictive signal earlier than waiting for close-to-close -
or whether it mostly just catches noise that reverts before the candle closes."""
import numpy as np

from src.data import fetch_history
from src.kalshi_momentum_backtest import load_records

THRESHOLDS = [0.0005, 0.00035, 0.0002]


def build_kalshi_minute_series(records):
    series = {}
    for r in records:
        for c in r["candles"]:
            price = c.get("price", {}).get("close_dollars")
            if price is None:
                continue
            minute_ts = c["end_period_ts"] - (c["end_period_ts"] % 60)
            series[minute_ts] = float(price)
    return series


def main():
    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.")

    open_times_ms = [r["open_time"] for r in records]
    import datetime as dt
    open_times = [dt.datetime.fromisoformat(t.replace("Z", "+00:00")) for t in open_times_ms]
    span_start = min(open_times)
    days = (dt.datetime.now(dt.timezone.utc) - span_start).days + 2
    spot_df = fetch_history(symbol="BTC-USD", interval="1m", days=days)
    spot_df["minute_ts"] = spot_df["open_time"] // 1000
    close_map = dict(zip(spot_df["minute_ts"], spot_df["close"]))
    high_map = dict(zip(spot_df["minute_ts"], spot_df["high"]))
    low_map = dict(zip(spot_df["minute_ts"], spot_df["low"]))
    print(f"Got {len(close_map)} spot minute bars (with high/low).")

    kalshi_price = build_kalshi_minute_series(records)
    print(f"Got {len(kalshi_price)} kalshi minute bars.\n")

    # build aligned series: for minute t, close_ret / wick_ret computed over [t-60,t],
    # correlated against kalshi_chg over [t, t+60] (the validated lag+1 relationship)
    close_rets, wick_rets, kalshi_chgs = {}, {}, {}
    for t, price in kalshi_price.items():
        prev_price = kalshi_price.get(t - 60)
        if prev_price is not None:
            kalshi_chgs[t] = price - prev_price

        c_now, c_prev = close_map.get(t), close_map.get(t - 60)
        h_now, l_now = high_map.get(t), low_map.get(t)
        if c_now is not None and c_prev is not None and c_prev != 0:
            close_rets[t] = c_now / c_prev - 1
        if h_now is not None and l_now is not None and c_prev is not None and c_prev != 0:
            up = h_now / c_prev - 1
            down = l_now / c_prev - 1
            wick_rets[t] = up if abs(up) >= abs(down) else down

    # correlation check: does wick_ret[t] predict kalshi_chg[t+60] as well as close_ret[t] does?
    xs_close, xs_wick, ys, pullback_ratios = [], [], [], []
    for t, chg in kalshi_chgs.items():
        cr = close_rets.get(t - 60)
        wr = wick_rets.get(t - 60)
        if cr is None or wr is None:
            continue
        xs_close.append(cr)
        xs_wick.append(wr)
        ys.append(chg)

        # how much of the wick's move got given back by the close?
        # 0 = closed at the extreme (no pullback), 1 = closed back at the start
        prev_t = t - 60
        c_prev = close_map.get(prev_t - 60)
        c_now = close_map.get(prev_t)
        h_now, l_now = high_map.get(prev_t), low_map.get(prev_t)
        ratio = None
        if None not in (c_prev, c_now, h_now, l_now) and c_prev != 0:
            if wr > 0:
                excursion = h_now - c_prev
                giveback = h_now - c_now
            else:
                excursion = c_prev - l_now
                giveback = c_now - l_now
            if excursion > 0:
                ratio = giveback / excursion
        pullback_ratios.append(ratio)

    xs_close, xs_wick, ys = np.array(xs_close), np.array(xs_wick), np.array(ys)
    print(f"n={len(ys)} aligned points")
    print(f"correlation(close_ret, next kalshi_chg) = {np.corrcoef(xs_close, ys)[0,1]:.4f}  (baseline, already validated)")
    print(f"correlation(wick_ret,  next kalshi_chg) = {np.corrcoef(xs_wick, ys)[0,1]:.4f}  (new, using high/low)")

    print("\n--- extra signals: minutes where the WICK crossed a threshold but the CLOSE didn't ---")
    print(f"{'threshold':>10} {'extra_n':>8} {'avg_kalshi_chg_same_dir':>24} {'pct_same_direction':>19}")
    for threshold in THRESHOLDS:
        extra_kalshi_chgs = []
        same_dir = 0
        for i in range(len(ys)):
            wr, cr, chg = xs_wick[i], xs_close[i], ys[i]
            if abs(wr) >= threshold and abs(cr) < threshold:
                # signed so positive = kalshi moved in the direction the wick pointed
                signed_chg = chg if wr > 0 else -chg
                extra_kalshi_chgs.append(signed_chg)
                if signed_chg > 0:
                    same_dir += 1
        n = len(extra_kalshi_chgs)
        if n:
            print(f"{threshold:>10.5f} {n:>8} {np.mean(extra_kalshi_chgs):>24.4f} {same_dir / n:>18.1%}")
        else:
            print(f"{threshold:>10.5f} {n:>8}          n/a                 n/a")

    print("\n--- does pullback depth (how much of the wick got given back by the close) matter? ---")
    print("0.0 = closed right at the extreme (no pullback), 1.0 = closed back at the start, >1.0 = reversed past start")
    buckets = [(0.0, 0.25), (0.25, 0.5), (0.5, 0.75), (0.75, 1.0), (1.0, 999)]
    for threshold in THRESHOLDS:
        print(f"\n  threshold={threshold:.5f}:")
        print(f"  {'pullback range':>16} {'n':>7} {'avg_kalshi_chg_same_dir':>24} {'pct_same_direction':>19}")
        for lo, hi in buckets:
            bucket_chgs, same_dir = [], 0
            for i in range(len(ys)):
                wr, cr, chg, ratio = xs_wick[i], xs_close[i], ys[i], pullback_ratios[i]
                if ratio is None or not (lo <= ratio < hi):
                    continue
                if abs(wr) >= threshold and abs(cr) < threshold:
                    signed_chg = chg if wr > 0 else -chg
                    bucket_chgs.append(signed_chg)
                    if signed_chg > 0:
                        same_dir += 1
            n = len(bucket_chgs)
            label = f"{lo:.2f}-{hi:.2f}" if hi < 999 else f">{lo:.2f}"
            if n:
                print(f"  {label:>16} {n:>7} {np.mean(bucket_chgs):>24.4f} {same_dir / n:>18.1%}")
            else:
                print(f"  {label:>16} {n:>7}          n/a                 n/a")


if __name__ == "__main__":
    main()
