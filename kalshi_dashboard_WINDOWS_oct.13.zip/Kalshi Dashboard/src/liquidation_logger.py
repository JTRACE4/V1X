"""Pure data-collection script - polls OKX's public liquidation-orders endpoint
for BTC and ETH perpetual swaps and logs every forced-liquidation event to CSV,
building a real historical dataset over time. The endpoint only exposes a
rolling ~22 hours of history, so this needs to run continuously to accumulate
anything deeper. Does NOT feed into any trading decision - completely separate
from kalshi_paper_bot.py / kalshi_live_bot.py, same as tick_logger.py."""
import csv
import os
import time

import requests

STATE_DIR = os.path.join(os.path.dirname(__file__), "..", "bot_state")
INST_FAMILIES = {"BTC": "BTC-USDT", "ETH": "ETH-USDT"}
POLL_SECONDS = 20

FIELDS = ["logged_at", "symbol", "event_ts", "side", "pos_side", "size", "break_price", "bk_loss"]


def _log_path(symbol):
    return os.path.join(STATE_DIR, f"liquidations_{symbol}.csv")


def _ensure_file(symbol):
    os.makedirs(STATE_DIR, exist_ok=True)
    path = _log_path(symbol)
    if not os.path.exists(path):
        with open(path, "w", newline="") as f:
            csv.DictWriter(f, fieldnames=FIELDS).writeheader()
    return path


def fetch_liquidations(inst_family):
    resp = requests.get(
        "https://www.okx.com/api/v5/public/liquidation-orders",
        params={"instType": "SWAP", "instFamily": inst_family, "state": "filled"},
        timeout=15,
    )
    resp.raise_for_status()
    data = resp.json().get("data", [])
    events = []
    for batch in data:
        for det in batch.get("details", []):
            events.append({
                "event_ts": det["ts"], "side": det["side"], "pos_side": det["posSide"],
                "size": det["sz"], "break_price": det["bkPx"], "bk_loss": det["bkLoss"],
            })
    return events


def run_forever():
    seen = {symbol: set() for symbol in INST_FAMILIES}
    paths = {symbol: _ensure_file(symbol) for symbol in INST_FAMILIES}
    print(f"Liquidation logger started. Polling OKX every {POLL_SECONDS}s for {list(INST_FAMILIES.keys())}.")
    print(f"Logging to {list(paths.values())}")

    while True:
        for symbol, inst_family in INST_FAMILIES.items():
            try:
                events = fetch_liquidations(inst_family)
            except Exception as exc:
                print(f"  [{symbol}] poll error: {exc}")
                continue
            new_count = 0
            with open(paths[symbol], "a", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=FIELDS)
                for e in events:
                    key = (e["event_ts"], e["side"], e["size"], e["break_price"])
                    if key in seen[symbol]:
                        continue
                    seen[symbol].add(key)
                    writer.writerow({"logged_at": time.time(), "symbol": symbol, **e})
                    new_count += 1
            if new_count:
                print(f"  [{symbol}] logged {new_count} new liquidation events")
            # cap memory growth - the dedupe set only needs to cover the
            # endpoint's own ~22h rolling window, not forever
            if len(seen[symbol]) > 20000:
                seen[symbol] = set(list(seen[symbol])[-10000:])
        time.sleep(POLL_SECONDS)


if __name__ == "__main__":
    run_forever()
