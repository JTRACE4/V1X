"""Tests a defensive-exit threshold that shrinks as the position's confidence
approaches 50% (close to the target line, any move matters) and widens as
confidence approaches the extremes (far from target, small moves are noise).
Uses Kalshi's own price as a proxy for distance-to-target - no new data needed."""
import argparse
import statistics

from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records, build_spot_minute_map

EPS = 1e-9


def adaptive_threshold(confidence, base_threshold, min_threshold, scale_confidence=0.90):
    """confidence in [0.5, 1.0]. At scale_confidence, returns base_threshold.
    Shrinks toward min_threshold as confidence -> 0.5, grows above base as
    confidence -> 1.0."""
    span = confidence - 0.5
    scale_span = scale_confidence - 0.5
    ratio = span / scale_span if scale_span else 1.0
    threshold = min_threshold + ratio * (base_threshold - min_threshold)
    return max(min_threshold, threshold)


def simulate(candles, close_ts, result, spot_map, entry_minutes,
             entry_filter_threshold, base_threshold, min_threshold, use_adaptive):
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None

    entry_ts = close_ts - entry_minutes * 60
    entry_idx = None
    for i, (ts, _) in enumerate(prices):
        if ts <= entry_ts:
            entry_idx = i
        else:
            break
    if entry_idx is None:
        entry_idx = 0
    if entry_idx >= len(prices) - 1:
        return None

    entry_price = prices[entry_idx][1]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    if entry_filter_threshold is not None:
        entry_ts_actual = prices[entry_idx][0]
        spot_now = spot_map.get(entry_ts_actual)
        spot_prev = spot_map.get(entry_ts_actual - 60)
        if spot_now is not None and spot_prev is not None and spot_prev != 0:
            spot_ret = spot_now / spot_prev - 1
            adverse_at_entry = (side == "yes" and spot_ret <= -entry_filter_threshold) or \
                                (side == "no" and spot_ret >= entry_filter_threshold)
            if adverse_at_entry:
                return None

    for ts, p in prices[entry_idx + 1:]:
        confidence = max(p, 1 - p)
        threshold = adaptive_threshold(confidence, base_threshold, min_threshold) if use_adaptive else base_threshold

        spot_now = spot_map.get(ts)
        spot_prev = spot_map.get(ts - 60)
        if spot_now is not None and spot_prev is not None and spot_prev != 0:
            spot_ret = spot_now / spot_prev - 1
            adverse = (side == "yes" and spot_ret <= -threshold) or \
                      (side == "no" and spot_ret >= threshold)
            if adverse:
                price_side_now = p if side == "yes" else (1 - p)
                return {"payoff": price_side_now - cost, "reason": "defensive_exit"}

    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff, "reason": "settlement"}


def evaluate(records, spot_map, entry_minutes, entry_filter, base_threshold, min_threshold, use_adaptive, bet_size=100.0):
    payoffs = []
    reasons = {"defensive_exit": 0, "settlement": 0}
    for r in records:
        out = simulate(r["candles"], r["close_ts"], r["result"], spot_map, entry_minutes,
                        entry_filter, base_threshold, min_threshold, use_adaptive)
        if out is None:
            continue
        payoffs.append(out["payoff"])
        reasons[out["reason"]] += 1
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "non_negative": non_negative,
            "avg_payoff": statistics.mean(payoffs) * bet_size, "reasons": reasons}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--entry-minutes", type=float, default=3.5)
    parser.add_argument("--entry-filter", type=float, default=0.00005)
    parser.add_argument("--base-threshold", type=float, default=0.00035)
    args = parser.parse_args()

    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.")
    spot_map = build_spot_minute_map(records)

    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    print("--- current (fixed threshold) combo ---")
    fixed = evaluate(records, spot_map, args.entry_minutes, args.entry_filter, args.base_threshold, args.base_threshold, False)
    print(f"n={fixed['n']} non-neg={fixed['non_negative']:.2%} avgPay/$100={fixed['avg_payoff']:+.2f}\n")

    print("--- adaptive gap: selecting min_threshold on TRAIN ---")
    best = None
    for min_threshold in [0.00005, 0.0001, 0.00015, 0.0002, 0.00025, 0.0003, 0.00035]:
        res = evaluate(train, spot_map, args.entry_minutes, args.entry_filter, args.base_threshold, min_threshold, True)
        if res:
            print(f"  min_threshold={min_threshold:.5f}: n={res['n']} non-neg={res['non_negative']:.2%} "
                  f"avgPay/$100={res['avg_payoff']:+.2f}")
            if best is None or res["non_negative"] > best[0]["non_negative"]:
                best = (res, min_threshold)

    _, best_min = best
    print(f"\n--- adaptive gap (min_threshold={best_min}) validated on HOLDOUT ---")
    fixed_test = evaluate(test, spot_map, args.entry_minutes, args.entry_filter, args.base_threshold, args.base_threshold, False)
    adaptive_test = evaluate(test, spot_map, args.entry_minutes, args.entry_filter, args.base_threshold, best_min, True)
    print(f"fixed threshold holdout:    n={fixed_test['n']} non-neg={fixed_test['non_negative']:.2%} "
          f"avgPay/$100={fixed_test['avg_payoff']:+.2f}")
    print(f"adaptive gap holdout:       n={adaptive_test['n']} non-neg={adaptive_test['non_negative']:.2%} "
          f"avgPay/$100={adaptive_test['avg_payoff']:+.2f} reasons={adaptive_test['reasons']}")


if __name__ == "__main__":
    main()
