"""Replays the live XRP synthetic-asset call logic (kalshi_web_dashboard.py's
compute_synthetic_asset_snapshot) over ~73 days of real 1-min XRP-USD spot
history, to test on a much bigger sample (thousands of windows, vs. the ~96
graded in the live dashboard log so far) whether the BEAR regime is really a
weak spot, and whether a stricter filter there would have helped.

Honest limitation: the live system polls every ~2 seconds and requires a
directional confirmation to hold for BEAR_CONFIRM_STREAK_REQUIRED (3) polls
in a row before trusting it - roughly 6 seconds. This script only has 1-min
resolution, so that "hold for a few seconds" streak requirement is NOT
replayed faithfully (6 seconds is far below 1-minute granularity anyway, so
at minute resolution it barely changes anything live). Everything else -
confidence formula, entry floor, regime veto, sweep filter, self-referential
settlement, momentum-ratio computation - uses the EXACT same functions/
constants as the live dashboard, imported directly, so this can't silently
drift out of sync with what's actually running.

Windows are reconstructed on real Kalshi 15-min boundaries (:00/:15/:30/:45
UTC), self-referential settlement matching how the live code settles
synthetic assets (target = spot price at window open, final = spot price at
window close).
"""
import argparse
import datetime as dt
import statistics

from src.data import fetch_history
from src.kalshi_live_bot import had_recent_sweep
from src.kalshi_price_projection import project_point_for_minutes, EMPIRICAL_MOVES
from src.kalshi_web_dashboard import (
    XRP_PSEUDO_ASSET, BEAR_MIN_CONFIDENCE, REGIME_VETO_OVERRIDE_CONFIDENCE,
    MID_CONFIDENCE_BAND, MID_CONFIDENCE_STREAK_REQUIRED, momentum_confirms,
)

SYMBOL = "XRP-USD"
REGIME_LOOKBACK_MINUTES = 240
REGIME_THRESHOLD = 0.002
WINDOW_MINUTES = 15
EPS = 1e-9


def load_minute_closes(days=180):
    df = fetch_history(symbol=SYMBOL, interval="1m", days=days)
    df = df.sort_values("open_time")
    closes = df["close"].tolist()
    open_times = (df["open_time"] // 1000).astype(int).tolist()  # seconds, minute-open ts
    return open_times, closes


def build_windows(open_times, closes):
    """Group into 15-min windows aligned to real Kalshi boundaries. Each
    window needs a full run of 1-min bars covering exactly its 15 minutes,
    plus enough lookback (regime needs 240min) to compute everything - so the
    first ~4 hours of the dataset are lookback-only, not tradeable windows."""
    ts_to_idx = {ts: i for i, ts in enumerate(open_times)}
    windows = []
    start = open_times[0]
    # align to the next :00/:15/:30/:45 UTC boundary
    aligned_start = start - (start % (WINDOW_MINUTES * 60)) + WINDOW_MINUTES * 60
    cursor = aligned_start
    last_ts = open_times[-1]
    while cursor + WINDOW_MINUTES * 60 <= last_ts:
        minute_ts = [cursor + m * 60 for m in range(WINDOW_MINUTES)]
        close_ts = cursor + WINDOW_MINUTES * 60
        if all(t in ts_to_idx for t in minute_ts) and close_ts in ts_to_idx:
            windows.append((cursor, close_ts))
        cursor += WINDOW_MINUTES * 60
    return windows, ts_to_idx


def regime_at(idx, closes):
    lookback = REGIME_LOOKBACK_MINUTES
    if idx < lookback:
        return None, None
    ret = closes[idx] / closes[idx - lookback] - 1
    if ret >= REGIME_THRESHOLD:
        return ret, "BULL"
    elif ret <= -REGIME_THRESHOLD:
        return ret, "BEAR"
    return ret, "NEUTRAL"


def simulate_window(open_ts, close_ts, ts_to_idx, closes, pseudo_asset,
                     bear_floor, bear_momentum_cap, require_recent_agree=False):
    """Replays one window minute-by-minute, exactly mirroring the live
    lock-the-first-real-call-then-freeze mechanic. Returns a result dict or
    None if no call ever formed (matches live "NO CALL" behavior - excluded
    from accuracy, not counted as a loss)."""
    open_idx = ts_to_idx[open_ts]
    target = closes[open_idx]
    margin = pseudo_asset["strict_direction_margin"]
    sweep_lookback = pseudo_asset["sweep_lookback_minutes"]
    sweep_recent = pseudo_asset["sweep_recent_minutes"]
    sweep_margin = pseudo_asset["sweep_margin"]
    floor = pseudo_asset["entry_confidence_floor"]

    locked = None
    for m in range(1, WINDOW_MINUTES):  # minute 0 = window open, nothing to call on yet
        ts = open_ts + m * 60
        idx = ts_to_idx[ts]
        price = closes[idx]
        if price == target:
            continue
        leaning = "YES" if price > target else "NO"

        elapsed_minutes = m
        typical_move = project_point_for_minutes(0, SYMBOL, elapsed_minutes,
                                                   direction="YES", percentile="p50")
        if not typical_move:
            continue
        ratio = abs(price - target) / typical_move
        confidence = 0.5 + min(ratio, 1.0) * 0.45

        regime_ret, regime = regime_at(idx, closes)

        required_floor = floor
        if regime == "BEAR":
            required_floor = max(required_floor, bear_floor)
        below_floor = confidence < required_floor

        recent_closes = closes[max(0, idx - 5):idx + 1]
        direction_confirms = momentum_confirms(recent_closes, leaning, margin)

        # candidate extra filter under test: momentum_confirms passes on EITHER
        # the 1-min OR 2-min return clearing the margin - so a call can lock
        # off a 2-minute-old burst even if the most recent single minute has
        # already reversed. This requires the MOST RECENT minute to at least
        # not be clearly opposing the call (not a full confirmation, just "not
        # actively reversing right now").
        recent_reversal = False
        if require_recent_agree and idx >= 1:
            last_1min_ret = closes[idx] / closes[idx - 1] - 1
            if leaning == "YES" and last_1min_ret <= -margin * 0.5:
                recent_reversal = True
            elif leaning == "NO" and last_1min_ret >= margin * 0.5:
                recent_reversal = True

        against_regime = ((regime == "BEAR" and leaning == "YES") or
                           (regime == "BULL" and leaning == "NO")) and (
            confidence < REGIME_VETO_OVERRIDE_CONFIDENCE)

        sweep_closes = closes[max(0, idx - sweep_lookback):idx + 1]
        swept = had_recent_sweep(sweep_closes, sweep_lookback, sweep_recent, sweep_margin)

        momentum_ratio = None
        if idx >= 1:
            spot_ret = closes[idx] / closes[idx - 1] - 1
            momentum_ratio = abs(spot_ret) / margin

        # candidate extra filter under test: cap on momentum_ratio specifically
        # during BEAR (motivated by a real cluster of misses that all showed
        # 6-9x normal momentum readings). None = no cap (baseline/current live
        # behavior only has the confidence floor, not this).
        momentum_capped = (bear_momentum_cap is not None and regime == "BEAR"
                            and momentum_ratio is not None and momentum_ratio > bear_momentum_cap)

        my_call = leaning if (not below_floor and direction_confirms and not swept
                               and not against_regime and not momentum_capped
                               and not recent_reversal) else None

        if my_call is not None and locked is None:
            locked = {
                "call": my_call,
                "locked_regime": regime,
                "locked_momentum_ratio": momentum_ratio,
                "locked_minute": m,
            }
            break  # first real call this window locks and freezes, same as live

    if locked is None:
        return None

    final_idx = ts_to_idx[close_ts]
    final_price = closes[final_idx]
    actual_side = "YES" if final_price >= target else "NO"
    correct = locked["call"] == actual_side
    return {**locked, "correct": correct}


def evaluate(windows, ts_to_idx, closes, pseudo_asset, bear_floor, bear_momentum_cap,
             require_recent_agree=False):
    results = []
    for open_ts, close_ts in windows:
        r = simulate_window(open_ts, close_ts, ts_to_idx, closes, pseudo_asset,
                             bear_floor, bear_momentum_cap, require_recent_agree)
        if r is not None:
            results.append(r)
    return results


def summarize(results, label):
    n = len(results)
    if n == 0:
        print(f"    {label}: no calls formed")
        return
    acc = sum(1 for r in results if r["correct"]) / n
    bear = [r for r in results if r["locked_regime"] == "BEAR"]
    bear_acc = (sum(1 for r in bear if r["correct"]) / len(bear)) if bear else None
    non_bear = [r for r in results if r["locked_regime"] != "BEAR"]
    non_bear_acc = (sum(1 for r in non_bear if r["correct"]) / len(non_bear)) if non_bear else None
    bear_str = f"{bear_acc:.1%} (n={len(bear)})" if bear_acc is not None else "n/a"
    non_bear_str = f"{non_bear_acc:.1%} (n={len(non_bear)})" if non_bear_acc is not None else "n/a"
    print(f"    {label}: n={n:5d} overall={acc:.2%}  BEAR={bear_str}  non-BEAR={non_bear_str}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--days", type=int, default=180)
    args = parser.parse_args()

    print("Loading real XRP-USD 1-min history...")
    open_times, closes = load_minute_closes(args.days)
    print(f"Loaded {len(closes)} 1-min bars.")

    windows, ts_to_idx = build_windows(open_times, closes)
    print(f"Reconstructed {len(windows)} candidate 15-min windows.\n")

    windows_sorted = sorted(windows, key=lambda w: w[1])
    split = int(len(windows_sorted) * 0.8)
    train, holdout = windows_sorted[:split], windows_sorted[split:]
    print(f"train n={len(train)} windows, holdout n={len(holdout)} windows\n")

    variants = [
        ("BASELINE (current live: BEAR floor=0.65, no momentum cap)", BEAR_MIN_CONFIDENCE, None, False),
        ("BEAR floor=0.70, no momentum cap", 0.70, None, False),
        ("BEAR floor=0.75, no momentum cap", 0.75, None, False),
        ("BASELINE floor=0.65 + BEAR momentum cap=5x", BEAR_MIN_CONFIDENCE, 5.0, False),
        ("BASELINE floor=0.65 + BEAR momentum cap=3x", BEAR_MIN_CONFIDENCE, 3.0, False),
        ("BASELINE + require most-recent-minute not reversing", BEAR_MIN_CONFIDENCE, None, True),
    ]

    for label, bear_floor, bear_cap, require_recent in variants:
        print(f"=== {label} ===")
        for set_label, data in (("TRAIN", train), ("HOLDOUT", holdout)):
            results = evaluate(data, ts_to_idx, closes, XRP_PSEUDO_ASSET, bear_floor, bear_cap,
                                require_recent)
            summarize(results, set_label)
        print()


if __name__ == "__main__":
    main()
