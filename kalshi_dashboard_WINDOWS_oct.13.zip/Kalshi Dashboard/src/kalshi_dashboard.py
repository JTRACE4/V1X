"""Combined read-only dashboard: directional prediction (up/down lean +
implied probability), a statistically-grounded price range projection, and
real-time liquidity sweep alerts. NEVER places any order - pure information.

Honest scope, stated plainly each run:
- Direction/probability: this IS what we validated today (confidence floor,
  strict-direction confirmation) - a real, tested signal.
- Price range: honest statistics (volatility scaling), not a claim to know
  the future - tells you the SPREAD of plausible outcomes, not one number.
- Sweep alert: fires the moment a sweep is DETECTED (real-time), not before
  it happens. We could not find a way to predict one in advance (tested
  liquidations, funding rate depth was insufficient, order flow, EMA - none
  gave a validated early-warning signal).
"""
import argparse
import datetime as dt
import math
import time

from src.data import fetch_klines, drop_forming_candle
from src.kalshi_live_bot import (
    get_active_market, get_kalshi_price, get_spot_closes, spot_return_from_closes,
    had_recent_sweep, ASSETS,
)
from src.kalshi_price_projection import project_range, HORIZONS_MINUTES

_last_sweep_state = {}  # asset name -> bool, to only alert on the moment it FLIPS to True


def show_price_projection(symbol):
    df = fetch_klines(symbol=symbol, interval="1m", limit=5)
    df = drop_forming_candle(df, "1m")
    if len(df) < 1:
        return
    current_price = float(df["close"].iloc[-1])
    print(f"  price: ${current_price:,.2f}  (empirical ranges, not a theoretical model)")
    for h in HORIZONS_MINUTES:
        low, high = project_range(current_price, symbol, h, "p68")
        if low is None:
            continue
        print(f"    {h:>2}min range (68%): ${low:,.2f} - ${high:,.2f}")


def check_asset(asset):
    active = get_active_market(asset["series"])
    if active is None:
        print(f"\n=== {asset['name']}: no active market ===")
        return

    ticker = active["ticker"]
    close_time = dt.datetime.fromisoformat(active["close_time"].replace("Z", "+00:00"))
    now = dt.datetime.now(dt.timezone.utc)
    seconds_left = (close_time - now).total_seconds()
    kalshi_price = get_kalshi_price(active)

    print(f"\n=== {asset['name']} - {ticker} ({int(seconds_left // 60)}m {int(seconds_left % 60)}s left) ===")

    if kalshi_price is None:
        print("  no Kalshi price data right now.")
        return

    confidence = max(kalshi_price, 1 - kalshi_price)
    leaning = "YES" if kalshi_price > 0.5 else "NO"
    below_floor = confidence < asset["entry_confidence_floor"]

    spot_closes = get_spot_closes(asset["symbol"], asset["sweep_lookback_minutes"])
    spot_ret = spot_return_from_closes(spot_closes)
    swept = had_recent_sweep(spot_closes, asset["sweep_lookback_minutes"],
                              asset["sweep_recent_minutes"], asset["sweep_margin"])

    # sweep alert - only fire the moment it flips from not-swept to swept
    prev_swept = _last_sweep_state.get(asset["name"], False)
    if swept and not prev_swept:
        print(f"  *** LIQUIDITY SWEEP DETECTED RIGHT NOW on {asset['symbol']} - real-time, not advance warning ***")
    _last_sweep_state[asset["name"]] = swept

    print(f"  DIRECTION: {leaning} @ {confidence:.1%} implied probability"
          f"{' (below validated confidence floor)' if below_floor else ''}")
    if spot_ret is not None:
        print(f"  spot momentum: {spot_ret:+.4%}")
    print(f"  sweep status: {'ACTIVE - recent whipsaw' if swept else 'clear'}")

    show_price_projection(asset["symbol"])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--poll-seconds", type=int, default=10)
    args = parser.parse_args()

    print("Kalshi dashboard - read-only, never places any order. Ctrl+C to stop.")
    while True:
        for asset in ASSETS:
            try:
                check_asset(asset)
            except Exception as exc:
                print(f"{asset['name']}: error - {exc}")
        if args.once:
            break
        time.sleep(args.poll_seconds)


if __name__ == "__main__":
    main()
