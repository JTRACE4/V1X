import argparse
import statistics

from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records, build_spot_minute_map

EPS = 1e-9


def simulate_defensive_trade(candles, close_ts, result, spot_map, entry_minutes_before_close, adverse_jump_threshold):
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None

    entry_ts = close_ts - entry_minutes_before_close * 60
    entry_idx = None
    for i, (ts, _) in enumerate(prices):
        if ts <= entry_ts:
            entry_idx = i
        else:
            break
    if entry_idx is None:
        entry_idx = 0
    if entry_idx >= len(prices) - 1:
        return None

    entry_price = prices[entry_idx][1]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    for ts, p in prices[entry_idx + 1:]:
        spot_now = spot_map.get(ts)
        spot_prev = spot_map.get(ts - 60)
        if spot_now is not None and spot_prev is not None and spot_prev != 0:
            spot_ret = spot_now / spot_prev - 1
            adverse = (side == "yes" and spot_ret <= -adverse_jump_threshold) or \
                      (side == "no" and spot_ret >= adverse_jump_threshold)
            if adverse:
                price_side_now = p if side == "yes" else (1 - p)
                return {"payoff": price_side_now - cost, "reason": "momentum_exit"}

    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff, "reason": "settlement"}


def evaluate(records, spot_map, entry_minutes, adverse_jump_threshold):
    payoffs = []
    reasons = {"momentum_exit": 0, "settlement": 0}
    for r in records:
        out = simulate_defensive_trade(r["candles"], r["close_ts"], r["result"], spot_map,
                                        entry_minutes, adverse_jump_threshold)
        if out is None:
            continue
        payoffs.append(out["payoff"])
        reasons[out["reason"]] += 1

    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {
        "adverse_jump_threshold": adverse_jump_threshold, "n": n,
        "non_negative": non_negative, "avg_payoff": statistics.mean(payoffs),
        "reasons": reasons,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--entry-minutes", type=float, default=3)
    parser.add_argument("--bet-size", type=float, default=100.0)
    args = parser.parse_args()

    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.")
    spot_map = build_spot_minute_map(records)

    print(f"\n--- Baseline: close_favorite, hold to settlement, no exit (entry={args.entry_minutes}min) ---")
    baseline = evaluate(records, spot_map, args.entry_minutes, adverse_jump_threshold=999)
    print(f"n={baseline['n']} non-negative={baseline['non_negative']:.2%} "
          f"avg_payoff/$100={baseline['avg_payoff'] * args.bet_size:+.2f}")

    print(f"\n--- close_favorite + sell-on-adverse-momentum, various thresholds ---")
    print(f"{'threshold':>10} {'n':>6} {'non-neg':>9} {'avgPay/$100':>12} {'reasons'}")
    for threshold in [0.0003, 0.0004, 0.0005, 0.0007, 0.0010, 0.0015, 0.0020]:
        res = evaluate(records, spot_map, args.entry_minutes, threshold)
        if res:
            print(f"{threshold:>10.4f} {res['n']:>6} {res['non_negative']:>8.2%} "
                  f"{res['avg_payoff'] * args.bet_size:>12.2f}  {res['reasons']}")


if __name__ == "__main__":
    main()
