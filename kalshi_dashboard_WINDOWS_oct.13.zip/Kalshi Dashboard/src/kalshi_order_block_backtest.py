"""Tests an 'order block' filter (ICT/SMC concept): the last opposite-direction
1-min candle immediately before a strong impulsive move is treated as a zone
institutional orders may return to before continuing (or reversing). Tests
whether entering while price is retesting a recent, opposite-direction order
block zone correlates with worse outcomes for this strategy. Needs full OHLC
candles (not just close), unlike every prior test today. Local/cached data."""
import argparse
import datetime as dt
import statistics

from src.data import fetch_history
from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records
from src.kalshi_adaptive_gap_backtest import adaptive_threshold

EPS = 1e-9
BASE_ENTRY_MINUTES = 3.5
BASE_THRESHOLD = 0.00035
BASE_MIN_THRESHOLD = 0.00005
BASE_CONFIDENCE_FLOOR = 0.58
BASE_STRICT_MARGIN = 0.0002


def build_ohlc_map(records, symbol="BTC-USD"):
    open_times = [dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")) for r in records]
    span_start = min(open_times)
    days = (dt.datetime.now(dt.timezone.utc) - span_start).days + 2
    spot_df = fetch_history(symbol=symbol, interval="1m", days=days)
    spot_df["minute_ts"] = spot_df["open_time"] // 1000
    ohlc = {}
    for _, row in spot_df.iterrows():
        ohlc[int(row["minute_ts"])] = (row["open"], row["high"], row["low"], row["close"])
    close_map = {ts: o[3] for ts, o in ohlc.items()}
    return ohlc, close_map


def find_order_block_zone(ohlc, entry_ts, impulse_window, impulse_threshold, search_back):
    """Look backward for the most recent impulsive move within search_back
    minutes of entry, then find the last opposite-color candle right before
    it. Returns (zone_low, zone_high, impulse_direction) or None."""
    minute_ts = int(entry_ts) // 60 * 60
    for start_offset in range(0, search_back - impulse_window):
        window_start = minute_ts - (start_offset + impulse_window) * 60
        window_end = minute_ts - start_offset * 60
        o = ohlc.get(window_start + 60)  # open of first candle in window
        c = ohlc.get(window_end)          # close of last candle in window
        if o is None or c is None:
            continue
        move = (c[3] - o[0]) / o[0] if o[0] else 0
        if abs(move) < impulse_threshold:
            continue
        direction = "up" if move > 0 else "down"
        # search backward from window_start for the last opposite-color candle
        for back in range(0, 10):
            ts = window_start - back * 60
            candle = ohlc.get(ts)
            if candle is None:
                continue
            o2, h2, l2, c2 = candle
            is_bullish = c2 > o2
            if (direction == "up" and not is_bullish) or (direction == "down" and is_bullish):
                return (l2, h2, direction)
        return None
    return None


def find_entry_idx(prices, close_ts, entry_minutes, confidence_floor):
    window_start_ts = close_ts - entry_minutes * 60
    if confidence_floor <= 0.5:
        entry_idx = None
        for i, (ts, _) in enumerate(prices):
            if ts <= window_start_ts:
                entry_idx = i
            else:
                break
        return entry_idx if entry_idx is not None else 0
    for i, (ts, p) in enumerate(prices):
        if ts < window_start_ts or ts >= close_ts:
            continue
        if max(p, 1 - p) >= confidence_floor:
            return i
    return None


def simulate(candles, close_ts, result, ohlc, close_map, impulse_window, impulse_threshold,
             search_back, filter_on_ob):
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None
    entry_idx = find_entry_idx(prices, close_ts, BASE_ENTRY_MINUTES, BASE_CONFIDENCE_FLOOR)
    if entry_idx is None or entry_idx >= len(prices) - 1:
        return None
    entry_ts, entry_price = prices[entry_idx]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    spot_now = close_map.get(entry_ts)
    spot_prev = close_map.get(entry_ts - 60)
    if spot_now is None or spot_prev is None or spot_prev == 0:
        return None
    spot_ret = spot_now / spot_prev - 1
    favorable = (side == "yes" and spot_ret >= BASE_STRICT_MARGIN) or (side == "no" and spot_ret <= -BASE_STRICT_MARGIN)
    if not favorable:
        return None

    if filter_on_ob:
        zone = find_order_block_zone(ohlc, entry_ts, impulse_window, impulse_threshold, search_back)
        if zone is not None:
            zone_low, zone_high, direction = zone
            # retesting an order block that OPPOSES our current side is the
            # risky case per ICT theory - price may reverse there.
            opposes = (side == "yes" and direction == "down") or (side == "no" and direction == "up")
            in_zone = spot_now is not None and zone_low <= spot_now <= zone_high
            if opposes and in_zone:
                return None

    for ts, p in prices[entry_idx + 1:]:
        confidence = max(p, 1 - p)
        threshold = adaptive_threshold(confidence, BASE_THRESHOLD, BASE_MIN_THRESHOLD)
        spot_now2 = close_map.get(ts)
        spot_prev2 = close_map.get(ts - 60)
        if spot_now2 is not None and spot_prev2 is not None and spot_prev2 != 0:
            spot_ret2 = spot_now2 / spot_prev2 - 1
            adverse = (side == "yes" and spot_ret2 <= -threshold) or (side == "no" and spot_ret2 >= threshold)
            if adverse:
                price_side_now = p if side == "yes" else (1 - p)
                return {"payoff": price_side_now - cost}
    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff}


def evaluate(records, ohlc, close_map, impulse_window, impulse_threshold, search_back, filter_on_ob, bet_size=100.0):
    payoffs = []
    for r in records:
        out = simulate(r["candles"], r["close_ts"], r["result"], ohlc, close_map,
                        impulse_window, impulse_threshold, search_back, filter_on_ob)
        if out is None:
            continue
        payoffs.append(out["payoff"])
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "non_negative": non_negative, "avg_payoff": statistics.mean(payoffs) * bet_size,
            "total_payoff": sum(payoffs) * bet_size}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--series", default="KXBTC15M")
    parser.add_argument("--symbol", default="BTC-USD")
    args = parser.parse_args()

    records = load_records(series=args.series)
    print(f"Loaded {len(records)} historical market price paths.")
    ohlc, close_map = build_ohlc_map(records, symbol=args.symbol)
    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    print("--- current deployed setup (floor + strict direction, no OB filter) baseline ---")
    for label, data in (("TRAIN", train), ("HOLDOUT", test)):
        res = evaluate(data, ohlc, close_map, 3, 0.001, 20, False)
        print(f"{label}: n={res['n']} non-neg={res['non_negative']:.2%} avgPay/$100={res['avg_payoff']:+.2f} "
              f"total=${res['total_payoff']:+.2f}")

    print("\n--- sweeping order-block params on TRAIN (impulse_window/threshold/search_back) ---")
    best = None
    configs = [
        (2, 0.0005, 15), (3, 0.001, 15), (3, 0.001, 20), (5, 0.0015, 20),
        (5, 0.002, 30), (2, 0.0008, 10), (3, 0.0015, 25),
    ]
    for iw, it, sb in configs:
        res = evaluate(train, ohlc, close_map, iw, it, sb, True)
        if res:
            print(f"  impulse_window={iw}m threshold={it} search_back={sb}m: n={res['n']} "
                  f"non-neg={res['non_negative']:.2%} avgPay/$100={res['avg_payoff']:+.2f} "
                  f"total=${res['total_payoff']:+.2f}")
            if best is None or res["avg_payoff"] > best[0]["avg_payoff"]:
                best = (res, iw, it, sb)

    if best:
        _, biw, bit, bsb = best
        print(f"\n--- OB filter (impulse_window={biw}m threshold={bit} search_back={bsb}m) validated on HOLDOUT ---")
        res = evaluate(test, ohlc, close_map, biw, bit, bsb, True)
        print(f"n={res['n']} non-neg={res['non_negative']:.2%} avgPay/$100={res['avg_payoff']:+.2f} "
              f"total=${res['total_payoff']:+.2f}")


if __name__ == "__main__":
    main()
