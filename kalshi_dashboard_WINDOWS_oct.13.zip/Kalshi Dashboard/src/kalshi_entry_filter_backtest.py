import argparse
import statistics

from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records, build_spot_minute_map

EPS = 1e-9
DEFAULT_ENTRY_MINUTES = 3
DEFAULT_EXIT_THRESHOLD = 0.00035  # already-validated defensive exit for the 3min entry


def simulate_filtered_trade(candles, close_ts, result, spot_map, entry_minutes_before_close,
                             exit_threshold, entry_filter_threshold):
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None

    entry_ts = close_ts - entry_minutes_before_close * 60
    entry_idx = None
    for i, (ts, _) in enumerate(prices):
        if ts <= entry_ts:
            entry_idx = i
        else:
            break
    if entry_idx is None:
        entry_idx = 0
    if entry_idx >= len(prices) - 1:
        return None

    entry_price = prices[entry_idx][1]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    if entry_filter_threshold is not None:
        entry_ts_actual = prices[entry_idx][0]
        spot_now = spot_map.get(entry_ts_actual)
        spot_prev = spot_map.get(entry_ts_actual - 60)
        if spot_now is not None and spot_prev is not None and spot_prev != 0:
            spot_ret = spot_now / spot_prev - 1
            adverse_at_entry = (side == "yes" and spot_ret <= -entry_filter_threshold) or \
                                (side == "no" and spot_ret >= entry_filter_threshold)
            if adverse_at_entry:
                return {"payoff": None, "reason": "skipped_entry"}

    # matches the already-validated defensive exit: exit immediately the first time
    # an adverse spot move hits, otherwise hold to settlement (no lock-in/trailing).
    for ts, p in prices[entry_idx + 1:]:
        spot_now = spot_map.get(ts)
        spot_prev = spot_map.get(ts - 60)
        if spot_now is not None and spot_prev is not None and spot_prev != 0:
            spot_ret = spot_now / spot_prev - 1
            adverse = (side == "yes" and spot_ret <= -exit_threshold) or \
                      (side == "no" and spot_ret >= exit_threshold)
            if adverse:
                price_side_now = p if side == "yes" else (1 - p)
                return {"payoff": price_side_now - cost, "reason": "defensive_exit"}

    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff, "reason": "settlement"}


def evaluate(records, spot_map, entry_minutes, exit_threshold, entry_filter_threshold):
    payoffs = []
    skipped = 0
    reasons = {}
    for r in records:
        out = simulate_filtered_trade(r["candles"], r["close_ts"], r["result"], spot_map,
                                       entry_minutes, exit_threshold, entry_filter_threshold)
        if out is None:
            continue
        if out["reason"] == "skipped_entry":
            skipped += 1
            continue
        payoffs.append(out["payoff"])
        reasons[out["reason"]] = reasons.get(out["reason"], 0) + 1

    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {
        "entry_filter_threshold": entry_filter_threshold, "n": n, "skipped": skipped,
        "non_negative": non_negative, "avg_payoff": statistics.mean(payoffs), "reasons": reasons,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--entry-minutes", type=float, default=DEFAULT_ENTRY_MINUTES)
    parser.add_argument("--exit-threshold", type=float, default=DEFAULT_EXIT_THRESHOLD)
    parser.add_argument("--bet-size", type=float, default=100.0)
    args = parser.parse_args()

    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.")
    spot_map = build_spot_minute_map(records)

    print(f"\n--- Baseline: entry={args.entry_minutes}min, defensive exit only, no entry filter ---")
    baseline = evaluate(records, spot_map, args.entry_minutes, args.exit_threshold, None)
    print(f"n={baseline['n']} non-neg={baseline['non_negative']:.2%} "
          f"avgPay/$100={baseline['avg_payoff'] * args.bet_size:+.2f}")

    print(f"\n--- + entry filter: skip if momentum already opposes the bet, various thresholds ---")
    print(f"{'filter thr':>10} {'n':>6} {'skipped':>8} {'non-neg':>9} {'avgPay/$100':>12}")
    for threshold in [0.0001, 0.00015, 0.0002, 0.00025, 0.0003, 0.0004, 0.0005]:
        res = evaluate(records, spot_map, args.entry_minutes, args.exit_threshold, threshold)
        if res:
            print(f"{threshold:>10.5f} {res['n']:>6} {res['skipped']:>8} {res['non_negative']:>8.2%} "
                  f"{res['avg_payoff'] * args.bet_size:>12.2f}")


if __name__ == "__main__":
    main()
