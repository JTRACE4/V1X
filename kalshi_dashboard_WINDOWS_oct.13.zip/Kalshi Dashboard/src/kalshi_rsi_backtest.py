"""Tests whether RSI (Relative Strength Index) actually predicts direction in
these 15-min Kalshi windows before wiring it into the live dashboard as a
real filter. Standard 14-period RSI computed on 1-min BTC closes. Tests the
classic reading: RSI oversold (<30) -> predict up (yes), RSI overbought (>70)
-> predict down (no), checked at several detection points into the window.
Entirely local/cached data, no API calls, runs fast.
"""
import argparse
import datetime as dt
import statistics

from src.data import fetch_history
from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records

EPS = 1e-9
RSI_PERIOD = 14


def compute_rsi_series(closes, period=RSI_PERIOD):
    """Standard Wilder's RSI. Returns a list aligned with closes (first
    `period` entries are None - not enough data yet)."""
    n = len(closes)
    rsi = [None] * n
    if n <= period:
        return rsi
    gains, losses = [], []
    for i in range(1, period + 1):
        change = closes[i] - closes[i - 1]
        gains.append(max(change, 0))
        losses.append(max(-change, 0))
    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period
    rs = avg_gain / avg_loss if avg_loss > 0 else float("inf")
    rsi[period] = 100 - (100 / (1 + rs))
    for i in range(period + 1, n):
        change = closes[i] - closes[i - 1]
        gain = max(change, 0)
        loss = max(-change, 0)
        avg_gain = (avg_gain * (period - 1) + gain) / period
        avg_loss = (avg_loss * (period - 1) + loss) / period
        rs = avg_gain / avg_loss if avg_loss > 0 else float("inf")
        rsi[i] = 100 - (100 / (1 + rs))
    return rsi


def build_rsi_map(records, symbol="BTC-USD"):
    open_times = [dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")) for r in records]
    span_start = min(open_times)
    days = (dt.datetime.now(dt.timezone.utc) - span_start).days + 2
    df = fetch_history(symbol=symbol, interval="1m", days=days)
    df["minute_ts"] = df["open_time"] // 1000
    df = df.sort_values("minute_ts")
    closes = df["close"].tolist()
    timestamps = df["minute_ts"].tolist()
    rsi_series = compute_rsi_series(closes)
    return dict(zip(timestamps, rsi_series)), dict(zip(timestamps, closes))


def evaluate_market(r, rsi_map, price_map, detect_minutes, oversold, overbought, economic=False):
    open_ts = dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")).timestamp()
    result = r["result"]
    if result not in ("yes", "no"):
        return None
    minute_ts = int(open_ts) // 60 * 60
    check_ts = minute_ts + detect_minutes * 60
    rsi_val = rsi_map.get(check_ts)
    if rsi_val is None:
        return None

    if rsi_val <= oversold:
        predicted = "yes"
    elif rsi_val >= overbought:
        predicted = "no"
    else:
        return None

    if not economic:
        return {"correct": predicted == result}

    kalshi_prices = prices_from_candles(r["candles"])
    entry_price = None
    for ts, p in kalshi_prices:
        if ts <= check_ts:
            entry_price = p
        else:
            break
    if entry_price is None or entry_price in (0, 1):
        return None
    cost = entry_price if predicted == "yes" else (1 - entry_price)
    if cost <= 0:
        return None
    payoff = (1 - cost) if predicted == result else -cost
    return {"correct": predicted == result, "payoff": payoff, "cost": cost}


def run(records, rsi_map, price_map, detect_minutes, oversold, overbought, economic, bet_size=100.0):
    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]

    for label, data in (("TRAIN", train), ("HOLDOUT", test)):
        results = []
        for r in data:
            out = evaluate_market(r, rsi_map, price_map, detect_minutes, oversold, overbought, economic)
            if out:
                results.append(out)
        n = len(results)
        if n == 0:
            print(f"    {label}: no qualifying events found")
            continue
        acc = sum(1 for x in results if x["correct"]) / n
        if economic:
            payoffs = [x["payoff"] for x in results]
            print(f"    {label}: n={n:4d} accuracy={acc:.2%} avgPay/$100={statistics.mean(payoffs)*bet_size:+.2f} "
                  f"total/$100={sum(payoffs)*bet_size:+.2f}")
        else:
            print(f"    {label}: n={n:4d} accuracy={acc:.2%}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--series", default="KXBTC15M")
    parser.add_argument("--symbol", default="BTC-USD")
    args = parser.parse_args()

    records = load_records(series=args.series)
    print(f"Loaded {len(records)} historical market price paths.\n")
    rsi_map, price_map = build_rsi_map(records, args.symbol)
    print(f"Computed RSI({RSI_PERIOD}) on {len(rsi_map)} spot minute bars.\n")

    for detect_minutes in [5, 7, 10]:
        for oversold, overbought in [(30, 70), (25, 75), (20, 80)]:
            print(f"=== detect at minute {detect_minutes}, RSI<={oversold} (buy) / RSI>={overbought} (sell) - accuracy ===")
            run(records, rsi_map, price_map, detect_minutes, oversold, overbought, economic=False)
            print(f"=== same, ECONOMIC (real Kalshi price as cost) ===")
            run(records, rsi_map, price_map, detect_minutes, oversold, overbought, economic=True)
            print()


if __name__ == "__main__":
    main()
