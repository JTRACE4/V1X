"""Tests a hard, last-resort backstop: if Kalshi's own price for our held
side falls to some fraction of what we paid, exit immediately - regardless
of what the spot-based adaptive-gap signal says. Different from the earlier
'absolute floor stop' idea (tested standalone and rejected for hurting the
average) - this tests it as a SECONDARY backstop layered on top of the
already-validated adaptive gap, and specifically measures its effect on the
worst-case tail (where last night's real loss lives), not just the overall
average. Entirely local/cached data - no API calls, runs fast."""
import argparse
import statistics

from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records, build_spot_minute_map
from src.kalshi_adaptive_gap_backtest import adaptive_threshold

EPS = 1e-9
ENTRY_MINUTES = 3.5
BASE_THRESHOLD = 0.00035
MIN_THRESHOLD = 0.00005


def simulate(candles, close_ts, result, spot_map, floor_level):
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None
    entry_ts = close_ts - ENTRY_MINUTES * 60
    entry_idx = None
    for i, (ts, _) in enumerate(prices):
        if ts <= entry_ts:
            entry_idx = i
        else:
            break
    if entry_idx is None:
        entry_idx = 0
    if entry_idx >= len(prices) - 1:
        return None
    entry_price = prices[entry_idx][1]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    for ts, p in prices[entry_idx + 1:]:
        confidence = max(p, 1 - p)
        threshold = adaptive_threshold(confidence, BASE_THRESHOLD, MIN_THRESHOLD)
        spot_now = spot_map.get(ts)
        spot_prev = spot_map.get(ts - 60)
        if spot_now is not None and spot_prev is not None and spot_prev != 0:
            spot_ret = spot_now / spot_prev - 1
            adverse = (side == "yes" and spot_ret <= -threshold) or (side == "no" and spot_ret >= threshold)
            if adverse:
                price_side_now = p if side == "yes" else (1 - p)
                return {"payoff": price_side_now - cost, "reason": "adaptive_gap"}

        # hard backstop: regardless of the spot signal, bail if the position
        # itself has crashed to floor_level of what we paid
        if floor_level is not None:
            price_side_now = p if side == "yes" else (1 - p)
            if price_side_now <= cost * floor_level:
                return {"payoff": price_side_now - cost, "reason": "hard_floor"}

    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff, "reason": "settlement"}


def evaluate(records, spot_map, floor_level):
    payoffs = []
    reasons = {"adaptive_gap": 0, "hard_floor": 0, "settlement": 0}
    for r in records:
        out = simulate(r["candles"], r["close_ts"], r["result"], spot_map, floor_level)
        if out is None:
            continue
        payoffs.append(out["payoff"])
        reasons[out["reason"]] += 1
    n = len(payoffs)
    if n == 0:
        return None, None
    non_neg = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "non_neg": non_neg, "avg": statistics.mean(payoffs) * 100,
            "total": sum(payoffs) * 100, "reasons": reasons}, payoffs


def main():
    records = load_records(series="KXBTC15M")
    print(f"Loaded {len(records)} historical market price paths.")
    spot_map = build_spot_minute_map(records)
    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    floor_levels = [None, 0.95, 0.9, 0.85, 0.8, 0.7, 0.5, 0.3, 0.2, 0.1, 0.05]

    print("=" * 100)
    print("ALL events (train + holdout combined for a full picture, then holdout alone)")
    print("=" * 100)
    all_records = records_sorted
    baseline_res, baseline_payoffs = evaluate(all_records, spot_map, None)

    for label, records_set in (("FULL (train+holdout)", all_records), ("HOLDOUT ONLY", test)):
        print(f"\n--- {label} ---")
        print(f"{'floor':>8} | {'n':>5} | {'non-neg':>8} | {'avg/$100':>10} | {'total/$100':>12} | {'reasons'}")
        for floor in floor_levels:
            res, payoffs = evaluate(records_set, spot_map, floor)
            if res:
                label_f = "none" if floor is None else f"{floor:.0%}"
                print(f"{label_f:>8} | {res['n']:>5} | {res['non_neg']:>7.2%} | {res['avg']:>+9.2f} | "
                      f"{res['total']:>+11.2f} | {res['reasons']}")

    # worst-case tail: rank ALL events by their no-floor payoff, look at the
    # worst 10% specifically - the regime last night's loss lived in
    print(f"\n{'=' * 100}")
    print("WORST 10% of events (ranked by no-floor payoff) - does the hard floor help HERE specifically?")
    print("=" * 100)
    res_all, payoffs_all = evaluate(all_records, spot_map, None)
    order = sorted(range(len(payoffs_all)), key=lambda i: payoffs_all[i])
    worst_n = max(1, len(payoffs_all) // 10)
    worst_records = [all_records[i] for i in order[:worst_n] if i < len(all_records)]
    # re-map: evaluate() filters Nones, so index alignment needs the same
    # filtered record set - rebuild it explicitly
    filtered_records = [r for r in all_records if simulate(r["candles"], r["close_ts"], r["result"], spot_map, None) is not None]
    worst_records = [filtered_records[i] for i in order[:worst_n]]

    print(f"{'floor':>8} | {'n':>5} | {'non-neg':>8} | {'avg/$100':>10} | {'total/$100':>12} | {'reasons'}")
    for floor in floor_levels:
        res, payoffs = evaluate(worst_records, spot_map, floor)
        if res:
            label_f = "none" if floor is None else f"{floor:.0%}"
            print(f"{label_f:>8} | {res['n']:>5} | {res['non_neg']:>7.2%} | {res['avg']:>+9.2f} | "
                  f"{res['total']:>+11.2f} | {res['reasons']}")


if __name__ == "__main__":
    main()
