"""Does waiting N seconds before locking a call (the price must stay on the
called side, at/above the 58% floor, the whole time) improve call accuracy?
User report 2026-10-03: 'the bot would make a call and literally in the next
candle it would flip'. Simulates on the per-poll intrawindow logs, starting
from the moment the dashboard actually locked."""
import json
import os

import numpy as np
import pandas as pd

ROOT = os.path.join(os.path.dirname(__file__), "..")
FLOOR = 0.58
FEE = lambda p: 0.07 * p * (1 - p)

hist = json.load(open(os.path.join(ROOT, "data_cache", "kalshi_dashboard_history.json")))
res = {r["ticker"]: r["actual_side"] for a in ("BTC", "XRP") for r in hist[a] if r.get("actual_side")}


def side_px(row_yes, side):
    return row_yes if side == "YES" else 1 - row_yes


def simulate(g, wait, min_left=90):
    """From the bot's real lock moment, hold the call only once its side has
    stayed >= FLOOR for `wait` seconds straight. If the price flips over to
    the other side (>= FLOOR) first, start a new wait on that side. Returns
    (side, price at lock) or None if nothing confirmed before min_left."""
    g = g.sort_values("seconds_left", ascending=False)
    first = g.dropna(subset=["locked_call"])
    if first.empty:
        return None
    start = first.index[0]
    g = g.loc[start:]
    cand, since = None, None
    for _, r in g.iterrows():
        if r.seconds_left <= min_left:
            return None
        lean = "YES" if r.kalshi_price >= 0.5 else "NO"
        conf = side_px(r.kalshi_price, lean)
        if conf < FLOOR:
            cand, since = None, None
            continue
        if lean != cand:
            cand, since = lean, r.seconds_left
        if since - r.seconds_left >= wait:
            return cand, conf
    return None


def run(path, label):
    d = pd.read_csv(path)
    d["res"] = d.ticker.map(res)
    d = d.dropna(subset=["res"]).reset_index(drop=True)
    print(f"\n=== {label} ===")
    for a in ("BTC", "XRP"):
        x = d[d.asset == a]
        # flip check: favorite side 60s after the bot's real lock
        flips = []
        for tk, g in x.groupby("ticker"):
            g = g.sort_values("seconds_left", ascending=False)
            L = g.dropna(subset=["locked_call"])
            if L.empty or L.locked_call.iloc[0] not in ("YES", "NO"):
                continue
            call, t0 = L.locked_call.iloc[0], L.seconds_left.iloc[0]
            later = g[g.seconds_left <= t0 - 60]
            if later.empty:
                continue
            fav60 = "YES" if later.kalshi_price.iloc[0] >= 0.5 else "NO"
            flips.append(dict(flipped=fav60 != call, right=call == g.res.iloc[0]))
        F = pd.DataFrame(flips)
        print(f"  {a}: calls whose favorite had FLIPPED 60s after locking: {F.flipped.mean():.0%} of {len(F)}  "
              f"-> those calls were right {F[F.flipped].right.mean():.0%}, the rest {F[~F.flipped].right.mean():.0%}")
        for wait in (0, 15, 30, 45, 60, 90):
            out = []
            for tk, g in x.groupby("ticker"):
                s = simulate(g, wait)
                if s:
                    side, px = s
                    e = min(0.99, px + 0.01)
                    won = side == g.res.iloc[0]
                    out.append(dict(won=won, px=px, pnl=(1 if won else 0) - e - FEE(e)))
            O = pd.DataFrame(out)
            if len(O):
                roi = O.pnl.sum() / (O.px + 0.01).sum()
                print(f"    wait {wait:>3}s: calls={len(O):4}  right={O.won.mean():5.1%}  avg price={O.px.mean():.2f}  "
                      f"ROI per $ bet={roi:+6.1%}  (per $100 bets: ${roi*100*len(O):+6.0f})")


run(os.path.join(ROOT, "bot_state", "intrawindow_price_log_v1_stale_quotes.csv"),
    "OLD log Sep 24 - Oct 3 (prices up to 30s stale)")
run(os.path.join(ROOT, "bot_state", "intrawindow_price_log.csv"), "NEW log since update (live prices)")
