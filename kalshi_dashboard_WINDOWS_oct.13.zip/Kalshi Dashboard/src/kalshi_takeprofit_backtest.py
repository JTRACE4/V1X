"""Tests a simple take-profit rule on top of the already-validated close_favorite
design: if the position's price ever reaches >= threshold in our favor, sell
immediately and lock in the gain, instead of risking a hold to settlement."""
import argparse
import statistics

from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_path_backtest import load_records

EPS = 1e-9


def simulate(candles, close_ts, result, entry_minutes, take_profit_threshold):
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None

    entry_ts = close_ts - entry_minutes * 60
    entry_idx = None
    for i, (ts, _) in enumerate(prices):
        if ts <= entry_ts:
            entry_idx = i
        else:
            break
    if entry_idx is None:
        entry_idx = 0
    if entry_idx >= len(prices) - 1:
        return None

    entry_price = prices[entry_idx][1]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    for ts, p in prices[entry_idx + 1:]:
        price_side_now = p if side == "yes" else (1 - p)
        if take_profit_threshold is not None and price_side_now >= take_profit_threshold:
            return {"payoff": price_side_now - cost, "reason": "take_profit"}

    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff, "reason": "settlement"}


def evaluate(records, entry_minutes, take_profit_threshold, bet_size=100.0):
    payoffs = []
    reasons = {"take_profit": 0, "settlement": 0}
    for r in records:
        out = simulate(r["candles"], r["close_ts"], r["result"], entry_minutes, take_profit_threshold)
        if out is None:
            continue
        payoffs.append(out["payoff"])
        reasons[out["reason"]] += 1
    n = len(payoffs)
    if n == 0:
        return None
    non_negative = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "non_negative": non_negative,
            "avg_payoff": statistics.mean(payoffs) * bet_size, "reasons": reasons}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--entry-minutes", type=float, default=3)
    args = parser.parse_args()

    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.\n")

    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    print("--- baseline: hold to settlement, no take-profit ---")
    baseline = evaluate(records, args.entry_minutes, None)
    print(f"n={baseline['n']} non-neg={baseline['non_negative']:.2%} avgPay/$100={baseline['avg_payoff']:+.2f}\n")

    print("--- selecting best take-profit threshold on TRAIN ---")
    best = None
    for threshold in [0.90, 0.92, 0.94, 0.96, 0.98, 0.99]:
        res = evaluate(train, args.entry_minutes, threshold)
        if res:
            print(f"  {threshold:.2f}: n={res['n']} non-neg={res['non_negative']:.2%} "
                  f"avgPay/$100={res['avg_payoff']:+.2f} reasons={res['reasons']}")
            if best is None or res["non_negative"] > best[0]["non_negative"]:
                best = (res, threshold)

    _, best_threshold = best
    print(f"\n--- take-profit at {best_threshold} validated on HOLDOUT ---")
    baseline_test = evaluate(test, args.entry_minutes, None)
    tp_test = evaluate(test, args.entry_minutes, best_threshold)
    print(f"hold-only on holdout:       n={baseline_test['n']} non-neg={baseline_test['non_negative']:.2%} "
          f"avgPay/$100={baseline_test['avg_payoff']:+.2f}")
    print(f"take-profit on holdout:     n={tp_test['n']} non-neg={tp_test['non_negative']:.2%} "
          f"avgPay/$100={tp_test['avg_payoff']:+.2f} reasons={tp_test['reasons']}")


if __name__ == "__main__":
    main()
