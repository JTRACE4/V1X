import statistics
import time
import datetime as dt

from src.kalshi_favorite_backtest import BASE, SERIES, _get, fetch_settled_markets

OFFSET_MINUTES = [10, 8, 6, 5, 4, 3, 2, 1]
CONFIDENCE_BUCKETS = [
    (0.50, 0.60), (0.60, 0.70), (0.70, 0.80),
    (0.80, 0.90), (0.90, 0.95), (0.95, 1.001),
]
N_MARKETS = 1000
BET_SIZE = 100


def fetch_candles(ticker, open_time_iso, close_time_iso, series=SERIES):
    open_ts = int(dt.datetime.fromisoformat(open_time_iso.replace("Z", "+00:00")).timestamp())
    close_ts = int(dt.datetime.fromisoformat(close_time_iso.replace("Z", "+00:00")).timestamp())
    data = _get(
        f"{BASE}/series/{series}/markets/{ticker}/candlesticks",
        params={"period_interval": 1, "start_ts": open_ts, "end_ts": close_ts},
    )
    candles = sorted(data.get("candlesticks", []), key=lambda c: c["end_period_ts"])
    return candles, close_ts


def price_at_offset(candles, close_ts, offset_seconds):
    target_ts = close_ts - offset_seconds
    eligible = [c for c in candles if c["end_period_ts"] <= target_ts]
    chosen = eligible[-1] if eligible else (candles[0] if candles else None)
    if chosen is None:
        return None
    p = chosen.get("price", {}).get("close_dollars")
    return float(p) if p is not None else None


def bucket_for(confidence):
    for lo, hi in CONFIDENCE_BUCKETS:
        if lo <= confidence < hi:
            return (lo, hi)
    return None


def run():
    print(f"Fetching last {N_MARKETS} settled {SERIES} markets...")
    markets = fetch_settled_markets(N_MARKETS)
    print(f"Got {len(markets)} settled markets. Pulling full candle history for each...")

    # cell key: (offset_minutes, bucket) -> list of payoffs (profit per $1 wagered)
    cells = {}
    overall = {m: [] for m in OFFSET_MINUTES}

    for i, m in enumerate(markets):
        result = m.get("result")
        if result not in ("yes", "no"):
            continue
        candles, close_ts = fetch_candles(m["ticker"], m["open_time"], m["close_time"])
        if not candles:
            continue

        for minutes in OFFSET_MINUTES:
            price = price_at_offset(candles, close_ts, minutes * 60)
            if price is None or price == 0.5:
                continue
            favorite = "yes" if price > 0.5 else "no"
            cost = price if favorite == "yes" else (1 - price)
            confidence = max(price, 1 - price)
            won = favorite == result
            payoff = (1 - cost) if won else -cost

            overall[minutes].append(payoff)
            b = bucket_for(confidence)
            if b:
                cells.setdefault((minutes, b), []).append(payoff)

        if (i + 1) % 100 == 0:
            print(f"  ...{i + 1}/{len(markets)} processed")
        time.sleep(0.1)

    def summarize(payoffs):
        n = len(payoffs)
        if n < 2:
            return None
        mean = statistics.mean(payoffs)
        stdev = statistics.stdev(payoffs)
        se = stdev / (n ** 0.5)
        return {
            "n": n,
            "win_rate": sum(1 for p in payoffs if p > 0) / n,
            "ev_per_dollar": mean,
            "ev_per_100": mean * BET_SIZE,
            "se_per_100": se * BET_SIZE,
        }

    print("\n--- EV by entry time alone (all confidence levels pooled) ---")
    print(f"{'min before close':>17} {'n':>6} {'win rate':>10} {'EV/$100':>10} {'+/- 2SE':>10}")
    overall_rows = []
    for minutes in OFFSET_MINUTES:
        s = summarize(overall[minutes])
        if s:
            overall_rows.append((minutes, s))
            print(f"{minutes:>17} {s['n']:>6} {s['win_rate']:>9.2%} "
                  f"{s['ev_per_100']:>+9.2f} {2 * s['se_per_100']:>9.2f}")

    print("\n--- EV by (entry time x confidence bucket) ---")
    print(f"{'min before close':>17} {'price range':>13} {'n':>6} {'win rate':>10} {'EV/$100':>10} {'+/- 2SE':>10}")
    cell_rows = []
    for minutes in OFFSET_MINUTES:
        for b in CONFIDENCE_BUCKETS:
            payoffs = cells.get((minutes, b))
            if not payoffs:
                continue
            s = summarize(payoffs)
            if not s:
                continue
            cell_rows.append((minutes, b, s))
            label = f"{b[0]:.2f}-{min(b[1], 1.0):.2f}"
            print(f"{minutes:>17} {label:>13} {s['n']:>6} {s['win_rate']:>9.2%} "
                  f"{s['ev_per_100']:>+9.2f} {2 * s['se_per_100']:>9.2f}")

    cell_rows.sort(key=lambda r: r[2]["ev_per_100"], reverse=True)
    print("\n--- Top 5 cells by raw EV/$100 (may include small, noisy samples) ---")
    for minutes, b, s in cell_rows[:5]:
        label = f"{b[0]:.2f}-{min(b[1], 1.0):.2f}"
        significant = abs(s["ev_per_100"]) > 2 * s["se_per_100"]
        print(f"{minutes} min left, price {label}: EV/$100 = {s['ev_per_100']:+.2f} "
              f"(n={s['n']}, win rate={s['win_rate']:.2%}, "
              f"{'significant' if significant else 'NOT statistically significant'} at ~2SE)")


if __name__ == "__main__":
    run()
