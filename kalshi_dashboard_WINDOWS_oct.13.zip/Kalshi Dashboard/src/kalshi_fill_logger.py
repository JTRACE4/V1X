"""Read-only recorder of every fill on the Kalshi account - added 2026-10-02 so
another bot's behavior can be studied (entry timing, prices, exits) while it
trades. Never places or cancels anything; it only reads GET /portfolio/fills.

Each new fill is appended to bot_state/other_bot_fills.jsonl as the raw Kalshi
fill plus context: whether it came from this dashboard (order_id matches a row
in live_xrp_lock_trades.csv) and what the dashboard was calling at that moment
(its /locked endpoint).

Run detached, e.g.:
  powershell -Command "Start-Process <python.exe> -ArgumentList '-m','src.kalshi_fill_logger' -WorkingDirectory '<project>' -WindowStyle Hidden"
Stop it by killing that python process. Only one instance can run (file lock).
"""
import csv
import datetime as dt
import json
import os
import sys
import time

import requests

from src.kalshi_live_bot import AUTH_BASE, KalshiClient

ROOT = os.path.join(os.path.dirname(__file__), "..", "bot_state")
OUT = os.path.join(ROOT, "other_bot_fills.jsonl")
LOG = os.path.join(ROOT, "fill_logger.log")
LOCK = os.path.join(ROOT, "fill_logger.lock")
OUR_TRADES = os.path.join(ROOT, "live_xrp_lock_trades.csv")
POLL_SECONDS = 4


def log(msg):
    line = f"{dt.datetime.now().isoformat(timespec='seconds')}  {msg}"
    print(line, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def acquire_lock():
    os.makedirs(ROOT, exist_ok=True)
    f = open(LOCK, "a+")
    try:
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        f.close()
        return None
    return f


def our_order_ids():
    ids = set()
    try:
        with open(OUR_TRADES, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row.get("order_id"):
                    ids.add(row["order_id"])
    except OSError:
        pass
    return ids


def dashboard_context():
    try:
        return requests.get("http://127.0.0.1:8765/locked", timeout=2).json()
    except Exception:
        return None


def fetch_fills(client, min_ts):
    path = "/trade-api/v2/portfolio/fills"
    fills, cursor = [], None
    while True:
        params = {"limit": 200, "min_ts": int(min_ts)}
        if cursor:
            params["cursor"] = cursor
        resp = requests.get(AUTH_BASE + path.replace("/trade-api/v2", ""),
                            headers=client._headers("GET", path), params=params, timeout=20)
        resp.raise_for_status()
        j = resp.json()
        fills += j.get("fills", [])
        cursor = j.get("cursor")
        if not cursor or not j.get("fills"):
            return fills


def fill_key(f):
    return f.get("fill_id") or f.get("trade_id") or json.dumps(f, sort_keys=True)


def main():
    lock = acquire_lock()
    if lock is None:
        print("another fill logger is already running - exiting")
        sys.exit(1)
    client = KalshiClient()
    start = time.time()
    seen = set()
    try:
        with open(OUT, encoding="utf-8") as f:
            for line in f:
                try:
                    seen.add(json.loads(line).get("_key"))
                except ValueError:
                    pass
    except OSError:
        pass
    log("fill logger starting (read-only)")
    min_ts = start - 120
    ours = our_order_ids()
    last_ours_refresh = 0.0
    while True:
        try:
            if time.time() - last_ours_refresh > 15:
                ours, last_ours_refresh = our_order_ids(), time.time()
            new = [f for f in fetch_fills(client, min_ts) if fill_key(f) not in seen]
            if new:
                ctx = dashboard_context()
                with open(OUT, "a", encoding="utf-8") as out:
                    for f in sorted(new, key=lambda x: x.get("created_time", "")):
                        rec = {"_key": fill_key(f), "_seen_at": dt.datetime.now(dt.timezone.utc).isoformat(),
                               "_from_dashboard": f.get("order_id") in ours, "_dashboard_call": ctx, "fill": f}
                        out.write(json.dumps(rec) + "\n")
                        seen.add(rec["_key"])
                log(f"recorded {len(new)} new fill(s)")
        except Exception as exc:  # noqa: BLE001 - a read-only logger must never die on one bad poll
            log(f"poll failed: {exc!r}")
            time.sleep(10)
        time.sleep(POLL_SECONDS)


if __name__ == "__main__":
    main()
