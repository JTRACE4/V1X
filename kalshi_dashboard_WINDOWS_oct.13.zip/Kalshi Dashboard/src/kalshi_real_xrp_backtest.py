"""Big finding 2026-08-31: Kalshi actually runs a REAL, live, tradeable XRP
15-min market (KXXRP15M) - real floor_strike, real yes_bid/yes_ask, same
60-second-average settlement rule as BTC. The dashboard has never used it -
XRP has always been treated as a synthetic/self-computed asset (own captured
window-open reference, own confidence formula from spot-price distance alone)
even though a real, market-priced Kalshi contract exists. This tests whether
switching XRP to the REAL market (same mechanics as BTC: confidence =
max(kalshi_price, 1-kalshi_price), the SAME entry filters already validated
for BTC) beats the self-computed synthetic approach's ~65-66% backtested
accuracy (see kalshi_xrp_regime_backtest.py).

Uses a real cached settled-market price path (data_cache/kalshi_paths_KXXRP15M.pkl,
~3994 markets, Jun 20 - Aug 2) plus real XRP-USD spot 1-min data for the
regime/momentum/sweep filters - same framework already used for BTC's own
validated backtests (kalshi_confidence_floor_backtest.py etc.), just pointed
at XRP's real series."""
import argparse
import datetime as dt
import statistics

from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records, build_spot_minute_map
from src.kalshi_live_bot import had_recent_sweep, spot_return_from_closes
from src.kalshi_price_projection import project_point_for_minutes
from src.kalshi_web_dashboard import (
    XRP_PSEUDO_ASSET, BEAR_MIN_CONFIDENCE, REGIME_VETO_OVERRIDE_CONFIDENCE, momentum_confirms,
)

SYMBOL = "XRP-USD"
REGIME_LOOKBACK_MINUTES = 240
REGIME_THRESHOLD = 0.002
EPS = 1e-9


def regime_at(ts, spot_map):
    """Same 4hr-return regime read as live, but keyed off a real timestamp
    instead of an array index (spot_map is sparse/keyed by minute-ts)."""
    now_p = spot_map.get(ts)
    past_p = spot_map.get(ts - REGIME_LOOKBACK_MINUTES * 60)
    if now_p is None or past_p is None or past_p == 0:
        return None, None
    ret = now_p / past_p - 1
    if ret >= REGIME_THRESHOLD:
        return ret, "BULL"
    elif ret <= -REGIME_THRESHOLD:
        return ret, "BEAR"
    return ret, "NEUTRAL"


def closes_up_to(ts, spot_map, minutes):
    out = []
    for m in range(minutes, -1, -1):
        p = spot_map.get(ts - m * 60)
        if p is not None:
            out.append(p)
    return out


def simulate_market(candles, close_ts, result, spot_map, pseudo_asset,
                     bear_floor, use_filters=True):
    prices = prices_from_candles(candles)
    if len(prices) < 3:
        return None

    for ts, kalshi_price in prices:
        if kalshi_price <= 0.0 or kalshi_price >= 1.0:
            continue
        leaning = "YES" if kalshi_price > 0.5 else "NO"
        confidence = max(kalshi_price, 1 - kalshi_price)

        if not use_filters:
            my_call = leaning
        else:
            regime_ret, regime = regime_at(ts, spot_map)
            required_floor = pseudo_asset["entry_confidence_floor"]
            if regime == "BEAR":
                required_floor = max(required_floor, bear_floor)
            below_floor = confidence < required_floor

            recent_closes = closes_up_to(ts, spot_map, 5)
            direction_confirms = momentum_confirms(recent_closes, leaning,
                                                     pseudo_asset["strict_direction_margin"])

            against_regime = ((regime == "BEAR" and leaning == "YES") or
                               (regime == "BULL" and leaning == "NO")) and (
                confidence < REGIME_VETO_OVERRIDE_CONFIDENCE)

            sweep_closes = closes_up_to(ts, spot_map, pseudo_asset["sweep_lookback_minutes"])
            swept = had_recent_sweep(sweep_closes, pseudo_asset["sweep_lookback_minutes"],
                                      pseudo_asset["sweep_recent_minutes"], pseudo_asset["sweep_margin"])

            my_call = leaning if (not below_floor and direction_confirms and not swept
                                   and not against_regime) else None

        if my_call is not None:
            correct = my_call.lower() == (result or "").lower()
            return {"correct": correct, "locked_regime": regime_at(ts, spot_map)[1] if use_filters else None}

    return None


def simulate_market_spot_based(candles, open_time, close_ts, result, spot_map, pseudo_asset, bear_floor):
    """Isolates ONE variable at a time: same self-computed spot-distance
    confidence formula and same entry filters as the old synthetic approach
    (kalshi_xrp_regime_backtest.py), but graded against the REAL, accurate
    settlement result instead of a self-captured single-tick 'final price'.
    If this scores close to the real-market variant, the earlier ~66% number
    was mostly a grading-noise artifact, not a real signal-quality gap. If it
    still scores well below, Kalshi's own price genuinely carries signal
    beyond just cleaner settlement accounting."""
    import datetime as _dt
    open_dt = _dt.datetime.fromisoformat(open_time.replace("Z", "+00:00"))
    open_ts = int(open_dt.timestamp())
    open_minute_ts = open_ts - (open_ts % 60)
    target = spot_map.get(open_minute_ts)
    if target is None:
        return None

    minute_ts = open_minute_ts + 60
    while minute_ts < close_ts:
        price = spot_map.get(minute_ts)
        if price is not None and price != target:
            leaning = "YES" if price > target else "NO"
            elapsed_minutes = (minute_ts - open_minute_ts) / 60
            typical_move = project_point_for_minutes(0, SYMBOL, elapsed_minutes,
                                                       direction="YES", percentile="p50")
            if typical_move:
                ratio = abs(price - target) / typical_move
                confidence = 0.5 + min(ratio, 1.0) * 0.45

                regime_ret, regime = regime_at(minute_ts, spot_map)
                required_floor = pseudo_asset["entry_confidence_floor"]
                if regime == "BEAR":
                    required_floor = max(required_floor, bear_floor)
                below_floor = confidence < required_floor

                recent_closes = closes_up_to(minute_ts, spot_map, 5)
                direction_confirms = momentum_confirms(recent_closes, leaning,
                                                         pseudo_asset["strict_direction_margin"])

                against_regime = ((regime == "BEAR" and leaning == "YES") or
                                   (regime == "BULL" and leaning == "NO")) and (
                    confidence < REGIME_VETO_OVERRIDE_CONFIDENCE)

                sweep_closes = closes_up_to(minute_ts, spot_map, pseudo_asset["sweep_lookback_minutes"])
                swept = had_recent_sweep(sweep_closes, pseudo_asset["sweep_lookback_minutes"],
                                          pseudo_asset["sweep_recent_minutes"], pseudo_asset["sweep_margin"])

                if not below_floor and direction_confirms and not swept and not against_regime:
                    correct = leaning.lower() == (result or "").lower()
                    return {"correct": correct, "locked_regime": regime}
        minute_ts += 60
    return None


def evaluate_spot_based(records, spot_map, pseudo_asset, bear_floor):
    results = []
    for r in records:
        out = simulate_market_spot_based(r["candles"], r["open_time"], r["close_ts"], r["result"],
                                          spot_map, pseudo_asset, bear_floor)
        if out is not None:
            results.append(out)
    return results


def evaluate(records, spot_map, pseudo_asset, bear_floor, use_filters):
    results = []
    for r in records:
        out = simulate_market(r["candles"], r["close_ts"], r["result"], spot_map,
                               pseudo_asset, bear_floor, use_filters)
        if out is not None:
            results.append(out)
    return results


def summarize(results, n_total, label):
    n = len(results)
    if n == 0:
        print(f"    {label}: no calls formed")
        return
    acc = sum(1 for r in results if r["correct"]) / n
    print(f"    {label}: n={n:5d}/{n_total} (coverage={n/n_total:.1%}) accuracy={acc:.2%}")


def main():
    parser = argparse.ArgumentParser()
    args = parser.parse_args()

    print("Loading real KXXRP15M settled markets...")
    records = load_records(series="KXXRP15M")
    print(f"Loaded {len(records)} real settled XRP markets.")
    records = [r for r in records if r.get("result") in ("yes", "no")]
    print(f"{len(records)} with a valid yes/no result.\n")

    print("Loading XRP-USD spot 1-min data for regime/momentum/sweep filters...")
    spot_map = build_spot_minute_map(records, symbol=SYMBOL)
    print()

    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, holdout = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(holdout)}\n")

    print("=== REAL Kalshi XRP market, UNFILTERED (take leaning at first available tick) ===")
    for label, data in (("TRAIN", train), ("HOLDOUT", holdout)):
        results = evaluate(data, spot_map, XRP_PSEUDO_ASSET, BEAR_MIN_CONFIDENCE, use_filters=False)
        summarize(results, len(data), label)
    print()

    print("=== REAL Kalshi XRP market, WITH live-style filters (floor/regime/momentum/sweep) ===")
    for label, data in (("TRAIN", train), ("HOLDOUT", holdout)):
        results = evaluate(data, spot_map, XRP_PSEUDO_ASSET, BEAR_MIN_CONFIDENCE, use_filters=True)
        summarize(results, len(data), label)
    print()

    print("=== SPOT-based self-computed signal (old synthetic formula), same filters, "
          "graded against the REAL settlement result (isolates signal quality from grading noise) ===")
    for label, data in (("TRAIN", train), ("HOLDOUT", holdout)):
        results = evaluate_spot_based(data, spot_map, XRP_PSEUDO_ASSET, BEAR_MIN_CONFIDENCE)
        summarize(results, len(data), label)
    print()


if __name__ == "__main__":
    main()
