"""Look up the real status of a specific order by ID - read-only, places no orders.
Usage: python -m src.kalshi_check_order <order_id>"""
import sys

import requests

from src.kalshi_live_bot import AUTH_BASE, KalshiClient


def main():
    if len(sys.argv) < 2:
        print("Usage: python -m src.kalshi_check_order <order_id>")
        return
    order_id = sys.argv[1]

    client = KalshiClient()
    path = f"/trade-api/v2/portfolio/orders/{order_id}"
    resp = requests.get(AUTH_BASE + path.replace("/trade-api/v2", ""),
                         headers=client._headers("GET", path), timeout=20)
    if resp.status_code != 200:
        print(f"FAILED - status {resp.status_code}")
        print(resp.text)
        return
    data = resp.json()
    print(data)


if __name__ == "__main__":
    main()
