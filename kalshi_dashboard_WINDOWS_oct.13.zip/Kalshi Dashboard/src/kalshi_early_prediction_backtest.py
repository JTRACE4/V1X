"""Tests whether the side favored EARLY in a market's 15-minute life (minutes
1-14 after open) predicts the final settlement well enough to trade on - and
whether that's more profitable than waiting until close (current strategy),
since an early entry is much cheaper but less certain. Pure "buy and hold to
settlement" at each offset - no defensive exit - to isolate the raw signal
before layering anything else on top."""
import argparse
import datetime as dt
import statistics

from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records

EPS = 1e-9


def price_at_offset_from_open(prices, open_ts, offset_seconds):
    target = open_ts + offset_seconds
    candidate = None
    for ts, p in prices:
        if ts <= target:
            candidate = (ts, p)
        else:
            break
    return candidate


def evaluate_offset(records, offset_seconds, bet_size=100.0):
    payoffs = []
    correct = 0
    n = 0
    for r in records:
        prices = prices_from_candles(r["candles"])
        if len(prices) < 2:
            continue
        open_ts = min(ts for ts, _ in prices)
        close_ts = r["close_ts"]
        if open_ts + offset_seconds >= close_ts:
            continue
        found = price_at_offset_from_open(prices, open_ts, offset_seconds)
        if found is None:
            continue
        _, price = found
        if price == 0.5:
            continue
        side = "yes" if price > 0.5 else "no"
        cost = price if side == "yes" else (1 - price)
        result = r["result"]
        if side == result:
            correct += 1
        payoff = (1 - cost) if side == result else -cost
        payoffs.append(payoff)
        n += 1
    if n == 0:
        return None
    return {
        "n": n,
        "accuracy": correct / n,
        "non_negative": sum(1 for p in payoffs if p >= -EPS) / n,
        "avg_payoff": statistics.mean(payoffs) * bet_size,
        "total_payoff": sum(payoffs) * bet_size,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--offsets-minutes", type=str,
                         default="1,2,3,4,5,6,7,8,9,10,11,11.5,12,12.5,13")
    args = parser.parse_args()

    records = load_records()
    print(f"Loaded {len(records)} historical market price paths.\n")

    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    offsets = [float(x) for x in args.offsets_minutes.split(",")]

    print(f"{'offset(min after open)':>24} | {'TRAIN n':>8} {'TRAIN acc':>10} {'TRAIN avgPay':>13} "
          f"| {'HOLDOUT n':>10} {'HOLDOUT acc':>12} {'HOLDOUT avgPay':>15} {'HOLDOUT total':>14}")
    for offset_min in offsets:
        offset_s = offset_min * 60
        train_res = evaluate_offset(train, offset_s)
        test_res = evaluate_offset(test, offset_s)
        if train_res is None or test_res is None:
            print(f"{offset_min:>24} | insufficient data")
            continue
        print(f"{offset_min:>24} | {train_res['n']:>8} {train_res['accuracy']:>9.2%} "
              f"{train_res['avg_payoff']:>+12.2f} | {test_res['n']:>10} {test_res['accuracy']:>11.2%} "
              f"{test_res['avg_payoff']:>+14.2f} {test_res['total_payoff']:>+13.2f}")


if __name__ == "__main__":
    main()
