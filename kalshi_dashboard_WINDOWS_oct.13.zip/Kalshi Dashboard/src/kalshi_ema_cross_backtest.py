"""Tests whether an EMA crossover on real spot price (fast EMA crossing slow
EMA - the classic trend-change signal) adds value on top of the already-
deployed combo (confidence floor + strict direction + sweep filter). Tests
two uses: (1) as an ENTRY filter - only enter if a recent crossover confirms
our side, and (2) as a DEFENSIVE EXIT - bail if the EMAs cross against a held
position, regardless of the existing adaptive-gap signal. Entirely local/
cached data, no API calls, runs fast."""
import argparse
import datetime as dt
import statistics

from src.data import fetch_history
from src.kalshi_exit_sim import prices_from_candles
from src.kalshi_momentum_backtest import load_records
from src.kalshi_adaptive_gap_backtest import adaptive_threshold

EPS = 1e-9
BASE_ENTRY_MINUTES = 3.5
BASE_THRESHOLD = 0.00035
BASE_MIN_THRESHOLD = 0.00005
BASE_CONFIDENCE_FLOOR = 0.58
BASE_STRICT_MARGIN = 0.0002


def build_price_series(records, symbol="BTC-USD"):
    open_times = [dt.datetime.fromisoformat(r["open_time"].replace("Z", "+00:00")) for r in records]
    span_start = min(open_times)
    days = (dt.datetime.now(dt.timezone.utc) - span_start).days + 2
    spot_df = fetch_history(symbol=symbol, interval="1m", days=days)
    spot_df["minute_ts"] = spot_df["open_time"] // 1000
    spot_df = spot_df.sort_values("minute_ts")
    return spot_df["minute_ts"].tolist(), spot_df["close"].tolist()


def compute_emas(timestamps, closes, fast_period, slow_period):
    """Returns {minute_ts: (fast_ema, slow_ema)}. Standard EMA smoothing."""
    fast_k = 2 / (fast_period + 1)
    slow_k = 2 / (slow_period + 1)
    fast_ema = closes[0]
    slow_ema = closes[0]
    out = {}
    for ts, c in zip(timestamps, closes):
        fast_ema = c * fast_k + fast_ema * (1 - fast_k)
        slow_ema = c * slow_k + slow_ema * (1 - slow_k)
        out[ts] = (fast_ema, slow_ema)
    return out


def find_entry_idx(prices, close_ts, entry_minutes, confidence_floor):
    window_start_ts = close_ts - entry_minutes * 60
    if confidence_floor <= 0.5:
        entry_idx = None
        for i, (ts, _) in enumerate(prices):
            if ts <= window_start_ts:
                entry_idx = i
            else:
                break
        return entry_idx if entry_idx is not None else 0
    for i, (ts, p) in enumerate(prices):
        if ts < window_start_ts or ts >= close_ts:
            continue
        if max(p, 1 - p) >= confidence_floor:
            return i
    return None


def ema_direction(ema_map, ts):
    """1 if fast > slow (bullish), -1 if fast < slow (bearish), 0 if no data."""
    v = ema_map.get(ts)
    if v is None:
        return 0
    fast, slow = v
    if fast > slow:
        return 1
    if fast < slow:
        return -1
    return 0


def simulate(candles, close_ts, result, price_map, ema_map, entry_filter_kind, exit_filter_kind):
    prices = prices_from_candles(candles)
    if len(prices) < 2:
        return None
    entry_idx = find_entry_idx(prices, close_ts, BASE_ENTRY_MINUTES, BASE_CONFIDENCE_FLOOR)
    if entry_idx is None or entry_idx >= len(prices) - 1:
        return None
    entry_ts, entry_price = prices[entry_idx]
    if entry_price == 0.5:
        return None
    side = "yes" if entry_price > 0.5 else "no"
    cost = entry_price if side == "yes" else (1 - entry_price)

    spot_now = price_map.get(entry_ts)
    spot_prev = price_map.get(entry_ts - 60)
    if spot_now is None or spot_prev is None or spot_prev == 0:
        return None
    spot_ret = spot_now / spot_prev - 1
    favorable = (side == "yes" and spot_ret >= BASE_STRICT_MARGIN) or (side == "no" and spot_ret <= -BASE_STRICT_MARGIN)
    if not favorable:
        return None

    if entry_filter_kind == "ema_confirm":
        minute_ts = int(entry_ts) // 60 * 60
        direction = ema_direction(ema_map, minute_ts)
        wants = 1 if side == "yes" else -1
        if direction != wants:
            return None

    for ts, p in prices[entry_idx + 1:]:
        confidence = max(p, 1 - p)
        threshold = adaptive_threshold(confidence, BASE_THRESHOLD, BASE_MIN_THRESHOLD)
        spot_now2 = price_map.get(ts)
        spot_prev2 = price_map.get(ts - 60)
        if spot_now2 is not None and spot_prev2 is not None and spot_prev2 != 0:
            spot_ret2 = spot_now2 / spot_prev2 - 1
            adverse = (side == "yes" and spot_ret2 <= -threshold) or (side == "no" and spot_ret2 >= threshold)
            if adverse:
                price_side_now = p if side == "yes" else (1 - p)
                return {"payoff": price_side_now - cost}

        if exit_filter_kind == "ema_cross_exit":
            minute_ts = int(ts) // 60 * 60
            direction = ema_direction(ema_map, minute_ts)
            wants = 1 if side == "yes" else -1
            if direction != 0 and direction != wants:
                price_side_now = p if side == "yes" else (1 - p)
                return {"payoff": price_side_now - cost}

    settlement_payoff = (1 - cost) if side == result else -cost
    return {"payoff": settlement_payoff}


def evaluate(records, price_map, ema_map, entry_filter_kind, exit_filter_kind, bet_size=100.0):
    payoffs = []
    for r in records:
        out = simulate(r["candles"], r["close_ts"], r["result"], price_map, ema_map,
                        entry_filter_kind, exit_filter_kind)
        if out is None:
            continue
        payoffs.append(out["payoff"])
    n = len(payoffs)
    if n == 0:
        return None
    non_neg = sum(1 for p in payoffs if p >= -EPS) / n
    return {"n": n, "non_neg": non_neg, "avg": statistics.mean(payoffs) * bet_size,
            "total": sum(payoffs) * bet_size}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--series", default="KXBTC15M")
    parser.add_argument("--symbol", default="BTC-USD")
    parser.add_argument("--fast", type=int, default=9)
    parser.add_argument("--slow", type=int, default=21)
    args = parser.parse_args()

    records = load_records(series=args.series)
    print(f"Loaded {len(records)} historical market price paths.")
    timestamps, closes = build_price_series(records, symbol=args.symbol)
    price_map = dict(zip(timestamps, closes))
    ema_map = compute_emas(timestamps, closes, args.fast, args.slow)
    print(f"EMA({args.fast})/EMA({args.slow}) computed on {len(timestamps)} 1-min spot bars.\n")

    records_sorted = sorted(records, key=lambda r: r["close_ts"])
    split = int(len(records_sorted) * 0.8)
    train, test = records_sorted[:split], records_sorted[split:]
    print(f"train n={len(train)}, holdout n={len(test)}\n")

    configs = [
        ("baseline (current combo, no EMA)", None, None),
        ("EMA entry confirmation", "ema_confirm", None),
        ("EMA defensive exit", None, "ema_cross_exit"),
        ("EMA entry + exit combined", "ema_confirm", "ema_cross_exit"),
    ]

    for label, entry_kind, exit_kind in configs:
        train_res = evaluate(train, price_map, ema_map, entry_kind, exit_kind)
        test_res = evaluate(test, price_map, ema_map, entry_kind, exit_kind)
        print(f"--- {label} ---")
        if train_res:
            print(f"  TRAIN:   n={train_res['n']:4d} non-neg={train_res['non_neg']:.2%} "
                  f"avg/$100={train_res['avg']:+.2f} total/$100={train_res['total']:+.2f}")
        if test_res:
            print(f"  HOLDOUT: n={test_res['n']:4d} non-neg={test_res['non_neg']:.2%} "
                  f"avg/$100={test_res['avg']:+.2f} total/$100={test_res['total']:+.2f}")
        print()


if __name__ == "__main__":
    main()
